//
//  JumioLiveness.h
//
//  Copyright © 2025 Jumio Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for JumioLiveness.
FOUNDATION_EXPORT double JumioLivenessVersionNumber;

//! Project version string for JumioLiveness.
FOUNDATION_EXPORT const unsigned char JumioLivenessVersionString[];
