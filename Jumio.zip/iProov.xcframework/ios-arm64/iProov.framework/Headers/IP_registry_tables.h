/* Size of kStringTable 46623 */
/* Size of kNodeTable 3904 */
/* Size of kLeafNodeTable 4435 */
/* Total size 78917 bytes */

static const char kStringTable[] =
"aaa\0" "aarp\0" "abarth\0" "abb\0" "abbott\0" "abbvie\0" "abc\0"
"able\0" "abogado\0" "abudhabi\0" "adac\0" "academy\0" "accenture\0"
"is-an-accountant\0" "accountants\0" "aco\0" "interactive\0" "is-an-actor\0"
"mad\0" "ads\0" "adult\0" "sakae\0" "aeg\0" "aero\0" "aetna\0" "xn--rhkkervju-01af\0"
"afamilycompany\0" "afl\0" "eastafrica\0" "dvag\0" "agakhan\0" "agency\0"
"aisai\0" "aig\0" "daigo\0" "airbus\0" "airforce\0" "airtel\0" "akdn\0"
"coal\0" "alfaromeo\0" "alibaba\0" "alipay\0" "allfinanz\0" "allstate\0"
"ally\0" "alsace\0" "alstom\0" "guam\0" "americanexpress\0" "americanfamily\0"
"banamex\0" "amfam\0" "amica\0" "amsterdam\0" "analytics\0" "android\0"
"anquan\0" "vao\0" "aol\0" "apartments\0" "fhapp\0" "apple\0" "iraq\0"
"aquarelle\0" "far\0" "arab\0" "aramco\0" "archi\0" "army\0" "arpa\0"
"smart\0" "arte\0" "tas\0" "asda\0" "asia\0" "associates\0" "nat\0"
"athleta\0" "attorney\0" "itau\0" "auction\0" "audi\0" "audible\0"
"audio\0" "auspost\0" "author\0" "auto\0" "autos\0" "avianca\0"
"waw\0" "amazonaws\0" "tax\0" "axa\0" "laz\0" "xenapponazure\0"
"nba\0" "baby\0" "baidu\0" "bananarepublic\0" "in-the-band\0" "ubank\0"
"bar\0" "barcelona\0" "barclaycard\0" "barclays\0" "barefoot\0"
"bargains\0" "baseball\0" "basketball\0" "bauhaus\0" "bayern\0"
"bbc\0" "bbt\0" "bbva\0" "bcg\0" "bcn\0" "xn--mgbab2bd\0" "kobe\0"
"beats\0" "beauty\0" "servebeer\0" "bentley\0" "berlin\0" "best\0"
"bestbuy\0" "bet\0" "xn--mgb9awbf\0" "cbg\0" "gmbh\0" "bharti\0"
"sbi\0" "bible\0" "bid\0" "bike\0" "plumbing\0" "bingo\0" "bio\0"
"ebiz\0" "bj\0" "black\0" "blackfriday\0" "blanco\0" "blockbuster\0"
"serveblog\0" "bloomberg\0" "blue\0" "ibm\0" "bms\0" "bmw\0" "cbn\0"
"bnl\0" "bnpparibas\0" "abo\0" "boats\0" "boehringer\0" "bofa\0"
"bom\0" "bond\0" "boo\0" "book\0" "booking\0" "bosch\0" "bostik\0"
"boston\0" "bot\0" "boutique\0" "xbox\0" "abr\0" "bradesco\0" "bridgestone\0"
"broadway\0" "broker\0" "brother\0" "brussels\0" "cbs\0" "budapest\0"
"bugatti\0" "build\0" "builders\0" "business\0" "buzz\0" "bv\0"
"bw\0" "bz\0" "bzh\0" "aca\0" "cab\0" "cafe\0" "medical\0" "call\0"
"calvinklein\0" "hicam\0" "mysecuritycamera\0" "at-band-camp\0"
"cancerresearch\0" "canon\0" "capetown\0" "capital\0" "capitalone\0"
"car\0" "caravan\0" "cards\0" "healthcare\0" "career\0" "careers\0"
"is-into-cars\0" "cartier\0" "casa\0" "case\0" "caseih\0" "cash\0"
"casino\0" "avocat\0" "catering\0" "catholic\0" "xn--nmesjevuemie-tcba\0"
"cbre\0" "xn--l1acc\0" "mycd\0" "ceb\0" "artcenter\0" "ceo\0" "cern\0"
"sncf\0" "cfa\0" "cfd\0" "tech\0" "chanel\0" "travelchannel\0" "charity\0"
"chase\0" "chat\0" "cheap\0" "chintai\0" "christmas\0" "chrome\0"
"chrysler\0" "church\0" "tci\0" "cipriani\0" "circle\0" "sanfrancisco\0"
"citadel\0" "citi\0" "citic\0" "!city\0" "cityeats\0" "duck\0" "wlocl\0"
"claims\0" "cleaning\0" "click\0" "clinic\0" "clinique\0" "clothing\0"
"rhcloud\0" "aeroclub\0" "clubmed\0" "tcm\0" "ecn\0" "coach\0" "codes\0"
"coffee\0" "ilovecollege\0" "cologne\0" "mincom\0" "comcast\0" "commbank\0"
"community\0" "compare\0" "computer\0" "comsec\0" "condos\0" "construction\0"
"consulting\0" "contact\0" "contractors\0" "cooking\0" "cookingchannel\0"
"cool\0" "coop\0" "corsica\0" "country\0" "coupon\0" "coupons\0"
"courses\0" "cr\0" "credit\0" "creditcard\0" "creditunion\0" "cricket\0"
"crown\0" "crs\0" "cruise\0" "cruises\0" "csc\0" "icu\0" "cuisinella\0"
"cv\0" "pccw\0" "cx\0" "cymru\0" "cyou\0" "lowicz\0" "dabur\0" "baghdad\0"
"dance\0" "alwaysdata\0" "hakodate\0" "dating\0" "datsun\0" "today\0"
"dclk\0" "dds\0" "iide\0" "deal\0" "dealer\0" "deals\0" "degree\0"
"delivery\0" "dell\0" "deloitte\0" "delta\0" "is-a-democrat\0" "dental\0"
"dentist\0" "desi\0" "artanddesign\0" "awdev\0" "dhl\0" "diamonds\0"
"diet\0" "digital\0" "nextdirect\0" "myactivedirectory\0" "discount\0"
"discover\0" "dish\0" "diy\0" "dj\0" "tdk\0" "adm\0" "dnp\0" "godo\0"
"docs\0" "is-a-doctor\0" "dodge\0" "dog\0" "doha\0" "domains\0"
"dot\0" "download\0" "drive\0" "dtv\0" "dubai\0" "dunlop\0" "duns\0"
"dupont\0" "durban\0" "camdvr\0" "czeladz\0" "earth\0" "seat\0"
"nec\0" "iveco\0" "edeka\0" "edu\0" "arteducation\0" "tree\0" "leg\0"
"email\0" "emerck\0" "energy\0" "is-an-engineer\0" "engineering\0"
"enterprises\0" "epost\0" "epson\0" "farmequipment\0" "lier\0" "ericsson\0"
"terni\0" "neues\0" "esq\0" "realestate\0" "esurance\0" "fet\0"
"etisalat\0" "eu\0" "eurovision\0" "eus\0" "events\0" "everbank\0"
"serveexchange\0" "geometre-expert\0" "exposed\0" "extraspace\0"
"fage\0" "fail\0" "fairwinds\0" "faith\0" "tuxfamily\0" "mlbfan\0"
"fans\0" "statefarm\0" "farmers\0" "fashion\0" "fast\0" "fedex\0"
"feedback\0" "ferrari\0" "ferrero\0" "sanofi\0" "fiat\0" "fidelity\0"
"fido\0" "film\0" "final\0" "finance\0" "lplfinancial\0" "fire\0"
"firestone\0" "firmdale\0" "fish\0" "fishing\0" "fit\0" "fitness\0"
"fj\0" "jfk\0" "flickr\0" "flights\0" "flir\0" "florist\0" "flowers\0"
"fly\0" "ifm\0" "v-info\0" "foo\0" "food\0" "foodnetwork\0" "football\0"
"oxford\0" "forex\0" "forsale\0" "forum\0" "foundation\0" "fox\0"
"sfr\0" "ddnsfree\0" "fresenius\0" "frl\0" "frogans\0" "frontdoor\0"
"frontier\0" "ftr\0" "fujitsu\0" "fujixerox\0" "fun\0" "fund\0"
"furniture\0" "futbol\0" "fyi\0" "saga\0" "legal\0" "artgallery\0"
"gallo\0" "gallup\0" "marugame\0" "is-into-games\0" "gap\0" "usgarden\0"
"xn--sandnessjen-ogb\0" "gbiz\0" "gd\0" "gdn\0" "koge\0" "gea\0"
"gent\0" "genting\0" "george\0" "ggf\0" "gg\0" "ggee\0" "pittsburgh\0"
"nogi\0" "gift\0" "gifts\0" "gives\0" "giving\0" "gl\0" "glade\0"
"glass\0" "withgoogle\0" "global\0" "globo\0" "xn--fzys8d69uvgm\0"
"gmail\0" "gmo\0" "gmx\0" "bjugn\0" "godaddy\0" "gold\0" "goldpoint\0"
"golf\0" "goo\0" "goodhands\0" "goodyear\0" "goog\0" "gop\0" "forgot\0"
"chernigov\0" "gp\0" "gq\0" "agr\0" "grainger\0" "graphics\0" "gratis\0"
"is-a-green\0" "gripe\0" "grocery\0" "stcgroup\0" "vgs\0" "gt\0"
"ivgu\0" "guardian\0" "gucci\0" "guge\0" "guide\0" "guitars\0" "is-a-guru\0"
"rzgw\0" "hair\0" "hamburg\0" "hangout\0" "hbo\0" "hdfc\0" "hdfcbank\0"
"health\0" "help\0" "helsinki\0" "thruhere\0" "hermes\0" "hgtv\0"
"hiphop\0" "hisamitsu\0" "hitachi\0" "chernihiv\0" "nhk\0" "hkt\0"
"hm\0" "stjohn\0" "hockey\0" "holdings\0" "holiday\0" "homedepot\0"
"homegoods\0" "homes\0" "homesense\0" "honda\0" "honeywell\0" "horse\0"
"hospital\0" "nohost\0" "webhosting\0" "hot\0" "hoteles\0" "kerryhotels\0"
"hotmail\0" "mulhouse\0" "show\0" "ruhr\0" "hsbc\0" "recht\0" "sohu\0"
"hughes\0" "hyatt\0" "hyundai\0" "icbc\0" "venice\0" "fie\0" "ieee\0"
"ikano\0" "mil\0" "cim\0" "imamat\0" "imdb\0" "immo\0" "immobilien\0"
"fin\0" "inc\0" "industries\0" "infiniti\0" "sling\0" "pink\0" "institute\0"
"lifeinsurance\0" "insure\0" "mint\0" "intel\0" "international\0"
"intuit\0" "investments\0" "ipiranga\0" "iq\0" "bir\0" "irish\0"
"iris\0" "iselect\0" "ismaili\0" "istanbul\0" "itv\0" "iwc\0" "jaguar\0"
"java\0" "jcb\0" "jcp\0" "fedje\0" "jeep\0" "jetzt\0" "jewelry\0"
"jio\0" "jlc\0" "jll\0" "jm\0" "jmp\0" "jnj\0" "gujo\0" "jobs\0"
"joburg\0" "jot\0" "joy\0" "jp\0" "jpmorgan\0" "jprs\0" "juegos\0"
"juniper\0" "kaufen\0" "kddi\0" "wake\0" "kerrylogistics\0" "kerryproperties\0"
"kfh\0" "kg\0" "kh\0" "ski\0" "nokia\0" "askim\0" "kinder\0" "kindle\0"
"kitchen\0" "kiwi\0" "km\0" "bokn\0" "koeln\0" "komatsu\0" "kosher\0"
"ostrowwlkp\0" "kpmg\0" "kpn\0" "wskr\0" "krd\0" "kred\0" "kuokgroup\0"
"kw\0" "sky\0" "kyoto\0" "kz\0" "fla\0" "lacaixa\0" "ladbrokes\0"
"lamborghini\0" "lamer\0" "lancaster\0" "lancia\0" "lancome\0" "orland\0"
"landrover\0" "lanxess\0" "lasalle\0" "balat\0" "latino\0" "latrobe\0"
"wroclaw\0" "is-a-lawyer\0" "mlb\0" "plc\0" "lds\0" "lease\0" "leclerc\0"
"lefrak\0" "lego\0" "lexus\0" "lgbt\0" "suli\0" "liaison\0" "lidl\0"
"metlife\0" "lifestyle\0" "lighting\0" "like\0" "lilly\0" "limited\0"
"limo\0" "lincoln\0" "linde\0" "homelink\0" "lipsy\0" "ddnslive\0"
"living\0" "lixil\0" "elk\0" "llc\0" "loan\0" "loans\0" "locker\0"
"locus\0" "loft\0" "lol\0" "london\0" "lotte\0" "lotto\0" "love\0"
"lpl\0" "lr\0" "mls\0" "alt\0" "ltd\0" "ltda\0" "lu\0" "lundbeck\0"
"lupin\0" "luxe\0" "luxury\0" "malselv\0" "mma\0" "macys\0" "madrid\0"
"maif\0" "est-a-la-maison\0" "makeup\0" "itoman\0" "management\0"
"mango\0" "map\0" "indianmarket\0" "marketing\0" "markets\0" "marriott\0"
"marshalls\0" "maserati\0" "mattel\0" "gotemba\0" "xn--qcka1pmc\0"
"mckinsey\0" "bmd\0" "wme\0" "media\0" "meet\0" "melbourne\0" "meme\0"
"memorial\0" "drammen\0" "menu\0" "merckmsd\0" "xn--j1amh\0" "miami\0"
"microsoft\0" "rimini\0" "rmit\0" "mitsubishi\0" "mk\0" "ml\0" "0emm\0"
"pmn\0" "mobi\0" "azure-mobile\0" "mobily\0" "shimoda\0" "moe\0"
"moi\0" "mom\0" "monash\0" "money\0" "monster\0" "mopar\0" "mormon\0"
"mortgage\0" "moscow\0" "kumamoto\0" "motorcycles\0" "mov\0" "movie\0"
"movistar\0" "emp\0" "mq\0" "emr\0" "from-mt\0" "mtn\0" "mtr\0"
"oumu\0" "naturalhistorymuseum\0" "northwesternmutual\0" "mv\0"
"sumy\0" "forumz\0" "arna\0" "xn--rdy-0nab\0" "nadex\0" "nagoya\0"
"tokoname\0" "nationwide\0" "natura\0" "oldnavy\0" "etne\0" "exnet\0"
"netbank\0" "netflix\0" "neustar\0" "new\0" "newholland\0" "news\0"
"next\0" "nexus\0" "inf\0" "nfl\0" "cng\0" "nango\0" "dni\0" "nico\0"
"nike\0" "nikon\0" "ninja\0" "nissan\0" "nissay\0" "ueno\0" "norton\0"
"now\0" "nowruz\0" "nowtv\0" "bnr\0" "kanra\0" "nrw\0" "ntt\0" "rnu\0"
"nyc\0" "linz\0" "observer\0" "off\0" "homeoffice\0" "okinawa\0"
"olayan\0" "olayangroup\0" "ollo\0" "nom\0" "omega\0" "phone\0"
"song\0" "onion\0" "onl\0" "barsyonline\0" "onyourside\0" "ooo\0"
"open\0" "oracle\0" "orange\0" "sarpsborg\0" "eating-organic\0"
"origins\0" "kosaka\0" "morotsuka\0" "ovh\0" "page\0" "panasonic\0"
"panerai\0" "paris\0" "pars\0" "partners\0" "parts\0" "party\0"
"passagens\0" "pet\0" "pf\0" "pfizer\0" "ppg\0" "ph\0" "pharmacy\0"
"phd\0" "philips\0" "photo\0" "photography\0" "myphotos\0" "physio\0"
"piaget\0" "servepics\0" "pictet\0" "pictures\0" "pid\0" "shopping\0"
"pioneer\0" "pizza\0" "pk\0" "birthplace\0" "play\0" "playstation\0"
"ptplus\0" "lmpm\0" "pnc\0" "pohl\0" "poker\0" "politie\0" "porn\0"
"from-pr\0" "pramerica\0" "praxi\0" "prime\0" "pro\0" "prod\0" "productions\0"
"prof\0" "progressive\0" "promo\0" "property\0" "protection\0" "pru\0"
"prudential\0" "ups\0" "pt\0" "pub\0" "pw\0" "pwc\0" "spy\0" "xn--bievt-0qa\0"
"qpon\0" "quebec\0" "quest\0" "qvc\0" "racing\0" "radio\0" "raid\0"
"kure\0" "stufftoread\0" "realtor\0" "realty\0" "recipes\0" "redstone\0"
"redumbrella\0" "rehab\0" "reise\0" "reisen\0" "reit\0" "reliance\0"
"turen\0" "space-to-rent\0" "rentals\0" "repair\0" "report\0" "is-a-republican\0"
"rest\0" "restaurant\0" "review\0" "reviews\0" "rexroth\0" "zuerich\0"
"richardli\0" "ricoh\0" "rightathome\0" "ril\0" "sondrio\0" "loseyourip\0"
"rocher\0" "rocks\0" "rodeo\0" "rogers\0" "room\0" "rsvp\0" "gru\0"
"rugby\0" "run\0" "rwe\0" "ryukyu\0" "wsa\0" "saarland\0" "safe\0"
"safety\0" "sakura\0" "salon\0" "samsclub\0" "samsung\0" "sandvik\0"
"sandvikcoromant\0" "sap\0" "sapo\0" "sarl\0" "sas\0" "save\0" "saxo\0"
"bsb\0" "sbs\0" "psc\0" "sca\0" "scb\0" "schaeffler\0" "schmidt\0"
"scholarships\0" "school\0" "schule\0" "schwarz\0" "historyofscience\0"
"scjohnson\0" "scor\0" "scot\0" "from-sd\0" "nose\0" "cdn77-secure\0"
"security\0" "seek\0" "sener\0" "services\0" "seven\0" "sew\0" "essex\0"
"sexy\0" "xn--5su34j936bgsg\0" "shangrila\0" "sharp\0" "shaw\0"
"shell\0" "shia\0" "shiksha\0" "shoes\0" "workshop\0" "shouji\0"
"showtime\0" "shriram\0" "psi\0" "silk\0" "messina\0" "singles\0"
"freesite\0" "sj\0" "msk\0" "skin\0" "skype\0" "qsl\0" "gsm\0" "smile\0"
"asn\0" "aso\0" "soccer\0" "social\0" "softbank\0" "software\0"
"solar\0" "solutions\0" "sony\0" "masoy\0" "webspace\0" "spiegel\0"
"transport\0" "appspot\0" "spreadbetting\0" "usr\0" "srl\0" "srt\0"
"fst\0" "stada\0" "staples\0" "starhub\0" "statebank\0" "statoil\0"
"stc\0" "stockholm\0" "storage\0" "store\0" "stream\0" "studio\0"
"study\0" "kusu\0" "sucks\0" "supplies\0" "supply\0" "support\0"
"surf\0" "surgery\0" "suzuki\0" "sv\0" "swatch\0" "swiftcover\0"
"swiss\0" "mypsx\0" "sydney\0" "symantec\0" "systems\0" "pisz\0"
"tab\0" "taipei\0" "elasticbeanstalk\0" "taobao\0" "target\0" "tatamotors\0"
"tatar\0" "tattoo\0" "taxi\0" "etc\0" "steam\0" "technology\0" "hotel\0"
"telecity\0" "telefonica\0" "temasek\0" "tennis\0" "teva\0" "wtf\0"
"stg\0" "ath\0" "thd\0" "theater\0" "theatre\0" "tiaa\0" "tickets\0"
"tienda\0" "tiffany\0" "tips\0" "tires\0" "trentinostirol\0" "tj\0"
"tjmaxx\0" "tjx\0" "tk\0" "tkmaxx\0" "intl\0" "atm\0" "tmall\0"
"mito\0" "tokyo\0" "linkitools\0" "freedesktop\0" "toray\0" "toshiba\0"
"total\0" "tours\0" "toyota\0" "toys\0" "ntr\0" "trade\0" "trading\0"
"training\0" "travel\0" "travelers\0" "travelersinsurance\0" "trust\0"
"trv\0" "withyoutube\0" "tui\0" "tunes\0" "tushu\0" "tvs\0" "tw\0"
"myfritz\0" "padua\0" "ubs\0" "uconnect\0" "pug\0" "jeonbuk\0" "unicom\0"
"university\0" "kazuno\0" "uol\0" "jus\0" "ooguy\0" "vacations\0"
"vana\0" "vanguard\0" "vegas\0" "ventures\0" "verisign\0" "versicherung\0"
"skiptvet\0" "fvg\0" "vi\0" "viajes\0" "video\0" "vig\0" "viking\0"
"villas\0" "granvin\0" "vip\0" "virgin\0" "visa\0" "television\0"
"revista\0" "vistaprint\0" "viva\0" "vivo\0" "vlaanderen\0" "koebenhavn\0"
"vodka\0" "volkswagen\0" "volvo\0" "vote\0" "voting\0" "voto\0"
"voyage\0" "vu\0" "vuelos\0" "wales\0" "walmart\0" "walter\0" "wang\0"
"wanggou\0" "warman\0" "watches\0" "weather\0" "weatherchannel\0"
"webcam\0" "weber\0" "s3-website\0" "wed\0" "wedding\0" "weibo\0"
"weir\0" "wf\0" "whoswho\0" "wien\0" "dyndns-wiki\0" "williamhill\0"
"win\0" "windows\0" "wine\0" "winners\0" "wolterskluwer\0" "woodside\0"
"works\0" "world\0" "wow\0" "wtc\0" "xfinity\0" "xihuan\0" "xin\0"
"xn--11b4c3d\0" "xn--1ck2e1b\0" "xn--1qqw23a\0" "xn--2scrj9c\0"
"xn--30rr7y\0" "xn--3bst00m\0" "xn--3ds443g\0" "xn--3e0b707e\0"
"xn--3hcrj9c\0" "xn--3oq18vl8pn36a\0" "xn--3pxu8k\0" "xn--42c2d9a\0"
"xn--45br5cyl\0" "xn--45brj9c\0" "xn--45q11c\0" "xn--4gbrim\0" "xn--54b7fta0cc\0"
"xn--55qw42g\0" "xn--55qx5d\0" "xn--5tzm5g\0" "xn--6frz82g\0" "xn--6qq986b3xl\0"
"xn--80adxhks\0" "xn--80ao21a\0" "xn--80aqecdr1a\0" "xn--80asehdb\0"
"xn--80aswg\0" "xn--8y0a063a\0" "xn--90a3ac\0" "xn--90ae\0" "xn--90ais\0"
"xn--9dbq2a\0" "xn--9et52u\0" "xn--9krt00a\0" "xn--b4w605ferd\0"
"xn--bck1b9a5dre4c\0" "xn--c1avg\0" "xn--c2br7g\0" "xn--cck2b3b\0"
"xn--cg4bki\0" "xn--clchc0ea0b2g2a9gcd\0" "xn--czr694b\0" "xn--czrs0t\0"
"xn--czru2d\0" "xn--d1acj3b\0" "xn--d1alf\0" "xn--e1a4c\0" "xn--eckvdtc9d\0"
"xn--efvy88h\0" "xn--estv75g\0" "xn--fct429k\0" "xn--fhbei\0" "xn--fiq228c5hs\0"
"xn--fiq64b\0" "xn--fiqs8s\0" "xn--fiqz9s\0" "xn--fjq720a\0" "xn--flw351e\0"
"xn--fpcrj9c3d\0" "xn--fzc2c9e2c\0" "xn--g2xx48c\0" "xn--gckr3f0f\0"
"xn--gecrj9c\0" "xn--gk3at1e\0" "xn--h2breg3eve\0" "xn--h2brj9c\0"
"xn--h2brj9c8c\0" "xn--hxt814e\0" "xn--i1b6b1a6a2e\0" "xn--imr513n\0"
"xn--io0a7i\0" "xn--j1aef\0" "xn--j6w193g\0" "xn--jlq61u9w7b\0"
"xn--jvr189m\0" "xn--kcrx77d1x4a\0" "xn--kprw13d\0" "xn--kpry57d\0"
"xn--kpu716f\0" "xn--kput3i\0" "xn--lgbbat1ad8j\0" "xn--mgb2ddes\0"
"xn--mgba3a3ejt\0" "xn--mgba3a4f16a\0" "xn--mgba3a4fra\0" "xn--mgba7c0bbn0a\0"
"xn--mgbaakc7dvf\0" "xn--mgbaam7a8h\0" "xn--mgbai9a5eva00b\0" "xn--mgbai9azgqp6j\0"
"xn--mgbayh7gpa\0" "xn--mgbb9fbpob\0" "xn--mgbbh1a\0" "xn--mgbbh1a71e\0"
"xn--mgbc0a9azcg\0" "xn--mgbca7dzdo\0" "xn--mgberp4a5d4a87g\0" "xn--mgberp4a5d4ar\0"
"xn--mgbgu82a\0" "xn--mgbi4ecexp\0" "xn--mgbpl2fh\0" "xn--mgbqly7c0a67fbc\0"
"xn--mgbqly7cvafr\0" "xn--mgbt3dhd\0" "xn--mgbtf8fl\0" "xn--mgbtx2b\0"
"xn--mgbx4cd0ab\0" "xn--mix082f\0" "xn--mix891f\0" "xn--mk1bu44c\0"
"xn--mxtq1m\0" "xn--ngbc5azd\0" "xn--ngbe9e0a\0" "xn--ngbrx\0" "xn--nnx388a\0"
"xn--node\0" "xn--nqv7f\0" "xn--nqv7fs00ema\0" "xn--nyqy26a\0" "xn--o3cw4h\0"
"xn--ogbpf8fl\0" "xn--otu796d\0" "xn--p1acf\0" "xn--p1ai\0" "xn--pbt977c\0"
"xn--pgbs0dh\0" "xn--pssy2u\0" "xn--q9jyb4c\0" "xn--qxam\0" "xn--rhqv96g\0"
"xn--rovu88b\0" "xn--rvc1e0am3e\0" "xn--s9brj9c\0" "xn--ses554g\0"
"xn--t60b56a\0" "xn--tckwe\0" "xn--tiq49xqyj\0" "xn--unup4y\0" "xn--vermgensberater-ctb\0"
"xn--vermgensberatung-pwb\0" "xn--vhquv\0" "xn--vuq861b\0" "xn--w4r85el8fhu5dnra\0"
"xn--w4rs40l\0" "xn--wgbh1c\0" "xn--wgbl6a\0" "xn--xhq521b\0" "xn--xkc2al3hye2a\0"
"xn--xkc2dl3a5ee0h\0" "xn--y9a3aq\0" "xn--yfro4i67o\0" "xn--ygbi2ammx\0"
"xn--zfr164b\0" "xperia\0" "xxx\0" "xyz\0" "yachts\0" "yahoo\0"
"yamaxun\0" "yandex\0" "ye\0" "yodobashi\0" "teaches-yoga\0" "yokohama\0"
"yt\0" "yun\0" "koza\0" "zappos\0" "zara\0" "zero\0" "zip\0" "zippo\0"
"zm\0" "podzone\0" "zw\0" "official\0" "blogspot\0" "accident-investigation\0"
"accident-prevention\0" "aerobatic\0" "aerodrome\0" "agents\0" "air-surveillance\0"
"air-traffic-control\0" "aircraft\0" "airline\0" "airport\0" "airtraffic\0"
"ambulance\0" "amusement\0" "passenger-association\0" "ballooning\0"
"caa\0" "cargo\0" "certification\0" "championship\0" "charter\0"
"civilaviation\0" "conference\0" "consultant\0" "council\0" "crew\0"
"dgca\0" "educator\0" "emergency\0" "engine\0" "entertainment\0"
"federation\0" "flight\0" "freight\0" "fuel\0" "hanggliding\0" "government\0"
"groundhandling\0" "homebuilt\0" "journal\0" "journalist\0" "leasing\0"
"magazine\0" "maintenance\0" "microlight\0" "modelling\0" "navigation\0"
"parachuting\0" "paragliding\0" "pilot\0" "production\0" "recreation\0"
"repbody\0" "rotorcraft\0" "scientist\0" "skydiving\0" "is-a-student\0"
"trader\0" "is-a-personaltrainer\0" "workinggroup\0" "fed\0" "gv\0"
"cog\0" "spb\0" "hasura\0" "gob\0" "musica\0" "karikatur\0" "e164\0"
"in-addr\0" "ip6\0" "heguri\0" "urn\0" "cloudns\0" "12hp\0" "2ix\0"
"4lima\0" "futurecms\0" "futurehosting\0" "futuremailing\0" "lima-city\0"
"jor\0" "ortsinfo\0" "priv\0" "*\0" "szex\0" "kunden\0" "conf\0"
"nsw\0" "cnt\0" "foz\0" "qld\0" "uvic\0" "sowa\0" "klepp\0" "transurl\0"
"2000\0" "eu-1\0" "u2\0" "s3\0" "e4\0" "5\0" "1337\0" "2038\0" "9\0"
"barsy\0" "qc\0" "sf\0" "qh\0" "yk\0" "jl\0" "cq\0" "rr\0" "js\0"
"gx\0" "dscloud\0" "dyndns\0" "for-better\0" "here-for-more\0" "for-some\0"
"for-the\0" "mmafan\0" "myftp\0" "no-ip\0" "selfip\0" "webhop\0"
"campobasso\0" "barreau\0" "gouv\0" "academia\0" "agro\0" "bolivia\0"
"ciencia\0" "cooperativa\0" "democracia\0" "deporte\0" "ecologia\0"
"economia\0" "empresa\0" "indigena\0" "industria\0" "medicina\0"
"movimiento\0" "natural\0" "nombre\0" "noticias\0" "patria\0" "plurinacional\0"
"politica\0" "profesional\0" "pueblo\0" "salud\0" "tecnologia\0"
"tksat\0" "transporte\0" "on-web\0" "9guacu\0" "adv\0" "aju\0" "anani\0"
"aparecida\0" "arq\0" "bato\0" "barueri\0" "belem\0" "bhz\0" "boavista\0"
"campinagrande\0" "campinas\0" "caxias\0" "contagem\0" "cri\0" "cuiaba\0"
"curitiba\0" "def\0" "eng\0" "esp\0" "rieti\0" "feira\0" "flog\0"
"floripa\0" "fnd\0" "fortal\0" "fot\0" "g12\0" "goiania\0" "imb\0"
"ind\0" "jab\0" "jampa\0" "jdf\0" "joinville\0" "lel\0" "londrina\0"
"macapa\0" "maceio\0" "manaus\0" "maringa\0" "morena\0" "mus\0"
"natal\0" "niteroi\0" "not\0" "osasco\0" "palmas\0" "xn--rdal-poa\0"
"pvh\0" "disrec\0" "recife\0" "ribeirao\0" "riobranco\0" "riopreto\0"
"salvador\0" "sampa\0" "santamaria\0" "santoandre\0" "saobernardo\0"
"saogonca\0" "sjc\0" "slg\0" "slz\0" "sorocaba\0" "srv\0" "teo\0"
"tmp\0" "trd\0" "vix\0" "vlog\0" "zlg\0" "lecce\0" "togo\0" "mypi\0"
"storj\0" "nym\0" "gc\0" "winb\0" "rns\0" "toon\0" "fantasyleague\0"
"ftpaccess\0" "game-server\0" "scrapping\0" "twmail\0" "ddnsking\0"
"gotdns\0" "linkyard-cloud\0" "square7\0" "presse\0" "xn--aroport-bya\0"
"!www\0" "linkyard\0" "magentosite\0" "sensiosite\0" "statics\0"
"trafficplex\0" "vapor\0" "utah\0" "gz\0" "naha\0" "xn--valle-d-aoste-ehb\0"
"marche\0" "ohi\0" "from-nm\0" "manx\0" "xj\0" "xn--od0alg\0" "xz\0"
"stryn\0" "zj\0" "cn-north-1\0" "compute\0" "elb\0" "firm\0" "n4t\0"
"nodum\0" "otap\0" "001www\0" "1kapp\0" "3utilities\0" "xn--8pvr4u\0"
"alpha-myqnapcloud\0" "appchizi\0" "applinzi\0" "barsycenter\0"
"betainabox\0" "bitballoon\0" "blogdns\0" "blogsyte\0" "bloxcms\0"
"bounty-full\0" "bplaced\0" "cechire\0" "ciscofreak\0" "cloudcontrolapp\0"
"cloudcontrolled\0" "codespot\0" "damnserver\0" "dattolocal\0" "dattorelay\0"
"dattoweb\0" "ddnsgeek\0" "dev-myqnapcloud\0" "ditchyourip\0" "dnsalias\0"
"dnsdojo\0" "dnsiskinky\0" "doesntexist\0" "dontexist\0" "doomdns\0"
"drayddns\0" "dreamhosters\0" "dsmynas\0" "dyn-o-saur\0" "dynalias\0"
"dyndns-at-home\0" "dyndns-at-work\0" "dyndns-blog\0" "dyndns-free\0"
"dyndns-home\0" "dyndns-ip\0" "dyndns-mail\0" "dyndns-office\0"
"dyndns-pics\0" "dyndns-remote\0" "dyndns-server\0" "dyndns-web\0"
"dyndns-work\0" "dynns\0" "est-a-la-masion\0" "est-le-patron\0"
"est-mon-blogueur\0" "evennode\0" "familyds\0" "fastvps-server\0"
"fbsbx\0" "firebaseapp\0" "firewall-gateway\0" "flynnhub\0" "freebox-os\0"
"freeboxos\0" "from-ak\0" "from-al\0" "from-ar\0" "from-ca\0" "from-ct\0"
"from-dc\0" "from-de\0" "from-fl\0" "from-ga\0" "from-hi\0" "from-ia\0"
"from-id\0" "from-il\0" "from-in\0" "from-ks\0" "from-ky\0" "from-ma\0"
"from-md\0" "from-mi\0" "from-mn\0" "from-mo\0" "from-ms\0" "from-nc\0"
"from-nd\0" "from-ne\0" "from-nh\0" "from-nj\0" "from-nv\0" "from-oh\0"
"from-ok\0" "from-or\0" "from-pa\0" "from-ri\0" "from-sc\0" "from-tn\0"
"from-tx\0" "from-ut\0" "from-va\0" "from-vt\0" "from-wa\0" "from-wi\0"
"from-wv\0" "from-wy\0" "geekgalaxy\0" "getmyip\0" "giize\0" "githubusercontent\0"
"gleeze\0" "googleapis\0" "googlecode\0" "gotpantheon\0" "health-carereform\0"
"herokuapp\0" "herokussl\0" "hobby-site\0" "homelinux\0" "homesecuritymac\0"
"homesecuritypc\0" "homeunix\0" "iamallama\0" "is-a-anarchist\0"
"is-a-blogger\0" "is-a-bookkeeper\0" "is-a-bulls-fan\0" "is-a-caterer\0"
"is-a-chef\0" "is-a-conservative\0" "is-a-cpa\0" "is-a-cubicle-slave\0"
"is-a-designer\0" "is-a-financialadvisor\0" "is-a-geek\0" "is-a-hard-worker\0"
"is-a-hunter\0" "is-a-landscaper\0" "is-a-liberal\0" "is-a-libertarian\0"
"is-a-llama\0" "is-a-musician\0" "is-a-nascarfan\0" "is-a-nurse\0"
"is-a-painter\0" "is-a-photographer\0" "is-a-player\0" "is-a-rockstar\0"
"is-a-socialist\0" "is-a-teacher\0" "is-a-techie\0" "is-a-therapist\0"
"is-an-actress\0" "is-an-anarchist\0" "is-an-artist\0" "is-an-entertainer\0"
"is-certified\0" "is-gone\0" "is-into-anime\0" "is-into-cartoons\0"
"is-leet\0" "is-not-certified\0" "is-slick\0" "is-uberleet\0" "is-with-theband\0"
"isa-geek\0" "isa-hockeynut\0" "issmarterthanyou\0" "jdevcloud\0"
"joyent\0" "jpn\0" "kozow\0" "likes-pie\0" "likescandy\0" "logoip\0"
"meteorapp\0" "miniserver\0" "myasustor\0" "mydatto\0" "mydrobo\0"
"myiphost\0" "myravendb\0" "myshopblocks\0" "mytuleap\0" "myvnc\0"
"neat-url\0" "net-freaks\0" "netlify\0" "nfshost\0" "on-aptible\0"
"onthewifi\0" "operaunite\0" "outsystemscloud\0" "ownprovider\0"
"pagefrontapp\0" "pagespeedmobilizer\0" "pgfog\0" "pixolino\0" "point2this\0"
"prgmr\0" "publishproxy\0" "qa2\0" "quicksytes\0" "quipelements\0"
"rackmaze\0" "remotewd\0" "saves-the-whales\0" "scrysec\0" "securitytactics\0"
"sells-for-less\0" "sells-for-u\0" "servebbs\0" "servecounterstrike\0"
"serveftp\0" "servegame\0" "servehalflife\0" "servehttp\0" "servehumour\0"
"serveirc\0" "servemp3\0" "servep2p\0" "servequake\0" "servesarcasm\0"
"simple-url\0" "vipsinaapp\0" "temp-dns\0" "theworkpc\0" "townnews-staging\0"
"unusualperson\0" "workisboring\0" "wpdevcloud\0" "writesthisblog\0"
"xnbay\0" "yolasite\0" "s3-ap-northeast-1\0" "s3-ap-northeast-2\0"
"s3-ap-south-1\0" "s3-ap-southeast-1\0" "s3-ap-southeast-2\0" "s3-ca-central-1\0"
"compute-1\0" "s3-eu-central-1\0" "s3-eu-west-1\0" "s3-eu-west-2\0"
"s3-eu-west-3\0" "s3-external-1\0" "s3-fips-us-gov-west-1\0" "s3-sa-east-1\0"
"s3-us-east-2\0" "s3-us-gov-west-1\0" "s3-us-west-1\0" "s3-us-west-2\0"
"s3-website-ap-northeast-1\0" "s3-website-ap-southeast-1\0" "s3-website-ap-southeast-2\0"
"s3-website-eu-west-1\0" "s3-website-sa-east-1\0" "s3-website-us-east-1\0"
"s3-website-us-west-1\0" "s3-website-us-west-2\0" "dualstack\0"
"alpha\0" "beta\0" "ap-northeast-3\0" "eu-2\0" "eu-3\0" "eu-4\0"
"us-1\0" "us-2\0" "us-3\0" "us-4\0" "cleverapps\0" "cns\0" "xen\0"
"u2-local\0" "ekloges\0" "parliament\0" "metacentrum\0" "muni\0"
"realm\0" "custom\0" "flt\0" "cosidns\0" "dd-dns\0" "ddnss\0" "dnshome\0"
"dnsupdater\0" "dray-dns\0" "draydns\0" "dyn-ip24\0" "dyn-vpn\0"
"dynamisches-dns\0" "dyndns1\0" "dynvpn\0" "fuettertdasnetz\0" "git-repos\0"
"home-webserver\0" "internet-dns\0" "isteingeek\0" "istmein\0" "keymachine\0"
"l-o-g-i-n\0" "lcube-server\0" "lebtimnetz\0" "leitungsen\0" "mein-iserv\0"
"mein-vigor\0" "my-gateway\0" "my-router\0" "my-vigor\0" "my-wan\0"
"myhome-server\0" "spdns\0" "speedpartner\0" "svn-repos\0" "syno-ds\0"
"synology-diskstation\0" "synology-ds\0" "taifun-dns\0" "test-iserv\0"
"traeumtgerade\0" "uberspace\0" "virtual-user\0" "virtualuser\0"
"dedyn\0" "customer\0" "fastpanel\0" "reg\0" "sld\0" "nerdpol\0"
"k12\0" "aip\0" "lib\0" "pri\0" "riik\0" "eun\0" "nieruchomosci\0"
"wellbeingzone\0" "ybo\0" "hordaland\0" "cody\0" "niki\0" "aeroport\0"
"assedic\0" "avoues\0" "chambagri\0" "chirurgiens-dentistes\0" "chirurgiens-dentistes-en-france\0"
"experts-comptables\0" "fbx-os\0" "fbxos\0" "greta\0" "huissier-justice\0"
"medecin\0" "notaires\0" "pharmacien\0" "prd\0" "veterinaire\0"
"cnpy\0" "pvt\0" "cya\0" "mod\0" "idv\0" "xn--ciqpn\0" "xn--gmq050i\0"
"xn--gmqw5a\0" "xn--lcvr32d\0" "xn--mk0axi\0" "xn--od0aq3b\0" "xn--tn0ag\0"
"xn--uc0atv\0" "xn--uc0ay4a\0" "xn--wcvs22d\0" "xn--zf0avx\0" "cloudaccess\0"
"half\0" "opencraft\0" "from\0" "perso\0" "rel\0" "agrar\0" "bolt\0"
"erotica\0" "erotika\0" "ingatlan\0" "jogasz\0" "konyvelo\0" "lakas\0"
"reklam\0" "tozsde\0" "utazas\0" "odesa\0" "idf\0" "bergen\0" "barrel-of-knowledge\0"
"barrell-of-knowledge\0" "dvrcam\0" "dynamic-dns\0" "for-our\0"
"groks-the\0" "groks-this\0" "knowsitall\0" "mayfirst\0" "nsupdate\0"
"azurecontainer\0" "backplaneapp\0" "boxfuse\0" "browsersafetymark\0"
"definima\0" "drud\0" "enonic\0" "github\0" "gitlab\0" "hasura-app\0"
"hzc\0" "lair\0" "ngrok\0" "nid\0" "nodeart\0" "pantheonsite\0"
"protonet\0" "resindevice\0" "resinstaging\0" "s5y\0" "sandcats\0"
"shiftedit\0" "spacekit\0" "stolos\0" "thingdust\0" "utwente\0"
"vaporcloud\0" "wedeploy\0" "stage\0" "devices\0" "testing\0" "cust\0"
"cupcake\0" "16-b\0" "32-b\0" "64-b\0" "abruzzo\0" "agrigento\0"
"alessandria\0" "trentinoalto-adige\0" "trentinoaltoadige\0" "esan\0"
"ancona\0" "andria-barletta-trani\0" "andria-trani-barletta\0" "andriabarlettatrani\0"
"andriatranibarletta\0" "valdaosta\0" "aosta-valley\0" "aostavalley\0"
"valleeaoste\0" "laquila\0" "arezzo\0" "ascoli-piceno\0" "ascolipiceno\0"
"asti\0" "av\0" "avellino\0" "balsan\0" "balsan-sudtirol\0" "balsan-suedtirol\0"
"nabari\0" "barletta-trani-andria\0" "barlettatraniandria\0" "basilicata\0"
"belluno\0" "benevento\0" "bergamo\0" "biella\0" "publ\0" "bologna\0"
"bolzano\0" "bolzano-altoadige\0" "bozen\0" "bozen-sudtirol\0" "bozen-suedtirol\0"
"brescia\0" "brindisi\0" "bulsan\0" "bulsan-sudtirol\0" "bulsan-suedtirol\0"
"cagliari\0" "reggiocalabria\0" "caltanissetta\0" "campania\0" "campidano-medio\0"
"campidanomedio\0" "carbonia-iglesias\0" "carboniaiglesias\0" "carrara-massa\0"
"carraramassa\0" "caserta\0" "catania\0" "catanzaro\0" "cesena-forli\0"
"cesenaforli\0" "chieti\0" "como\0" "cosenza\0" "cremona\0" "crotone\0"
"acct\0" "cuneo\0" "dell-ogliastra\0" "dellogliastra\0" "emilia-romagna\0"
"emiliaromagna\0" "ravenna\0" "fermo\0" "ferrara\0" "fg\0" "firenze\0"
"florence\0" "foggia\0" "forli-cesena\0" "forlicesena\0" "friuli-v-giulia\0"
"friuli-ve-giulia\0" "friuli-vegiulia\0" "friuli-venezia-giulia\0"
"friuli-veneziagiulia\0" "friuli-vgiulia\0" "friuliv-giulia\0" "friulive-giulia\0"
"friulivegiulia\0" "friulivenezia-giulia\0" "friuliveneziagiulia\0"
"friulivgiulia\0" "frosinone\0" "genoa\0" "genova\0" "gorizia\0"
"grosseto\0" "iglesias-carbonia\0" "iglesiascarbonia\0" "imperia\0"
"isernia\0" "la-spezia\0" "laspezia\0" "latina\0" "lazio\0" "bale\0"
"lecco\0" "lig\0" "liguria\0" "livorno\0" "plo\0" "lodi\0" "lom\0"
"lombardia\0" "lombardy\0" "lucania\0" "lucca\0" "macerata\0" "mantova\0"
"hamar\0" "massa-carrara\0" "massacarrara\0" "matera\0" "medio-campidano\0"
"mediocampidano\0" "isumi\0" "milan\0" "milano\0" "modena\0" "mol\0"
"molise\0" "monza\0" "monza-brianza\0" "monza-e-della-brianza\0"
"monzabrianza\0" "monzaebrianza\0" "monzaedellabrianza\0" "naples\0"
"napoli\0" "novara\0" "nuoro\0" "olbia-tempio\0" "olbiatempio\0"
"oristano\0" "padova\0" "palermo\0" "parma\0" "pavia\0" "pd\0" "perugia\0"
"pesaro-urbino\0" "pesarourbino\0" "pescara\0" "piacenza\0" "piedmont\0"
"piemonte\0" "pisa\0" "pistoia\0" "uppo\0" "pordenone\0" "potenza\0"
"prato\0" "pippu\0" "puglia\0" "pv\0" "pz\0" "nara\0" "ragusa\0"
"reggio-calabria\0" "reggio-emilia\0" "reggioemilia\0" "elburg\0"
"saroma\0" "rovigo\0" "salerno\0" "sar\0" "sardegna\0" "sardinia\0"
"sassari\0" "savona\0" "music\0" "sicilia\0" "sicily\0" "siena\0"
"siracusa\0" "moss\0" "kota\0" "vantaa\0" "taranto\0" "tempio-olbia\0"
"tempioolbia\0" "teramo\0" "torino\0" "toscana\0" "trani-andria-barletta\0"
"trani-barletta-andria\0" "traniandriabarletta\0" "tranibarlettaandria\0"
"trapani\0" "trentin-sud-tirol\0" "trentin-sudtirol\0" "trentin-sued-tirol\0"
"trentin-suedtirol\0" "trentino\0" "trentino-a-adige\0" "trentino-aadige\0"
"trentino-alto-adige\0" "trentino-altoadige\0" "trentino-s-tirol\0"
"trentino-stirol\0" "trentino-sud-tirol\0" "trentino-sudtirol\0"
"trentino-sued-tirol\0" "trentino-suedtirol\0" "trentinoa-adige\0"
"trentinoaadige\0" "trentinos-tirol\0" "trentinosud-tirol\0" "trentinosudtirol\0"
"trentinosued-tirol\0" "trentinosuedtirol\0" "trentinsud-tirol\0"
"trentinsudtirol\0" "trentinsued-tirol\0" "trentinsuedtirol\0" "trento\0"
"treviso\0" "trieste\0" "its\0" "turin\0" "tuscany\0" "udine\0"
"umb\0" "umbria\0" "urbino-pesaro\0" "urbinopesaro\0" "val-d-aosta\0"
"val-daosta\0" "vald-aosta\0" "valle-aosta\0" "valle-d-aosta\0"
"valle-daosta\0" "valleaosta\0" "valled-aosta\0" "valledaosta\0"
"vallee-aoste\0" "vallee-d-aoste\0" "valleedaoste\0" "varese\0"
"xn--trentin-sdtirol-7vb\0" "vda\0" "veneto\0" "venezia\0" "verbania\0"
"vercelli\0" "verona\0" "vibo-valentia\0" "vibovalentia\0" "vicenza\0"
"viterbo\0" "vv\0" "xn--balsan-sdtirol-nsb\0" "xn--bozen-sdtirol-2ob\0"
"xn--bulsan-sdtirol-nsb\0" "xn--cesena-forl-mcb\0" "xn--cesenaforl-i8a\0"
"xn--forl-cesena-fcb\0" "xn--forlcesena-c8a\0" "xn--sdtirol-n2a\0"
"xn--trentin-sd-tirol-rzb\0" "xn--trentino-sd-tirol-c3b\0" "xn--trentino-sdtirol-szb\0"
"xn--trentinosd-tirol-rzb\0" "xn--trentinosdtirol-7vb\0" "xn--trentinsd-tirol-6vb\0"
"xn--trentinsdtirol-nsb\0" "xn--valle-aoste-ebb\0" "xn--valleaoste-e7a\0"
"xn--valledaoste-ebb\0" "yokkaichi\0" "kawakita\0" "aomori\0" "yokaichiba\0"
"ehime\0" "fukui\0" "fukuoka\0" "kisofukushima\0" "gifu\0" "gunma\0"
"kitahiroshima\0" "hokkaido\0" "hyogo\0" "ibaraki\0" "nishikawa\0"
"iwate\0" "nakagawa\0" "kagoshima\0" "kanagawa\0" "kawasaki\0" "kitakyushu\0"
"kochi\0" "namie\0" "miyagi\0" "miyazaki\0" "kawachinagano\0" "nagasaki\0"
"niigata\0" "yoita\0" "okayama\0" "saitama\0" "sapporo\0" "satsumasendai\0"
"shiga\0" "shimane\0" "shizuoka\0" "tochigi\0" "tokushima\0" "tottori\0"
"motoyama\0" "wakayama\0" "xn--0trq7p7nn\0" "xn--1ctwo\0" "xn--1lqs03n\0"
"xn--1lqs71d\0" "xn--2m4a15e\0" "xn--32vp30h\0" "xn--4it168d\0"
"xn--4it797k\0" "xn--4pvxs\0" "xn--5js045d\0" "xn--5rtp49c\0" "xn--5rtq34k\0"
"xn--6btw5a\0" "xn--6orx2r\0" "xn--7t0a264c\0" "xn--8ltr62k\0" "xn--c3s14m\0"
"xn--d5qv7z876c\0" "xn--djrs72d6uy\0" "xn--djty4k\0" "xn--efvn9s\0"
"xn--ehqz56n\0" "xn--elqq16h\0" "xn--f6qx53a\0" "xn--k7yn95e\0"
"xn--kbrq7o\0" "xn--klt787d\0" "xn--kltp7d\0" "xn--kltx9a\0" "xn--klty5x\0"
"xn--mkru45i\0" "xn--nit225k\0" "xn--ntso0iqx3a\0" "xn--ntsq17g\0"
"xn--pssu33l\0" "xn--qqqt11m\0" "xn--rht27z\0" "xn--rht3d\0" "xn--rht61e\0"
"xn--rny31h\0" "xn--tor131o\0" "xn--uist22h\0" "xn--uisz3g\0" "xn--uuwu58a\0"
"xn--vgu402c\0" "xn--zbx025d\0" "yamagata\0" "yamaguchi\0" "yamanashi\0"
"zama\0" "sanjo\0" "asuke\0" "chiryu\0" "chita\0" "fuso\0" "gamagori\0"
"handa\0" "hazu\0" "hekinan\0" "higashiura\0" "ichinomiya\0" "inazawa\0"
"inuyama\0" "isshiki\0" "iwakura\0" "kanie\0" "kariya\0" "kasugai\0"
"kira\0" "kiyosu\0" "komaki\0" "konan\0" "mihama\0" "higashisumiyoshi\0"
"nishio\0" "nisshin\0" "motobu\0" "oguchi\0" "oharu\0" "okazaki\0"
"owariasahi\0" "oseto\0" "shikatsu\0" "shinshiro\0" "shitara\0"
"tahara\0" "takahama\0" "tobishima\0" "toei\0" "tokai\0" "toyoake\0"
"toyohashi\0" "toyokawa\0" "toyone\0" "komatsushima\0" "yatomi\0"
"daisen\0" "fujisato\0" "gojome\0" "hachirogata\0" "happou\0" "higashinaruse\0"
"yurihonjo\0" "honjyo\0" "aikawa\0" "kamikoani\0" "kamioka\0" "katagami\0"
"kitaakita\0" "kyowa\0" "tomisato\0" "minamitane\0" "moriyoshi\0"
"nikaho\0" "noshiro\0" "koga\0" "nogata\0" "semboku\0" "yokote\0"
"gonohe\0" "hachinohe\0" "hashikami\0" "hiranai\0" "hirosaki\0"
"itayanagi\0" "kuroishi\0" "misawa\0" "mutsu\0" "nakadomari\0" "noheji\0"
"oirase\0" "owani\0" "rokunohe\0" "sannohe\0" "shichinohe\0" "shingo\0"
"takko\0" "towada\0" "tsugaru\0" "tsuruta\0" "abiko\0" "chonan\0"
"chosei\0" "choshi\0" "kibichuo\0" "funabashi\0" "futtsu\0" "hanamigawa\0"
"ichihara\0" "ichikawa\0" "inzai\0" "kamagaya\0" "kamogawa\0" "kashiwa\0"
"takatori\0" "nachikatsuura\0" "kimitsu\0" "kisarazu\0" "kozaki\0"
"kujukuri\0" "kyonan\0" "matsudo\0" "midori\0" "minamiboso\0" "mobara\0"
"mutsuzawa\0" "nagara\0" "nagareyama\0" "narashino\0" "narita\0"
"noda\0" "oamishirasato\0" "omigawa\0" "onjuku\0" "kurotaki\0" "shimofusa\0"
"shirako\0" "shiroi\0" "shisui\0" "sodegaura\0" "sosa\0" "itako\0"
"tateyama\0" "togane\0" "tohnosho\0" "urayasu\0" "yachimata\0" "yachiyo\0"
"yokoshibahikari\0" "yotsukaido\0" "kainan\0" "shonai\0" "namikata\0"
"imabari\0" "seiyo\0" "osakikamijima\0" "kihoku\0" "kumakogen\0"
"masaki\0" "matsuno\0" "higashimatsuyama\0" "niihama\0" "uozu\0"
"saijo\0" "shikokuchuo\0" "otobe\0" "fujikawaguchiko\0" "uwajima\0"
"yawatahama\0" "minamiechizen\0" "eiheiji\0" "ikeda\0" "katsuyama\0"
"obama\0" "tono\0" "sabae\0" "sakai\0" "tsuruga\0" "wakasa\0" "ashiya\0"
"buzen\0" "chikugo\0" "chikuho\0" "chikujo\0" "chikushino\0" "chikuzen\0"
"dazaifu\0" "fukuchi\0" "hakata\0" "higashi\0" "hirokawa\0" "hisayama\0"
"iizuka\0" "inatsuki\0" "kasuga\0" "kasuya\0" "kawara\0" "keisen\0"
"kurate\0" "kurogi\0" "higashikurume\0" "asaminami\0" "miyako\0"
"kumiyama\0" "miyawaka\0" "mizumaki\0" "munakata\0" "nakama\0" "seranishi\0"
"ogori\0" "okagaki\0" "toki\0" "omuta\0" "onga\0" "miyakonojo\0"
"koto\0" "saigawa\0" "sasaguri\0" "shingu\0" "shinyoshitomi\0" "soeda\0"
"matsue\0" "tachiarai\0" "kitagawa\0" "kitakata\0" "toho\0" "toyotsu\0"
"tsuiki\0" "ukiha\0" "yusui\0" "yamada\0" "yame\0" "yanagawa\0"
"yukuhashi\0" "aizubange\0" "aizumisato\0" "aizuwakamatsu\0" "asakawa\0"
"bandai\0" "furudono\0" "futaba\0" "hanawa\0" "hirata\0" "hirono\0"
"iitate\0" "inawashiro\0" "nishiwaki\0" "izumizaki\0" "kagamiishi\0"
"kaneyama\0" "kawamata\0" "kitashiobara\0" "koori\0" "yamatokoriyama\0"
"kunimi\0" "miharu\0" "mishima\0" "nishiaizu\0" "nishigo\0" "okuma\0"
"omotego\0" "otama\0" "samegawa\0" "shimogo\0" "higashishirakawa\0"
"showa\0" "soma\0" "sukagawa\0" "taishin\0" "tamakawa\0" "tanagura\0"
"tenei\0" "yabuki\0" "higashiyamato\0" "yamatsuri\0" "yanaizu\0"
"yugawa\0" "anpachi\0" "ginan\0" "hashima\0" "hichiso\0" "machida\0"
"ibigawa\0" "kakamigahara\0" "kani\0" "kasahara\0" "kasamatsu\0"
"kawaue\0" "kitagata\0" "kimino\0" "minokamo\0" "mitake\0" "mizunami\0"
"motosu\0" "nakatsugawa\0" "aogaki\0" "sakahogi\0" "ichinoseki\0"
"sekigahara\0" "tajimi\0" "takayama\0" "tarui\0" "tomika\0" "wanouchi\0"
"yaotsu\0" "nayoro\0" "annaka\0" "chiyoda\0" "fujioka\0" "higashiagatsuma\0"
"isesaki\0" "itakura\0" "kanna\0" "katashina\0" "kawaba\0" "kiryu\0"
"kusatsu\0" "maebashi\0" "meiwa\0" "minakami\0" "naganohara\0" "nakanojo\0"
"nanmoku\0" "numata\0" "oizumi\0" "ozora\0" "shibukawa\0" "shimonita\0"
"shinto\0" "takasaki\0" "tamamura\0" "tatebayashi\0" "tomioka\0"
"tsukiyono\0" "tsumagoi\0" "yoshioka\0" "daiwa\0" "etajima\0" "fuchu\0"
"fukuyama\0" "hatsukaichi\0" "higashihiroshima\0" "hongo\0" "jinsekikogen\0"
"kaita\0" "kumano\0" "sagamihara\0" "onomichi\0" "otake\0" "sera\0"
"shinichi\0" "shobara\0" "takehara\0" "abashiri\0" "akabira\0" "aibetsu\0"
"akkeshi\0" "asahikawa\0" "ashibetsu\0" "ashoro\0" "assabu\0" "bibai\0"
"biei\0" "bifuka\0" "bihoro\0" "biratori\0" "chippubetsu\0" "chitose\0"
"ebetsu\0" "embetsu\0" "eniwa\0" "erimo\0" "esashi\0" "fukagawa\0"
"kamifurano\0" "furubira\0" "haboro\0" "hamatonbetsu\0" "hidaka\0"
"higashikagura\0" "higashikawa\0" "hiroo\0" "hokuryu\0" "hokuto\0"
"honbetsu\0" "horokanai\0" "horonobe\0" "imakane\0" "ishikari\0"
"iwamizawa\0" "iwanai\0" "kamikawa\0" "kamishihoro\0" "kamisunagawa\0"
"kamoenai\0" "kayabe\0" "kembuchi\0" "kikonai\0" "kimobetsu\0" "kitami\0"
"kiyosato\0" "koshimizu\0" "kunneppu\0" "kuriyama\0" "kuromatsunai\0"
"kushiro\0" "kutchan\0" "mashike\0" "matsumae\0" "mikasa\0" "minamifurano\0"
"mombetsu\0" "moseushi\0" "samukawa\0" "muroran\0" "naie\0" "nakasatsunai\0"
"nakatombetsu\0" "nanae\0" "nanporo\0" "nemuro\0" "niikappu\0" "nishiokoppe\0"
"noboribetsu\0" "obihiro\0" "obira\0" "oketo\0" "otaru\0" "otofuke\0"
"otoineppu\0" "rankoshi\0" "rebun\0" "rikubetsu\0" "rishiri\0" "rishirifuji\0"
"sarufutsu\0" "shakotan\0" "shari\0" "shibecha\0" "shikabe\0" "shikaoi\0"
"shimamaki\0" "shimokawa\0" "shinshinotsu\0" "shintoku\0" "shiranuka\0"
"shiraoi\0" "shiriuchi\0" "sobetsu\0" "taiki\0" "takasu\0" "takikawa\0"
"takinoue\0" "teshikaga\0" "tobetsu\0" "tohma\0" "tomakomai\0" "tomari\0"
"toya\0" "toyako\0" "toyotomi\0" "toyoura\0" "tsubetsu\0" "tsukigata\0"
"urakawa\0" "urausu\0" "utashinai\0" "wakkanai\0" "wassamu\0" "yakumo\0"
"yoichi\0" "aioi\0" "akashi\0" "amagasaki\0" "takasago\0" "minamiawaji\0"
"fukusaki\0" "goshiki\0" "harima\0" "himeji\0" "shinagawa\0" "kakogawa\0"
"kamigori\0" "kasai\0" "kawanishi\0" "miki\0" "nishinomiya\0" "sanda\0"
"sannan\0" "sasayama\0" "sayo\0" "shinonsen\0" "shiso\0" "matsumoto\0"
"taishi\0" "mitaka\0" "takarazuka\0" "takino\0" "kyotamba\0" "tatsuno\0"
"toyooka\0" "yabu\0" "miyashiro\0" "yoka\0" "atami\0" "bando\0"
"chikusei\0" "fujishiro\0" "hitachinaka\0" "hitachiomiya\0" "hitachiota\0"
"ebina\0" "inashiki\0" "iwama\0" "joso\0" "kamisu\0" "kasama\0"
"takashima\0" "kasumigaura\0" "miho\0" "moriya\0" "namegata\0" "oarai\0"
"edogawa\0" "omitama\0" "ryugasaki\0" "sakuragawa\0" "shimodate\0"
"shimotsuma\0" "shirosato\0" "suifu\0" "takahagi\0" "tamatsukuri\0"
"tomobe\0" "toride\0" "tsuchiura\0" "tsukuba\0" "uchihara\0" "ushiku\0"
"yawara\0" "yuki\0" "anamizu\0" "hakui\0" "hakusan\0" "ashikaga\0"
"kahoku\0" "kanazawa\0" "nakanoto\0" "nanao\0" "uchinomi\0" "nonoichi\0"
"ooshika\0" "suzu\0" "tsubata\0" "tsurugi\0" "uchinada\0" "fudai\0"
"fujisawa\0" "hanamaki\0" "hiraizumi\0" "iwaizumi\0" "joboji\0"
"kamaishi\0" "kanegasaki\0" "karumai\0" "kawai\0" "kitakami\0" "kuji\0"
"kuzumaki\0" "mizusawa\0" "morioka\0" "ninohe\0" "ofunato\0" "koshu\0"
"otsuchi\0" "rikuzentakata\0" "shizukuishi\0" "sumita\0" "tanohata\0"
"yahaba\0" "ayagawa\0" "higashikagawa\0" "kanonji\0" "kotohira\0"
"manno\0" "mitoyo\0" "naoshima\0" "sanuki\0" "tadotsu\0" "takamatsu\0"
"tonosho\0" "utazu\0" "zentsuji\0" "akune\0" "zamami\0" "hioki\0"
"kanoya\0" "kawanabe\0" "kinko\0" "kouyama\0" "makurazaki\0" "nakatane\0"
"nishinoomote\0" "soo\0" "tarumizu\0" "atsugi\0" "ayase\0" "chigasaki\0"
"hadano\0" "hakone\0" "hiratsuka\0" "isehara\0" "kaisei\0" "kamakura\0"
"kiyokawa\0" "matsuda\0" "minamiashigara\0" "miura\0" "nakai\0"
"ninomiya\0" "odawara\0" "kuroiso\0" "tsukui\0" "yamakita\0" "yokosuka\0"
"yugawara\0" "zushi\0" "geisei\0" "higashitsuno\0" "ebino\0" "kagami\0"
"ryokami\0" "muroto\0" "nahari\0" "nakamura\0" "nankoku\0" "nishitosa\0"
"niyodogawa\0" "otoyo\0" "otsuki\0" "sukumo\0" "susaki\0" "tosashimizu\0"
"umaji\0" "yasuda\0" "yusuhara\0" "kamiamakusa\0" "arao\0" "choyo\0"
"gyokuto\0" "kikuchi\0" "mashiki\0" "mifune\0" "minamata\0" "minamioguni\0"
"nagasu\0" "nishihara\0" "takamori\0" "yamaga\0" "yatsushiro\0"
"fukuchiyama\0" "higashiyama\0" "joyo\0" "kameoka\0" "kizu\0" "kyotanabe\0"
"kyotango\0" "maizuru\0" "minamiyamashiro\0" "miyazu\0" "muko\0"
"nagaokakyo\0" "nakagyo\0" "nantan\0" "oyamazaki\0" "sakyo\0" "seika\0"
"ujitawara\0" "wazuka\0" "yamashina\0" "yawata\0" "inabe\0" "kameyama\0"
"kawagoe\0" "kiho\0" "kisosaki\0" "kiwa\0" "komono\0" "kuwana\0"
"matsusaka\0" "minamiise\0" "misugi\0" "suzuka\0" "tado\0" "tamaki\0"
"toba\0" "ureshino\0" "watarai\0" "furukawa\0" "higashimatsushima\0"
"ishinomaki\0" "iwanuma\0" "kakuda\0" "marumori\0" "minamisanriku\0"
"murata\0" "natori\0" "ogawara\0" "onagawa\0" "rifu\0" "semine\0"
"shibata\0" "shichikashuku\0" "shikama\0" "shiogama\0" "shiroishi\0"
"tagajo\0" "taiwa\0" "saotome\0" "tomiya\0" "wakuya\0" "watari\0"
"yamamoto\0" "zao\0" "okaya\0" "gokase\0" "hyuga\0" "kadogawa\0"
"kawaminami\0" "kijo\0" "kitaura\0" "kobayashi\0" "kunitomi\0" "mimata\0"
"nichinan\0" "nishimera\0" "nobeoka\0" "saito\0" "shiiba\0" "shintomi\0"
"takaharu\0" "takanabe\0" "takazaki\0" "adachi\0" "agematsu\0" "kanan\0"
"aoki\0" "azumino\0" "chikuhoku\0" "chikuma\0" "chino\0" "fujimi\0"
"hakuba\0" "hiraya\0" "davvesiida\0" "iijima\0" "iiyama\0" "iizuna\0"
"ikusaka\0" "karuizawa\0" "kawakami\0" "kiso\0" "kitaaiki\0" "komagane\0"
"komoro\0" "matsukawa\0" "miasa\0" "minamiaiki\0" "minamimaki\0"
"minamiminowa\0" "miyada\0" "miyota\0" "mochizuki\0" "nagiso\0"
"nakano\0" "nozawaonsen\0" "obuse\0" "shinanomachi\0" "ookuwa\0"
"otari\0" "sakaki\0" "saku\0" "sakuho\0" "shimosuwa\0" "shiojiri\0"
"suzaka\0" "takagi\0" "tateshina\0" "togakushi\0" "togura\0" "ueda\0"
"yamanouchi\0" "yasaka\0" "yasuoka\0" "chijiwa\0" "shinkamigoto\0"
"hasami\0" "hirado\0" "isahaya\0" "kawatana\0" "kuchinotsu\0" "matsuura\0"
"omura\0" "saikai\0" "sasebo\0" "seihi\0" "shimabara\0" "togitsu\0"
"unzen\0" "ogose\0" "higashiyoshino\0" "ikaruga\0" "ikoma\0" "kamikitayama\0"
"kanmaki\0" "kashiba\0" "kashihara\0" "katsuragi\0" "koryo\0" "kamitsue\0"
"miyake\0" "nosegawa\0" "ouda\0" "oyodo\0" "sakurai\0" "sango\0"
"shimoichi\0" "shimokitayama\0" "shinjo\0" "soni\0" "tawaramoto\0"
"tenkawa\0" "tenri\0" "yamatotakada\0" "yamazoe\0" "gosen\0" "itoigawa\0"
"izumozaki\0" "joetsu\0" "kariwa\0" "kashiwazaki\0" "minamiuonuma\0"
"mitsuke\0" "muika\0" "murakami\0" "myoko\0" "nagaoka\0" "ojiya\0"
"sado\0" "seiro\0" "seirou\0" "sekikawa\0" "tainai\0" "tochio\0"
"tokamachi\0" "tsubame\0" "tsunan\0" "yahiko\0" "yuzawa\0" "beppu\0"
"bungoono\0" "bungotakada\0" "hasama\0" "hiji\0" "himeshima\0" "kokonoe\0"
"kuju\0" "kunisaki\0" "saiki\0" "taketa\0" "tsukumi\0" "usuki\0"
"yufu\0" "akaiwa\0" "asakuchi\0" "bizen\0" "hayashima\0" "maibara\0"
"kagamino\0" "kasaoka\0" "kumenan\0" "kurashiki\0" "maniwa\0" "misaki\0"
"inagi\0" "niimi\0" "nishiawakura\0" "satosho\0" "setouchi\0" "shoo\0"
"soja\0" "takahashi\0" "tamano\0" "yakage\0" "yonaguni\0" "ginowan\0"
"ginoza\0" "gushikami\0" "haebaru\0" "hirara\0" "iheya\0" "ishigaki\0"
"izena\0" "kadena\0" "kitadaito\0" "kitanakagusuku\0" "kumejima\0"
"kunigami\0" "minamidaito\0" "yonago\0" "nakijin\0" "nanjo\0" "ogimi\0"
"donna\0" "shimoji\0" "taketomi\0" "tarama\0" "tokashiki\0" "tomigusuku\0"
"tonaki\0" "urasoe\0" "uruma\0" "yaese\0" "yomitan\0" "yonabaru\0"
"abeno\0" "chihayaakasaka\0" "fujiidera\0" "habikino\0" "hannan\0"
"higashiosaka\0" "higashiyodogawa\0" "hirakata\0" "izumiotsu\0"
"izumisano\0" "kadoma\0" "kaizuka\0" "kashiwara\0" "katano\0" "kishiwada\0"
"kumatori\0" "matsubara\0" "sakaiminato\0" "minoh\0" "moriguchi\0"
"neyagawa\0" "osakasayama\0" "sennan\0" "settsu\0" "shijonawate\0"
"shimamoto\0" "suita\0" "tadaoka\0" "tajiri\0" "takaishi\0" "takatsuki\0"
"tondabayashi\0" "toyonaka\0" "toyono\0" "yao\0" "ariake\0" "fukudomi\0"
"genkai\0" "hamatama\0" "imari\0" "kamimine\0" "kanzaki\0" "karatsu\0"
"kitahata\0" "kiyama\0" "kouhoku\0" "kyuragi\0" "nishiarita\0" "taku\0"
"yoshinogari\0" "arakawa\0" "higashichichibu\0" "fujimino\0" "fukaya\0"
"hanno\0" "hanyu\0" "hasuda\0" "hatogaya\0" "hatoyama\0" "iruma\0"
"iwatsuki\0" "kamiizumi\0" "kamisato\0" "kasukabe\0" "kawaguchi\0"
"kawajima\0" "kazo\0" "kitamoto\0" "koshigaya\0" "kounosu\0" "kuki\0"
"kumagaya\0" "matsubushi\0" "minano\0" "moroyama\0" "nagatoro\0"
"namegawa\0" "niiza\0" "ogano\0" "okegawa\0" "ranzan\0" "sakado\0"
"satte\0" "shiraoka\0" "soka\0" "sugito\0" "toda\0" "tokigawa\0"
"tokorozawa\0" "tsurugashima\0" "urawa\0" "warabi\0" "yashio\0"
"yokoze\0" "yorii\0" "fujiyoshida\0" "yoshikawa\0" "yoshimi\0" "aisho\0"
"higashiomi\0" "hikone\0" "koka\0" "kosei\0" "moriyama\0" "nagahama\0"
"nishiazai\0" "notogawa\0" "omihachiman\0" "gotsu\0" "ritto\0" "ryuoh\0"
"torahime\0" "toyosato\0" "hamada\0" "higashiizumo\0" "hikimi\0"
"okuizumo\0" "kakinoki\0" "masuda\0" "nishinoshima\0" "ohda\0" "okinoshima\0"
"tamayu\0" "tsuwano\0" "unnan\0" "yasugi\0" "yatsuka\0" "fujieda\0"
"fujikawa\0" "fujinomiya\0" "fukuroi\0" "haibara\0" "hamamatsu\0"
"higashiizu\0" "iwata\0" "izunokuni\0" "kakegawa\0" "kannami\0"
"kawanehon\0" "kawazu\0" "kikugawa\0" "kosai\0" "makinohara\0" "matsuzaki\0"
"minamiizu\0" "morimachi\0" "nishiizu\0" "numazu\0" "omaezaki\0"
"shimada\0" "susono\0" "yaizu\0" "haga\0" "ichikai\0" "iwafune\0"
"kaminokawa\0" "kanuma\0" "karasuyama\0" "mashiko\0" "mibu\0" "moka\0"
"motegi\0" "nasu\0" "nasushiobara\0" "nikko\0" "nishikata\0" "ohtawara\0"
"shimotsuke\0" "shioya\0" "takanezawa\0" "tsuga\0" "ujiie\0" "utsunomiya\0"
"yaita\0" "itano\0" "matsushige\0" "mima\0" "mugi\0" "naruto\0"
"sanagochi\0" "shishikui\0" "wajiki\0" "akiruno\0" "akishima\0"
"aogashima\0" "bunkyo\0" "chofu\0" "fussa\0" "hachijo\0" "hachioji\0"
"hamura\0" "higashimurayama\0" "hinode\0" "hinohara\0" "itabashi\0"
"katsushika\0" "kiyose\0" "kodaira\0" "koganei\0" "kokubunji\0"
"komae\0" "kouzushima\0" "kunitachi\0" "meguro\0" "mizuho\0" "musashimurayama\0"
"musashino\0" "nerima\0" "ogasawara\0" "okutama\0" "nome\0" "toshima\0"
"setagaya\0" "shibuya\0" "shinjuku\0" "suginami\0" "sumida\0" "tachikawa\0"
"taito\0" "chizu\0" "kawahara\0" "kotoura\0" "misasa\0" "nanbu\0"
"fukumitsu\0" "funahashi\0" "johana\0" "kamiichi\0" "kurobe\0" "nakaniikawa\0"
"namerikawa\0" "nanto\0" "nyuzen\0" "oyabe\0" "taira\0" "takaoka\0"
"toga\0" "tonami\0" "unazuki\0" "arida\0" "aridagawa\0" "gobo\0"
"hashimoto\0" "hirogawa\0" "iwade\0" "kamitonda\0" "kinokawa\0"
"koya\0" "kozagawa\0" "kudoyama\0" "kushimoto\0" "shirahama\0" "taiji\0"
"yuasa\0" "yura\0" "funagata\0" "higashine\0" "kaminoyama\0" "mamurogawa\0"
"nagai\0" "nakayama\0" "nanyo\0" "obanazawa\0" "ohkura\0" "oishida\0"
"sagae\0" "sakata\0" "sakegawa\0" "shirataka\0" "takahata\0" "tendo\0"
"tozawa\0" "tsuruoka\0" "yamanobe\0" "yonezawa\0" "yuza\0" "iwakuni\0"
"kudamatsu\0" "mitou\0" "nagato\0" "shimonoseki\0" "shunan\0" "tabuse\0"
"tokuyama\0" "yuu\0" "doshi\0" "fuefuki\0" "hayakawa\0" "ichikawamisato\0"
"kofu\0" "kosuge\0" "minami-alps\0" "minobu\0" "nakamichi\0" "narusawa\0"
"nirasaki\0" "nishikatsura\0" "tabayama\0" "tsuru\0" "uenohara\0"
"yamanakako\0" "pharmaciens\0" "rep\0" "hitra\0" "busan\0" "chungbuk\0"
"chungnam\0" "daegu\0" "daejeon\0" "gangwon\0" "gwangju\0" "gyeongbuk\0"
"gyeonggi\0" "gyeongnam\0" "fhs\0" "incheon\0" "jeju\0" "jeonnam\0"
"seoul\0" "static\0" "azurewebsites\0" "cyon\0" "mypep\0" "assn\0"
"grp\0" "soc\0" "brasilia\0" "c66\0" "daplie\0" "myddns\0" "dnsfor\0"
"filegear\0" "hopto\0" "i234\0" "loginto\0" "myds\0" "noip\0" "soundcast\0"
"synology\0" "tcp4\0" "yombo\0" "localhost\0" "agriculture\0" "airguard\0"
"alabama\0" "alaska\0" "amber\0" "nativeamerican\0" "americana\0"
"americanantiques\0" "americanart\0" "brand\0" "annefrank\0" "anthro\0"
"anthropology\0" "usantiques\0" "aquarium\0" "arboretum\0" "archaeological\0"
"archaeology\0" "architecture\0" "artdeco\0" "artsandcrafts\0" "asmatart\0"
"assassination\0" "assisi\0" "astronomy\0" "atlanta\0" "austin\0"
"australia\0" "automotive\0" "axis\0" "badajoz\0" "eisenbahn\0"
"baltimore\0" "basel\0" "baths\0" "bauern\0" "beauxarts\0" "beeldengeluid\0"
"bellevue\0" "bergbau\0" "berkeley\0" "bern\0" "bilbao\0" "bill\0"
"birdart\0" "bonn\0" "botanical\0" "botanicalgarden\0" "botanicgarden\0"
"botany\0" "brandywinevalley\0" "brasil\0" "bristol\0" "british\0"
"britishcolumbia\0" "broadcast\0" "brunel\0" "brussel\0" "bruxelles\0"
"building\0" "burghof\0" "bushey\0" "cadaques\0" "california\0"
"cambridge\0" "canada\0" "capebreton\0" "carrier\0" "cartoonart\0"
"casadelamoneda\0" "castle\0" "castres\0" "celtic\0" "chattanooga\0"
"cheltenham\0" "chesapeakebay\0" "chicago\0" "children\0" "childrens\0"
"childrensgarden\0" "chiropractic\0" "chocolate\0" "christiansburg\0"
"cincinnati\0" "cinema\0" "circus\0" "civilisation\0" "civilization\0"
"civilwar\0" "clinton\0" "watchandclock\0" "coastaldefence\0" "coldwar\0"
"collection\0" "colonialwilliamsburg\0" "coloradoplateau\0" "columbus\0"
"communication\0" "posts-and-telecommunications\0" "computerhistory\0"
"contemporary\0" "contemporaryart\0" "convent\0" "copenhagen\0"
"corporation\0" "corvette\0" "costume\0" "uscountryestate\0" "county\0"
"cranbrook\0" "cultural\0" "culturalcenter\0" "usculture\0" "cyber\0"
"salvadordali\0" "dallas\0" "database\0" "usdecorativearts\0" "stateofdelaware\0"
"delmenhorst\0" "denmark\0" "detroit\0" "dinosaur\0" "discovery\0"
"dolls\0" "donostia\0" "durham\0" "eastcoast\0" "educational\0"
"egyptian\0" "elvendrell\0" "embroidery\0" "encyclopedic\0" "england\0"
"entomology\0" "environment\0" "environmentalconservation\0" "epilepsy\0"
"ethnology\0" "exeter\0" "exhibition\0" "farmstead\0" "field\0"
"figueres\0" "filatelia\0" "fineart\0" "finearts\0" "finland\0"
"flanders\0" "florida\0" "fortmissoula\0" "fortworth\0" "francaise\0"
"frankfurt\0" "franziskaner\0" "freemasonry\0" "freiburg\0" "fribourg\0"
"frog\0" "fundacio\0" "geelvinck\0" "gemological\0" "geology\0"
"georgia\0" "giessen\0" "glas\0" "gorge\0" "grandrapids\0" "graz\0"
"guernsey\0" "halloffame\0" "handson\0" "harvestcelebration\0" "hawaii\0"
"heimatunduhren\0" "hellas\0" "hembygdsforbund\0" "nationalheritage\0"
"histoire\0" "historical\0" "historicalsociety\0" "historichouses\0"
"historisch\0" "naturhistorisches\0" "ushistory\0" "horology\0"
"humanities\0" "illustration\0" "imageandsound\0" "indian\0" "indiana\0"
"indianapolis\0" "intelligence\0" "iron\0" "isleofman\0" "jamison\0"
"jefferson\0" "jerusalem\0" "jewish\0" "jewishart\0" "journalism\0"
"judaica\0" "judygarland\0" "juedisches\0" "juif\0" "karate\0" "kids\0"
"kunst\0" "kunstsammlung\0" "kunstunddesign\0" "labor\0" "labour\0"
"lajolla\0" "lancashire\0" "landes\0" "lans\0" "larsson\0" "lewismiller\0"
"uslivinghistory\0" "localhistory\0" "losangeles\0" "louvre\0" "loyalist\0"
"lucerne\0" "luxembourg\0" "luzern\0" "mallorca\0" "manchester\0"
"mansion\0" "mansions\0" "marburg\0" "maritime\0" "maritimo\0" "maryland\0"
"marylhurst\0" "medizinhistorisches\0" "meeres\0" "mesaverde\0"
"michigan\0" "midatlantic\0" "military\0" "windmill\0" "miners\0"
"mining\0" "minnesota\0" "missile\0" "modern\0" "moma\0" "monmouth\0"
"monticello\0" "montreal\0" "motorcycle\0" "muenchen\0" "muenster\0"
"muncie\0" "museet\0" "museumcenter\0" "museumvereniging\0" "nationalfirearms\0"
"naturalhistory\0" "naturalsciences\0" "nature\0" "natuurwetenschappen\0"
"naumburg\0" "naval\0" "nebraska\0" "newhampshire\0" "newjersey\0"
"newmexico\0" "newport\0" "newspaper\0" "newyork\0" "niepce\0" "norfolk\0"
"north\0" "nuernberg\0" "nuremberg\0" "nyny\0" "oceanographic\0"
"oceanographique\0" "omaha\0" "ontario\0" "openair\0" "oregon\0"
"oregontrail\0" "otago\0" "pacific\0" "paderborn\0" "palace\0" "paleo\0"
"palmsprings\0" "panama\0" "pasadena\0" "philadelphia\0" "philadelphiaarea\0"
"philately\0" "phoenix\0" "pilots\0" "planetarium\0" "plantation\0"
"plants\0" "plaza\0" "portal\0" "portland\0" "portlligat\0" "preservation\0"
"presidio\0" "fedoraproject\0" "pubol\0" "railroad\0" "railway\0"
"resistance\0" "riodejaneiro\0" "rochester\0" "rockart\0" "russia\0"
"saintlouis\0" "salzburg\0" "sandiego\0" "santabarbara\0" "santacruz\0"
"santafe\0" "saskatchewan\0" "satx\0" "savannahga\0" "schlesisches\0"
"schoenbrunn\0" "schokoladen\0" "schweiz\0" "science-fiction\0"
"scienceandhistory\0" "scienceandindustry\0" "sciencecenter\0" "sciencecenters\0"
"sciencehistory\0" "sciencesnaturelles\0" "scotland\0" "seaport\0"
"settlement\0" "settlers\0" "sherbrooke\0" "sibenik\0" "skole\0"
"sologne\0" "soundandvision\0" "southcarolina\0" "southwest\0" "square\0"
"stadt\0" "stalbans\0" "starnberg\0" "steiermark\0" "stpetersburg\0"
"stuttgart\0" "suisse\0" "surgeonshall\0" "surrey\0" "svizzera\0"
"sweden\0" "tank\0" "telekommunikation\0" "texas\0" "textile\0"
"timekeeping\0" "topology\0" "touch\0" "trolley\0" "trustee\0" "ulm\0"
"undersea\0" "usarts\0" "ushuaia\0" "versailles\0" "village\0" "virginia\0"
"virtual\0" "virtuel\0" "volkenkunde\0" "wallonie\0" "washingtondc\0"
"watch-and-clock\0" "western\0" "westfalen\0" "whaling\0" "wildlife\0"
"xn--9dbhblg6di\0" "xn--comunicaes-v6a2o\0" "xn--correios-e-telecomunicaes-ghc29a\0"
"xn--h1aegh\0" "xn--lns-qla\0" "yorkshire\0" "yosemite\0" "youth\0"
"zoological\0" "zoology\0" "blackbaudcdn\0" "boomla\0" "bounceme\0"
"broke-it\0" "buyshouses\0" "casacam\0" "cdn77\0" "cdn77-ssl\0"
"channelsdvr\0" "cloudapp\0" "cloudeity\0" "cloudfront\0" "cloudfunctions\0"
"cloudycluster\0" "cryptonomic\0" "debian\0" "dnsup\0" "does-it\0"
"dynathome\0" "dynu\0" "dynv6\0" "endofinternet\0" "fastly\0" "fastlylb\0"
"feste-ip\0" "flynnhosting\0" "from-az\0" "from-co\0" "from-la\0"
"from-ny\0" "gets-it\0" "ham-radio-op\0" "homeftp\0" "homeip\0"
"ipifony\0" "kicks-ass\0" "knx-server\0" "memset\0" "moonscale\0"
"mydissent\0" "myeffect\0" "mymediapc\0" "nhlfan\0" "now-dns\0"
"office-on-the\0" "ownip\0" "pgafan\0" "privatizehealthinsurance\0"
"redirectme\0" "schokokeks\0" "scrapper-site\0" "sells-it\0" "serveminecraft\0"
"static-access\0" "t3l3p0rt\0" "vpndns\0" "freetls\0" "alces\0"
"cistron\0" "demon\0" "hosting-cluster\0" "virtueeldomein\0" "aarborte\0"
"aejrie\0" "kafjord\0" "agdenes\0" "akershus\0" "aknoluokta\0" "akrehamn\0"
"alaheadju\0" "alesund\0" "algard\0" "alstahaug\0" "yalta\0" "alvdal\0"
"amli\0" "amot\0" "andasuolo\0" "andebu\0" "sandoy\0" "lardal\0"
"aremark\0" "arendal\0" "aseral\0" "asker\0" "askoy\0" "askvoll\0"
"asnes\0" "audnedaln\0" "aukra\0" "aure\0" "aurland\0" "aurskog-holand\0"
"austevoll\0" "austrheim\0" "averoy\0" "badaddja\0" "bahcavuotna\0"
"bahccavuotna\0" "baidar\0" "bajddar\0" "balestrand\0" "ballangen\0"
"balsfjord\0" "bamble\0" "bardu\0" "barum\0" "batsfjord\0" "bearalvahki\0"
"beardu\0" "beiarn\0" "eidsberg\0" "berlevag\0" "bievat\0" "bindal\0"
"birkenes\0" "bjarkoy\0" "bjerkreim\0" "bodo\0" "bomlo\0" "bremanger\0"
"bronnoy\0" "bronnoysund\0" "brumunddal\0" "bryne\0" "budejju\0"
"buskerud\0" "bygland\0" "bykle\0" "cahcesuolo\0" "davvenjarga\0"
"deatnu\0" "dep\0" "dielddanuorri\0" "divtasvuodna\0" "divttasvuotna\0"
"dovre\0" "drangedal\0" "drobak\0" "dyroy\0" "egersund\0" "hareid\0"
"eidfjord\0" "eidskog\0" "eidsvoll\0" "eigersund\0" "elverum\0"
"enebakk\0" "engerdal\0" "etnedal\0" "evenassi\0" "evenes\0" "evje-og-hornnes\0"
"farsund\0" "fauske\0" "fetsund\0" "finnoy\0" "fitjar\0" "fjaler\0"
"fjell\0" "flakstad\0" "flatanger\0" "flekkefjord\0" "flesberg\0"
"flora\0" "floro\0" "folkebibl\0" "folldal\0" "forde\0" "forsand\0"
"fosnes\0" "frana\0" "fredrikstad\0" "frei\0" "frogn\0" "froland\0"
"frosta\0" "froya\0" "fuoisku\0" "fuossko\0" "fylkesbibl\0" "fyresdal\0"
"gaivuotna\0" "galsa\0" "gamvik\0" "gangaviika\0" "gaular\0" "gausdal\0"
"giehtavuoatna\0" "gildeskal\0" "giske\0" "gjemnes\0" "gjerdrum\0"
"gjerstad\0" "gjesdal\0" "gjovik\0" "gloppen\0" "gol\0" "gran\0"
"grane\0" "gratangen\0" "grimstad\0" "grong\0" "grue\0" "gulen\0"
"guovdageaidnu\0" "habmer\0" "hadsel\0" "hagebostad\0" "halden\0"
"halsa\0" "hamaroy\0" "hammarfeasta\0" "hammerfest\0" "hapmir\0"
"haram\0" "harstad\0" "hasvik\0" "hattfjelldal\0" "haugesund\0"
"hedmark\0" "hemne\0" "hemnes\0" "hemsedal\0" "sauherad\0" "hjartdal\0"
"hjelmeland\0" "hobol\0" "hokksund\0" "hol\0" "hole\0" "holmestrand\0"
"holtalen\0" "honefoss\0" "hornindal\0" "horten\0" "hoyanger\0"
"hoylandet\0" "hurdal\0" "hurum\0" "hvaler\0" "hyllestad\0" "ibestad\0"
"idrett\0" "inderoy\0" "iveland\0" "jan-mayen\0" "jessheim\0" "jevnaker\0"
"jolster\0" "jondal\0" "jorpeland\0" "karasjohka\0" "karasjok\0"
"karlsoy\0" "karmoy\0" "kautokeino\0" "kirkenes\0" "klabu\0" "kommune\0"
"kongsberg\0" "kongsvinger\0" "kopervik\0" "kraanghke\0" "kragero\0"
"kristiansand\0" "kristiansund\0" "krodsherad\0" "krokstadelva\0"
"kvafjord\0" "kvalsund\0" "kvam\0" "kvanangen\0" "kvinesdal\0" "kvinnherad\0"
"kviteseid\0" "kvitsoy\0" "laakesvuemie\0" "lahppi\0" "langevag\0"
"larvik\0" "lavagis\0" "lavangen\0" "leangaviika\0" "lebesby\0"
"leikanger\0" "leirfjord\0" "leirvik\0" "dlugoleka\0" "leksvik\0"
"lenvik\0" "lerdal\0" "lesja\0" "levanger\0" "lierne\0" "lillehammer\0"
"lillesand\0" "lindas\0" "lindesnes\0" "loabat\0" "lodingen\0" "loppa\0"
"lorenskog\0" "loten\0" "solund\0" "lunner\0" "luroy\0" "lyngdal\0"
"lyngen\0" "malatvuopmi\0" "malvik\0" "mandal\0" "marker\0" "marnardal\0"
"masfjorden\0" "matta-varjjat\0" "meldal\0" "melhus\0" "meloy\0"
"meraker\0" "midsund\0" "midtre-gauldal\0" "mjondalen\0" "mo-i-rana\0"
"moareke\0" "modalen\0" "modum\0" "molde\0" "more-og-romsdal\0"
"mosjoen\0" "moskenes\0" "mosvik\0" "muosat\0" "naamesjevuemie\0"
"namdalseid\0" "namsos\0" "namsskogan\0" "nannestad\0" "naroy\0"
"narviika\0" "narvik\0" "naustdal\0" "navuotna\0" "nedre-eiker\0"
"nesna\0" "nesodden\0" "nesoddtangen\0" "nesseby\0" "nesset\0" "nissedal\0"
"nittedal\0" "nord-aurdal\0" "nord-fron\0" "nord-odal\0" "norddal\0"
"nordkapp\0" "nordland\0" "nordre-land\0" "nordreisa\0" "nore-og-uvdal\0"
"notodden\0" "notteroy\0" "odda\0" "oksnes\0" "omasvuotna\0" "oppdal\0"
"oppegard\0" "orkanger\0" "orkdal\0" "orskog\0" "orsta\0" "oslo\0"
"osoyro\0" "osteroy\0" "ostfold\0" "ostre-toten\0" "overhalla\0"
"ovre-eiker\0" "oyer\0" "oygarden\0" "oystre-slidre\0" "porsanger\0"
"porsangu\0" "porsgrunn\0" "radoy\0" "rahkkeravju\0" "raholt\0"
"raisa\0" "rakkestad\0" "ralingen\0" "randaberg\0" "rauma\0" "rendalen\0"
"rennebu\0" "rennesoy\0" "rindal\0" "ringebu\0" "ringerike\0" "ringsaker\0"
"risor\0" "rissa\0" "roan\0" "rodoy\0" "rollag\0" "tromsa\0" "romskog\0"
"roros\0" "rost\0" "royken\0" "royrvik\0" "ruovat\0" "rygge\0" "salangen\0"
"saltdal\0" "samnanger\0" "sandefjord\0" "sandnes\0" "sandnessjoen\0"
"sauda\0" "selbu\0" "selje\0" "seljord\0" "siellak\0" "sigdal\0"
"siljan\0" "sirdal\0" "skanit\0" "skanland\0" "skaun\0" "skedsmo\0"
"skedsmokorset\0" "skien\0" "skierva\0" "skjak\0" "skjervoy\0" "skodje\0"
"slattum\0" "smola\0" "snaase\0" "snasa\0" "snillfjord\0" "snoasa\0"
"sogndal\0" "sogne\0" "sokndal\0" "sola\0" "somna\0" "sondre-land\0"
"songdalen\0" "sor-aurdal\0" "sor-fron\0" "sor-odal\0" "sor-varanger\0"
"sorfold\0" "sorreisa\0" "sortland\0" "sorum\0" "spjelkavik\0" "spydeberg\0"
"stange\0" "stat\0" "stathelle\0" "stavanger\0" "stavern\0" "steigen\0"
"steinkjer\0" "stjordal\0" "stjordalshalsen\0" "stokke\0" "stor-elvdal\0"
"stord\0" "stordal\0" "storfjord\0" "stranda\0" "sula\0" "suldal\0"
"sunndal\0" "surnadal\0" "svalbard\0" "sveio\0" "svelvik\0" "sykkylven\0"
"tananger\0" "telemark\0" "tingvoll\0" "tinn\0" "tjeldsund\0" "tjome\0"
"tolga\0" "tonsberg\0" "torsken\0" "trana\0" "tranby\0" "tranoy\0"
"troandin\0" "trogstad\0" "tromso\0" "trondheim\0" "trysil\0" "tvedestrand\0"
"tydal\0" "tynset\0" "tysfjord\0" "tysnes\0" "tysvar\0" "ullensaker\0"
"ullensvang\0" "ulvik\0" "unjarga\0" "utsira\0" "vaapste\0" "vadso\0"
"vaga\0" "vagan\0" "vagsoy\0" "vaksdal\0" "valle\0" "vanylven\0"
"vardo\0" "varggat\0" "varoy\0" "vefsn\0" "vega\0" "vegarshei\0"
"vennesla\0" "verdal\0" "verran\0" "vestby\0" "vestfold\0" "vestnes\0"
"vestre-slidre\0" "vestre-toten\0" "vestvagoy\0" "vevelstad\0" "vikna\0"
"vindafjord\0" "voagat\0" "volda\0" "voss\0" "vossevangen\0" "xn--andy-ira\0"
"xn--asky-ira\0" "xn--aurskog-hland-jnb\0" "xn--avery-yua\0" "xn--bdddj-mrabd\0"
"xn--bearalvhki-y4a\0" "xn--berlevg-jxa\0" "xn--bhcavuotna-s4a\0"
"xn--bhccavuotna-k7a\0" "xn--bidr-5nac\0" "xn--bjarky-fya\0" "xn--bjddar-pta\0"
"xn--blt-elab\0" "xn--bmlo-gra\0" "xn--bod-2na\0" "xn--brnny-wuac\0"
"xn--brnnysund-m8ac\0" "xn--brum-voa\0" "xn--btsfjord-9za\0" "xn--davvenjrga-y4a\0"
"xn--dnna-gra\0" "xn--drbak-wua\0" "xn--dyry-ira\0" "xn--eveni-0qa01ga\0"
"xn--finny-yua\0" "xn--fjord-lra\0" "xn--fl-zia\0" "xn--flor-jra\0"
"xn--frde-gra\0" "xn--frna-woa\0" "xn--frya-hra\0" "xn--ggaviika-8ya47h\0"
"xn--gildeskl-g0a\0" "xn--givuotna-8ya\0" "xn--gjvik-wua\0" "xn--gls-elac\0"
"xn--h-2fa\0" "xn--hbmer-xqa\0" "xn--hcesuolo-7ya35b\0" "xn--hgebostad-g3a\0"
"xn--hmmrfeasta-s4ac\0" "xn--hnefoss-q1a\0" "xn--hobl-ira\0" "xn--holtlen-hxa\0"
"xn--hpmir-xqa\0" "xn--hyanger-q1a\0" "xn--hylandet-54a\0" "xn--indery-fya\0"
"xn--jlster-bya\0" "xn--jrpeland-54a\0" "xn--karmy-yua\0" "xn--kfjord-iua\0"
"xn--klbu-woa\0" "xn--koluokta-7ya57h\0" "xn--krager-gya\0" "xn--kranghke-b0a\0"
"xn--krdsherad-m8a\0" "xn--krehamn-dxa\0" "xn--krjohka-hwab49j\0"
"xn--ksnes-uua\0" "xn--kvfjord-nxa\0" "xn--kvitsy-fya\0" "xn--kvnangen-k0a\0"
"xn--l-1fa\0" "xn--laheadju-7ya\0" "xn--langevg-jxa\0" "xn--ldingen-q1a\0"
"xn--leagaviika-52b\0" "xn--lesund-hua\0" "xn--lgrd-poac\0" "xn--lhppi-xqa\0"
"xn--linds-pra\0" "xn--loabt-0qa\0" "xn--lrdal-sra\0" "xn--lrenskog-54a\0"
"xn--lt-liac\0" "xn--lten-gra\0" "xn--lury-ira\0" "xn--mely-ira\0"
"xn--merker-kua\0" "xn--mjndalen-64a\0" "xn--mlatvuopmi-s4a\0" "xn--mli-tla\0"
"xn--mlselv-iua\0" "xn--moreke-jua\0" "xn--mosjen-eya\0" "xn--mot-tla\0"
"xn--mre-og-romsdal-qqb\0" "xn--msy-ula0h\0" "xn--mtta-vrjjat-k7af\0"
"xn--muost-0qa\0" "xn--nry-yla5g\0" "xn--nttery-byae\0" "xn--nvuotna-hwa\0"
"xn--oppegrd-ixa\0" "xn--ostery-fya\0" "xn--osyro-wua\0" "xn--porsgu-sta26f\0"
"xn--rady-ira\0" "xn--rde-ula\0" "xn--rennesy-v1a\0" "xn--rholt-mra\0"
"xn--risa-5na\0" "xn--risr-ira\0" "xn--rland-uua\0" "xn--rlingen-mxa\0"
"xn--rmskog-bya\0" "xn--rros-gra\0" "xn--rskog-uua\0" "xn--rst-0na\0"
"xn--rsta-fra\0" "xn--ryken-vua\0" "xn--ryrvik-bya\0" "xn--s-1fa\0"
"xn--sandy-yua\0" "xn--seral-lra\0" "xn--sgne-gra\0" "xn--skierv-uta\0"
"xn--skjervy-v1a\0" "xn--skjk-soa\0" "xn--sknit-yqa\0" "xn--sknland-fxa\0"
"xn--slat-5na\0" "xn--slt-elab\0" "xn--smla-hra\0" "xn--smna-gra\0"
"xn--snase-nra\0" "xn--sndre-land-0cb\0" "xn--snes-poa\0" "xn--snsa-roa\0"
"xn--sr-aurdal-l8a\0" "xn--sr-fron-q1a\0" "xn--sr-odal-q1a\0" "xn--sr-varanger-ggb\0"
"xn--srfold-bya\0" "xn--srreisa-q1a\0" "xn--srum-gra\0" "xn--stfold-9xa\0"
"xn--stjrdal-s1a\0" "xn--stjrdalshalsen-sqb\0" "xn--stre-toten-zcb\0"
"xn--tjme-hra\0" "xn--tnsberg-q1a\0" "xn--trany-yua\0" "xn--trgstad-r1a\0"
"xn--trna-woa\0" "xn--troms-zua\0" "xn--tysvr-vra\0" "xn--unjrga-rta\0"
"xn--vads-jra\0" "xn--vard-jra\0" "xn--vegrshei-c0a\0" "xn--vestvgy-ixa6o\0"
"xn--vg-yiab\0" "xn--vgan-qoa\0" "xn--vgsy-qoa0j\0" "xn--vre-eiker-k8a\0"
"xn--vrggt-xqad\0" "xn--vry-yla5g\0" "xn--yer-zna\0" "xn--ygarden-p1a\0"
"xn--ystre-slidre-ujb\0" "wios\0" "xn--vler-qoa\0" "heroy\0" "sande\0"
"xn--b-5ga\0" "xn--hery-ira\0" "merseine\0" "shacknet\0" "govt\0"
"maori\0" "xn--mori-qsa\0" "accesscam\0" "amune\0" "blogsite\0"
"bmoattachments\0" "boldlygoingnowhere\0" "cable-modem\0" "certmgr\0"
"collegefan\0" "couchpotatofries\0" "duckdns\0" "dvrdns\0" "dynserv\0"
"endoftheinternet\0" "fedorainfracloud\0" "fedorapeople\0" "freeddns\0"
"from-me\0" "game-host\0" "hepforge\0" "homedns\0" "is-a-bruinsfan\0"
"is-a-candidate\0" "is-a-celticsfan\0" "is-a-knight\0" "is-a-linux-user\0"
"is-a-patsfan\0" "is-a-soxfan\0" "is-found\0" "is-lost\0" "is-saved\0"
"is-very-bad\0" "is-very-evil\0" "is-very-good\0" "is-very-nice\0"
"is-very-sweet\0" "misconfused\0" "mozilla-iot\0" "my-firewall\0"
"myfirewall\0" "mywire\0" "nflfan\0" "pimienta\0" "poivron\0" "potager\0"
"read-books\0" "readmyblog\0" "sellsyourhome\0" "stuff-4-sale\0"
"sweetpepper\0" "tunk\0" "ufcfan\0" "uklugs\0" "webredirect\0" "wmflabs\0"
"zapto\0" "tele\0" "rsc\0" "origin\0" "q-a\0" "gok\0" "augustow\0"
"babia-gora\0" "bedzin\0" "beep\0" "beskidy\0" "bialowieza\0" "bialystok\0"
"bielawa\0" "bieszczady\0" "boleslawiec\0" "bydgoszcz\0" "bytom\0"
"cieszyn\0" "czest\0" "elblag\0" "vologda\0" "gdansk\0" "gdynia\0"
"gliwice\0" "glogow\0" "gmina\0" "gniezno\0" "gorlice\0" "grajewo\0"
"ilawa\0" "jaworzno\0" "jelenia-gora\0" "jgora\0" "kalisz\0" "karpacz\0"
"kartuzy\0" "kaszuby\0" "katowice\0" "kazimierz-dolny\0" "kepno\0"
"ketrzyn\0" "klodzko\0" "kobierzyce\0" "kolobrzeg\0" "konin\0" "konskowola\0"
"krakow\0" "kutno\0" "lapy\0" "lebork\0" "legnica\0" "lezajsk\0"
"limanowa\0" "lomza\0" "lubin\0" "lukow\0" "malbork\0" "malopolska\0"
"mazowsze\0" "mazury\0" "miasta\0" "mielec\0" "mielno\0" "mragowo\0"
"naklo\0" "nowaruda\0" "nysa\0" "olawa\0" "olecko\0" "olkusz\0"
"olsztyn\0" "opoczno\0" "opole\0" "ostroda\0" "ostroleka\0" "ostrowiec\0"
"pila\0" "podhale\0" "podlasie\0" "polkowice\0" "pomorskie\0" "pomorze\0"
"powiat\0" "poznan\0" "prochowice\0" "pruszkow\0" "przeworsk\0"
"pulawy\0" "radom\0" "rawa-maz\0" "rybnik\0" "rzeszow\0" "sanok\0"
"sejny\0" "sklep\0" "skoczow\0" "slask\0" "slupsk\0" "sopot\0" "sosnowiec\0"
"stalowa-wola\0" "starachowice\0" "stargard\0" "suwalki\0" "swidnica\0"
"swiebodzin\0" "swinoujscie\0" "szczecin\0" "szczytno\0" "szkola\0"
"targi\0" "tarnobrzeg\0" "tgory\0" "tourism\0" "turek\0" "turystyka\0"
"tychy\0" "ustka\0" "walbrzych\0" "warmia\0" "warszawa\0" "wegrow\0"
"wielun\0" "wloclawek\0" "wodzislaw\0" "wolomin\0" "wroc\0" "zachpomor\0"
"zagan\0" "zakopane\0" "zarow\0" "zgora\0" "zgorzelec\0" "griw\0"
"kmpsp\0" "konsulat\0" "kppsp\0" "kwp\0" "kwpsp\0" "mup\0" "oirm\0"
"oum\0" "pinb\0" "piw\0" "psse\0" "pup\0" "sdn\0" "starostwo\0"
"ugim\0" "umig\0" "upow\0" "wzmiuw\0" "uzs\0" "wif\0" "wiih\0" "witd\0"
"wiw\0" "wuoz\0" "zp\0" "test\0" "isla\0" "dnstrace\0" "jur\0" "bci\0"
"belau\0" "x443\0" "clan\0" "adygeya\0" "bashkiria\0" "cldmail\0"
"dagestan\0" "grozny\0" "kalmykia\0" "kustanai\0" "marine\0" "mordovia\0"
"myjino\0" "mytis\0" "nalchik\0" "nov\0" "pyatigorsk\0" "ras\0"
"vladikavkaz\0" "vladimir\0" "landing\0" "spectrum\0" "vps\0" "development\0"
"fhsk\0" "fhv\0" "komforb\0" "kommunalforbund\0" "komvux\0" "lanbib\0"
"naturbruksgymn\0" "parti\0" "hashbang\0" "platform\0" "byen\0"
"platformsh\0" "univ\0" "stackspace\0" "uber\0" "xs4all\0" "consulado\0"
"embaixada\0" "noho\0" "principe\0" "abkhazia\0" "aktyubinsk\0"
"arkhangelsk\0" "armenia\0" "ashgabad\0" "azerbaijan\0" "balashov\0"
"bryansk\0" "bukhara\0" "chimkent\0" "east-kazakhstan\0" "ivanovo\0"
"jambyl\0" "kaluga\0" "karacol\0" "karaganda\0" "karelia\0" "khakassia\0"
"krasnodar\0" "kurgan\0" "lenug\0" "mangyshlak\0" "murmansk\0" "navoi\0"
"north-kazakhstan\0" "obninsk\0" "penza\0" "pokrovsk\0" "sochi\0"
"tashkent\0" "termez\0" "togliatti\0" "troitsk\0" "tselinograd\0"
"tula\0" "tuva\0" "knightpoint\0" "agrinet\0" "defense\0" "edunet\0"
"rnrt\0" "vpnplus\0" "ntdll\0" "bel\0" "kep\0" "better-than\0" "on-the-web\0"
"worse-than\0" "xn--czrw28b\0" "xn--zf0ao64a\0" "mymailer\0" "cherkassy\0"
"cherkasy\0" "chernivtsi\0" "chernovtsy\0" "crimea\0" "dnepropetrovsk\0"
"dnipropetrovsk\0" "dominic\0" "donetsk\0" "dp\0" "ivano-frankivsk\0"
"kharkiv\0" "kharkov\0" "kherson\0" "khmelnitskiy\0" "khmelnytskyi\0"
"kiev\0" "kirovograd\0" "krym\0" "kv\0" "kyiv\0" "lugansk\0" "lutsk\0"
"lviv\0" "mykolaiv\0" "nikolaev\0" "odessa\0" "poltava\0" "rivne\0"
"rovno\0" "sebastopol\0" "sevastopol\0" "ternopil\0" "uzhgorod\0"
"vinnica\0" "vinnytsia\0" "volyn\0" "zaporizhzhe\0" "zaporizhzhia\0"
"zhitomir\0" "zhytomyr\0" "nhs\0" "police\0" "gwiddle\0" "nh-serv\0"
"service\0" "glug\0" "golffan\0" "is-by\0" "land-4-sale\0" "nsn\0"
"pointto\0" "chtr\0" "paroch\0" "ann-arbor\0" "dst\0" "eaton\0"
"washtenaw\0" "gub\0" "e12\0" "cloud66\0" "mypets\0" "xn--80au\0"
"xn--90azh\0" "xn--d1at\0" "xn--o1ac\0" "xn--o1ach\0" "xn--12c1fe0br\0"
"xn--12cfi8ixb8l\0" "xn--12co0c3b4eva\0" "xn--h3cuzk1di\0" "xn--m3ch0j3a\0"
"xn--o3cyx2a\0" "crafting\0" "agric\0" "grondar\0" "triton\0" "";

static const struct TrieNode kNodeTable[] = {
  {     0,     0,     0, 1 },  /* aaa */
  {     4,     0,     0, 1 },  /* aarp */
  {     9,     0,     0, 1 },  /* abarth */
  {    16,     0,     0, 1 },  /* abb */
  {    20,     0,     0, 1 },  /* abbott */
  {    27,     0,     0, 1 },  /* abbvie */
  {    34,     0,     0, 1 },  /* abc */
  {    38,     0,     0, 1 },  /* able */
  {    43,     0,     0, 1 },  /* abogado */
  {    51,     0,     0, 1 },  /* abudhabi */
  {    62,  3904,     6, 1 },  /* ac */
  {    65,  3910,     1, 1 },  /* academy */
  {    73,     0,     0, 1 },  /* accenture */
  {    89,     0,     0, 1 },  /* accountant */
  {   100,     0,     0, 1 },  /* accountants */
  {   112,     0,     0, 1 },  /* aco */
  {   121,     0,     0, 1 },  /* active */
  {   134,     0,     0, 1 },  /* actor */
  {   141,  3911,     1, 1 },  /* ad */
  {    60,     0,     0, 1 },  /* adac */
  {   144,     0,     0, 1 },  /* ads */
  {   148,     0,     0, 1 },  /* adult */
  {   157,  3912,     9, 1 },  /* ae */
  {   160,     0,     0, 1 },  /* aeg */
  {   164,  3921,    87, 1 },  /* aero */
  {   169,     0,     0, 1 },  /* aetna */
  {   191,  4008,     6, 1 },  /* af */
  {   194,     0,     0, 1 },  /* afamilycompany */
  {   209,     0,     0, 1 },  /* afl */
  {   217,     0,     0, 1 },  /* africa */
  {   226,  4014,     5, 1 },  /* ag */
  {   229,     0,     0, 1 },  /* agakhan */
  {   237,     0,     0, 1 },  /* agency */
  {   247,  4019,     5, 1 },  /* ai */
  {   250,     0,     0, 1 },  /* aig */
  {   255,     0,     0, 1 },  /* aigo */
  {   260,     0,     0, 1 },  /* airbus */
  {   267,     0,     0, 1 },  /* airforce */
  {   276,     0,     0, 1 },  /* airtel */
  {   283,     0,     0, 1 },  /* akdn */
  {   290,  4024,     8, 1 },  /* al */
  {   293,     0,     0, 1 },  /* alfaromeo */
  {   303,     0,     0, 1 },  /* alibaba */
  {   311,     0,     0, 1 },  /* alipay */
  {   318,     0,     0, 1 },  /* allfinanz */
  {   328,     0,     0, 1 },  /* allstate */
  {   337,     0,     0, 1 },  /* ally */
  {   342,     0,     0, 1 },  /* alsace */
  {   349,     0,     0, 1 },  /* alstom */
  {   358,  4032,     1, 1 },  /* am */
  {   361,     0,     0, 1 },  /* americanexpress */
  {   377,     0,     0, 1 },  /* americanfamily */
  {   395,     0,     0, 1 },  /* amex */
  {   400,     0,     0, 1 },  /* amfam */
  {   406,     0,     0, 1 },  /* amica */
  {   412,     0,     0, 1 },  /* amsterdam */
  {   422,     0,     0, 1 },  /* analytics */
  {   432,     0,     0, 1 },  /* android */
  {   440,     0,     0, 1 },  /* anquan */
  {   324,     0,     0, 1 },  /* anz */
  {   448,  4033,     6, 1 },  /* ao */
  {   451,     0,     0, 1 },  /* aol */
  {   455,     0,     0, 1 },  /* apartments */
  {   468,  4039,     1, 1 },  /* app */
  {   472,     0,     0, 1 },  /* apple */
  {   480,     0,     0, 1 },  /* aq */
  {   483,     0,     0, 1 },  /* aquarelle */
  {   494,  1555,    10, 1 },  /* ar */
  {   497,     0,     0, 1 },  /* arab */
  {   502,     0,     0, 1 },  /* aramco */
  {   509,     0,     0, 1 },  /* archi */
  {   515,     0,     0, 1 },  /* army */
  {   520,  4040,     6, 1 },  /* arpa */
  {   527,     0,     0, 1 },  /* art */
  {   531,     0,     0, 1 },  /* arte */
  {   537,  4046,     1, 1 },  /* as */
  {   540,     0,     0, 1 },  /* asda */
  {   545,  4047,     1, 1 },  /* asia */
  {   550,     0,     0, 1 },  /* associates */
  {   562,  1565,    15, 1 },  /* at */
  {   565,     0,     0, 1 },  /* athleta */
  {   573,     0,     0, 1 },  /* attorney */
  {   584,  1585,    18, 1 },  /* au */
  {   587,     0,     0, 1 },  /* auction */
  {   595,     0,     0, 1 },  /* audi */
  {   600,     0,     0, 1 },  /* audible */
  {   608,     0,     0, 1 },  /* audio */
  {   614,     0,     0, 1 },  /* auspost */
  {   622,     0,     0, 1 },  /* author */
  {   629,     0,     0, 1 },  /* auto */
  {   634,     0,     0, 1 },  /* autos */
  {   640,     0,     0, 1 },  /* avianca */
  {   649,  4062,     1, 1 },  /* aw */
  {   658,     0,     0, 1 },  /* aws */
  {   663,     0,     0, 1 },  /* ax */
  {   666,     0,     0, 1 },  /* axa */
  {   671,  4063,    12, 1 },  /* az */
  {   682,     0,     0, 1 },  /* azure */
  {   308,  4075,     7, 1 },  /* ba */
  {   692,     0,     0, 1 },  /* baby */
  {   697,     0,     0, 1 },  /* baidu */
  {   392,     0,     0, 1 },  /* banamex */
  {   703,     0,     0, 1 },  /* bananarepublic */
  {   725,     0,     0, 1 },  /* band */
  {   731,     0,     0, 1 },  /* bank */
  {   736,     0,     0, 1 },  /* bar */
  {   740,     0,     0, 1 },  /* barcelona */
  {   750,     0,     0, 1 },  /* barclaycard */
  {   762,     0,     0, 1 },  /* barclays */
  {   771,     0,     0, 1 },  /* barefoot */
  {   780,     0,     0, 1 },  /* bargains */
  {   789,     0,     0, 1 },  /* baseball */
  {   798,     0,     0, 1 },  /* basketball */
  {   809,     0,     0, 1 },  /* bauhaus */
  {   817,     0,     0, 1 },  /* bayern */
  {    17,  4082,    10, 1 },  /* bb */
  {   824,     0,     0, 1 },  /* bbc */
  {   828,     0,     0, 1 },  /* bbt */
  {   832,     0,     0, 1 },  /* bbva */
  {   837,     0,     0, 1 },  /* bcg */
  {   841,     0,     0, 1 },  /* bcn */
  {   855,  4048,     1, 0 },  /* bd */
  {   860,  1603,     4, 1 },  /* be */
  {   863,     0,     0, 1 },  /* beats */
  {   869,     0,     0, 1 },  /* beauty */
  {   881,     0,     0, 1 },  /* beer */
  {   886,     0,     0, 1 },  /* bentley */
  {   894,     0,     0, 1 },  /* berlin */
  {   901,     0,     0, 1 },  /* best */
  {   906,     0,     0, 1 },  /* bestbuy */
  {   914,     0,     0, 1 },  /* bet */
  {   928,  4046,     1, 1 },  /* bf */
  {   932,  4092,    38, 1 },  /* bg */
  {   937,  4130,     5, 1 },  /* bh */
  {   940,     0,     0, 1 },  /* bharti */
  {    57,  4135,     5, 1 },  /* bi */
  {   951,     0,     0, 1 },  /* bible */
  {   957,     0,     0, 1 },  /* bid */
  {   961,     0,     0, 1 },  /* bike */
  {   970,     0,     0, 1 },  /* bing */
  {   975,     0,     0, 1 },  /* bingo */
  {   981,     0,     0, 1 },  /* bio */
  {   986,  4140,    12, 1 },  /* biz */
  {   990,  4152,     4, 1 },  /* bj */
  {   993,     0,     0, 1 },  /* black */
  {   999,     0,     0, 1 },  /* blackfriday */
  {  1011,     0,     0, 1 },  /* blanco */
  {  1018,     0,     0, 1 },  /* blockbuster */
  {  1035,     0,     0, 1 },  /* blog */
  {  1040,     0,     0, 1 },  /* bloomberg */
  {  1050,     0,     0, 1 },  /* blue */
  {  1056,  4130,     5, 1 },  /* bm */
  {  1059,     0,     0, 1 },  /* bms */
  {  1063,     0,     0, 1 },  /* bmw */
  {  1068,  4048,     1, 0 },  /* bn */
  {  1071,     0,     0, 1 },  /* bnl */
  {  1075,     0,     0, 1 },  /* bnpparibas */
  {  1087,  4156,    41, 1 },  /* bo */
  {  1090,     0,     0, 1 },  /* boats */
  {  1096,     0,     0, 1 },  /* boehringer */
  {  1107,     0,     0, 1 },  /* bofa */
  {  1112,     0,     0, 1 },  /* bom */
  {  1116,     0,     0, 1 },  /* bond */
  {  1121,     0,     0, 1 },  /* boo */
  {  1125,     0,     0, 1 },  /* book */
  {  1130,     0,     0, 1 },  /* booking */
  {  1138,     0,     0, 1 },  /* bosch */
  {  1144,     0,     0, 1 },  /* bostik */
  {  1151,     0,     0, 1 },  /* boston */
  {  1158,     0,     0, 1 },  /* bot */
  {  1162,     0,     0, 1 },  /* boutique */
  {  1172,     0,     0, 1 },  /* box */
  {  1177,  1607,   127, 1 },  /* br */
  {  1180,     0,     0, 1 },  /* bradesco */
  {  1189,     0,     0, 1 },  /* bridgestone */
  {  1201,     0,     0, 1 },  /* broadway */
  {  1210,     0,     0, 1 },  /* broker */
  {  1217,     0,     0, 1 },  /* brother */
  {  1225,     0,     0, 1 },  /* brussels */
  {  1235,  4224,     6, 1 },  /* bs */
  {   829,  4130,     5, 1 },  /* bt */
  {  1238,     0,     0, 1 },  /* budapest */
  {  1247,     0,     0, 1 },  /* bugatti */
  {  1255,     0,     0, 1 },  /* build */
  {  1261,     0,     0, 1 },  /* builders */
  {  1270,     0,     0, 1 },  /* business */
  {   910,     0,     0, 1 },  /* buy */
  {  1279,     0,     0, 1 },  /* buzz */
  {  1284,     0,     0, 1 },  /* bv */
  {  1287,  4230,     2, 1 },  /* bw */
  {   694,  1734,     5, 1 },  /* by */
  {  1290,  4232,     7, 1 },  /* bz */
  {  1293,     0,     0, 1 },  /* bzh */
  {   221,  1739,    19, 1 },  /* ca */
  {  1301,     0,     0, 1 },  /* cab */
  {  1305,     0,     0, 1 },  /* cafe */
  {  1314,     0,     0, 1 },  /* cal */
  {  1318,     0,     0, 1 },  /* call */
  {  1323,     0,     0, 1 },  /* calvinklein */
  {  1337,     0,     0, 1 },  /* cam */
  {  1351,     0,     0, 1 },  /* camera */
  {  1366,     0,     0, 1 },  /* camp */
  {  1371,     0,     0, 1 },  /* cancerresearch */
  {  1386,     0,     0, 1 },  /* canon */
  {  1392,     0,     0, 1 },  /* capetown */
  {  1401,     0,     0, 1 },  /* capital */
  {  1409,     0,     0, 1 },  /* capitalone */
  {  1420,     0,     0, 1 },  /* car */
  {  1424,     0,     0, 1 },  /* caravan */
  {  1432,     0,     0, 1 },  /* cards */
  {  1444,     0,     0, 1 },  /* care */
  {  1449,     0,     0, 1 },  /* career */
  {  1456,     0,     0, 1 },  /* careers */
  {  1472,     0,     0, 1 },  /* cars */
  {  1477,     0,     0, 1 },  /* cartier */
  {  1485,     0,     0, 1 },  /* casa */
  {  1490,     0,     0, 1 },  /* case */
  {  1495,     0,     0, 1 },  /* caseih */
  {  1502,     0,     0, 1 },  /* cash */
  {  1507,     0,     0, 1 },  /* casino */
  {  1517,     0,     0, 1 },  /* cat */
  {  1521,     0,     0, 1 },  /* catering */
  {  1530,     0,     0, 1 },  /* catholic */
  {  1557,     0,     0, 1 },  /* cba */
  {  1067,     0,     0, 1 },  /* cbn */
  {  1561,     0,     0, 1 },  /* cbre */
  {  1234,     0,     0, 1 },  /* cbs */
  {  1573,  4239,     7, 1 },  /* cc */
  {  1578,  4046,     1, 1 },  /* cd */
  {  1581,     0,     0, 1 },  /* ceb */
  {  1588,     0,     0, 1 },  /* center */
  {  1595,     0,     0, 1 },  /* ceo */
  {  1599,     0,     0, 1 },  /* cern */
  {  1606,  4032,     1, 1 },  /* cf */
  {  1609,     0,     0, 1 },  /* cfa */
  {  1613,     0,     0, 1 },  /* cfd */
  {   838,     0,     0, 1 },  /* cg */
  {  1141,  4246,     9, 1 },  /* ch */
  {  1622,     0,     0, 1 },  /* chanel */
  {  1635,     0,     0, 1 },  /* channel */
  {  1643,     0,     0, 1 },  /* charity */
  {  1651,     0,     0, 1 },  /* chase */
  {  1657,     0,     0, 1 },  /* chat */
  {  1662,     0,     0, 1 },  /* cheap */
  {  1668,     0,     0, 1 },  /* chintai */
  {  1676,     0,     0, 1 },  /* christmas */
  {  1686,     0,     0, 1 },  /* chrome */
  {  1693,     0,     0, 1 },  /* chrysler */
  {  1702,     0,     0, 1 },  /* church */
  {  1710,  4255,    15, 1 },  /* ci */
  {  1713,     0,     0, 1 },  /* cipriani */
  {  1722,     0,     0, 1 },  /* circle */
  {  1736,     0,     0, 1 },  /* cisco */
  {  1742,     0,     0, 1 },  /* citadel */
  {  1750,     0,     0, 1 },  /* citi */
  {  1755,     0,     0, 1 },  /* citic */
  {  1762,     0,     0, 1 },  /* city */
  {  1767,     0,     0, 1 },  /* cityeats */
  {   996,  4270,     2, 0 },  /* ck */
  {  1784,  4272,     6, 1 },  /* cl */
  {  1787,     0,     0, 1 },  /* claims */
  {  1794,     0,     0, 1 },  /* cleaning */
  {  1803,     0,     0, 1 },  /* click */
  {  1809,     0,     0, 1 },  /* clinic */
  {  1816,     0,     0, 1 },  /* clinique */
  {  1825,     0,     0, 1 },  /* clothing */
  {  1836,  1758,     6, 1 },  /* cloud */
  {  1846,  4278,     2, 1 },  /* club */
  {  1851,     0,     0, 1 },  /* clubmed */
  {  1860,  4280,     4, 1 },  /* cm */
  {   842,  1764,    44, 1 },  /* cn */
  {   113,  1813,    17, 1 },  /* co */
  {  1867,     0,     0, 1 },  /* coach */
  {  1873,     0,     0, 1 },  /* codes */
  {  1879,     0,     0, 1 },  /* coffee */
  {  1891,     0,     0, 1 },  /* college */
  {  1899,     0,     0, 1 },  /* cologne */
  {  1910,  1830,   303, 1 },  /* com */
  {  1914,     0,     0, 1 },  /* comcast */
  {  1922,     0,     0, 1 },  /* commbank */
  {  1931,  4319,     1, 1 },  /* community */
  {   201,     0,     0, 1 },  /* company */
  {  1941,     0,     0, 1 },  /* compare */
  {  1949,     0,     0, 1 },  /* computer */
  {  1958,     0,     0, 1 },  /* comsec */
  {  1965,     0,     0, 1 },  /* condos */
  {  1972,     0,     0, 1 },  /* construction */
  {  1985,     0,     0, 1 },  /* consulting */
  {  1996,     0,     0, 1 },  /* contact */
  {  2004,     0,     0, 1 },  /* contractors */
  {  2016,     0,     0, 1 },  /* cooking */
  {  2024,     0,     0, 1 },  /* cookingchannel */
  {  2039,  4320,     1, 1 },  /* cool */
  {  2044,     0,     0, 1 },  /* coop */
  {  2049,     0,     0, 1 },  /* corsica */
  {  2057,     0,     0, 1 },  /* country */
  {  2065,     0,     0, 1 },  /* coupon */
  {  2072,     0,     0, 1 },  /* coupons */
  {  2080,     0,     0, 1 },  /* courses */
  {  2088,  4321,     7, 1 },  /* cr */
  {  2091,     0,     0, 1 },  /* credit */
  {  2098,     0,     0, 1 },  /* creditcard */
  {  2109,     0,     0, 1 },  /* creditunion */
  {  2121,     0,     0, 1 },  /* cricket */
  {  2129,     0,     0, 1 },  /* crown */
  {  2135,     0,     0, 1 },  /* crs */
  {  2139,     0,     0, 1 },  /* cruise */
  {  2146,     0,     0, 1 },  /* cruises */
  {  2154,     0,     0, 1 },  /* csc */
  {  2159,  4328,     6, 1 },  /* cu */
  {  2162,     0,     0, 1 },  /* cuisinella */
  {  2173,  4032,     1, 1 },  /* cv */
  {  2178,  4334,     4, 1 },  /* cw */
  {  2181,  4338,     3, 1 },  /* cx */
  {   241,  2203,    13, 1 },  /* cy */
  {  2184,     0,     0, 1 },  /* cymru */
  {  2190,     0,     0, 1 },  /* cyou */
  {  2199,  2216,     6, 1 },  /* cz */
  {  2202,     0,     0, 1 },  /* dabur */
  {  2212,     0,     0, 1 },  /* dad */
  {  2216,     0,     0, 1 },  /* dance */
  {  2228,     0,     0, 1 },  /* data */
  {  2237,     0,     0, 1 },  /* date */
  {  2242,     0,     0, 1 },  /* dating */
  {  2249,     0,     0, 1 },  /* datsun */
  {  1007,     0,     0, 1 },  /* day */
  {  2262,     0,     0, 1 },  /* dclk */
  {  2267,     0,     0, 1 },  /* dds */
  {  2273,  2223,    54, 1 },  /* de */
  {  2276,     0,     0, 1 },  /* deal */
  {  2281,     0,     0, 1 },  /* dealer */
  {  2288,     0,     0, 1 },  /* deals */
  {  2294,     0,     0, 1 },  /* degree */
  {  2301,     0,     0, 1 },  /* delivery */
  {  2310,     0,     0, 1 },  /* dell */
  {  2315,     0,     0, 1 },  /* deloitte */
  {  2324,     0,     0, 1 },  /* delta */
  {  2335,     0,     0, 1 },  /* democrat */
  {  2344,     0,     0, 1 },  /* dental */
  {  2351,     0,     0, 1 },  /* dentist */
  {  2359,     0,     0, 1 },  /* desi */
  {  2370,     0,     0, 1 },  /* design */
  {  2379,     0,     0, 1 },  /* dev */
  {  2383,     0,     0, 1 },  /* dhl */
  {  2387,     0,     0, 1 },  /* diamonds */
  {  2396,     0,     0, 1 },  /* diet */
  {  2401,     0,     0, 1 },  /* digital */
  {  2413,  4349,     1, 1 },  /* direct */
  {  2428,     0,     0, 1 },  /* directory */
  {  2438,     0,     0, 1 },  /* discount */
  {  2447,     0,     0, 1 },  /* discover */
  {  2456,     0,     0, 1 },  /* dish */
  {  2461,     0,     0, 1 },  /* diy */
  {  2465,     0,     0, 1 },  /* dj */
  {  2469,  4350,     6, 1 },  /* dk */
  {  2473,  4130,     5, 1 },  /* dm */
  {  2476,     0,     0, 1 },  /* dnp */
  {    48,  4356,    10, 1 },  /* do */
  {  2485,     0,     0, 1 },  /* docs */
  {  2495,     0,     0, 1 },  /* doctor */
  {  2502,     0,     0, 1 },  /* dodge */
  {  2508,     0,     0, 1 },  /* dog */
  {  2512,     0,     0, 1 },  /* doha */
  {  2517,     0,     0, 1 },  /* domains */
  {  2525,     0,     0, 1 },  /* dot */
  {  2529,     0,     0, 1 },  /* download */
  {  2538,     0,     0, 1 },  /* drive */
  {  2544,     0,     0, 1 },  /* dtv */
  {  2548,     0,     0, 1 },  /* dubai */
  {  1776,     0,     0, 1 },  /* duck */
  {  2554,     0,     0, 1 },  /* dunlop */
  {  2561,     0,     0, 1 },  /* duns */
  {  2566,     0,     0, 1 },  /* dupont */
  {  2573,     0,     0, 1 },  /* durban */
  {   224,     0,     0, 1 },  /* dvag */
  {  2583,     0,     0, 1 },  /* dvr */
  {  2592,  4366,     8, 1 },  /* dz */
  {  2595,     0,     0, 1 },  /* earth */
  {  2602,     0,     0, 1 },  /* eat */
  {  1962,  4374,    12, 1 },  /* ec */
  {  2612,     0,     0, 1 },  /* eco */
  {  2616,     0,     0, 1 },  /* edeka */
  {  2622,     0,     0, 1 },  /* edu */
  {  2629,     0,     0, 1 },  /* education */
  {  1883,  2277,    10, 1 },  /* ee */
  {   161,  2287,     9, 1 },  /* eg */
  {  2648,     0,     0, 1 },  /* email */
  {  2654,     0,     0, 1 },  /* emerck */
  {  2661,     0,     0, 1 },  /* energy */
  {  2674,     0,     0, 1 },  /* engineer */
  {  2683,     0,     0, 1 },  /* engineering */
  {  2695,     0,     0, 1 },  /* enterprises */
  {  2707,     0,     0, 1 },  /* epost */
  {  2713,     0,     0, 1 },  /* epson */
  {  2723,     0,     0, 1 },  /* equipment */
  {   883,  4048,     1, 0 },  /* er */
  {  2738,     0,     0, 1 },  /* ericsson */
  {  2748,     0,     0, 1 },  /* erni */
  {   558,  2296,     5, 1 },  /* es */
  {  2759,     0,     0, 1 },  /* esq */
  {  2767,  2301,     1, 1 },  /* estate */
  {  2774,     0,     0, 1 },  /* esurance */
  {   915,  4386,     8, 1 },  /* et */
  {  2787,     0,     0, 1 },  /* etisalat */
  {  2796,  2302,     7, 1 },  /* eu */
  {  2799,     0,     0, 1 },  /* eurovision */
  {  2810,  2309,     1, 1 },  /* eus */
  {  2814,     0,     0, 1 },  /* events */
  {  2821,     0,     0, 1 },  /* everbank */
  {  2835,     0,     0, 1 },  /* exchange */
  {  2853,     0,     0, 1 },  /* expert */
  {  2860,     0,     0, 1 },  /* exposed */
  {   369,     0,     0, 1 },  /* express */
  {  2868,     0,     0, 1 },  /* extraspace */
  {  2879,     0,     0, 1 },  /* fage */
  {  2884,     0,     0, 1 },  /* fail */
  {  2889,     0,     0, 1 },  /* fairwinds */
  {  2899,  4395,     1, 1 },  /* faith */
  {   385,     0,     0, 1 },  /* family */
  {  2918,     0,     0, 1 },  /* fan */
  {  2922,     0,     0, 1 },  /* fans */
  {  2932,  4396,     1, 1 },  /* farm */
  {  2937,     0,     0, 1 },  /* farmers */
  {  2945,     0,     0, 1 },  /* fashion */
  {  2953,     0,     0, 1 },  /* fast */
  {  2958,     0,     0, 1 },  /* fedex */
  {  2964,     0,     0, 1 },  /* feedback */
  {  2973,     0,     0, 1 },  /* ferrari */
  {  2981,     0,     0, 1 },  /* ferrero */
  {  2993,  4397,     4, 1 },  /* fi */
  {  2996,     0,     0, 1 },  /* fiat */
  {  3001,     0,     0, 1 },  /* fidelity */
  {  3010,     0,     0, 1 },  /* fido */
  {  3015,     0,     0, 1 },  /* film */
  {  3020,     0,     0, 1 },  /* final */
  {  3026,     0,     0, 1 },  /* finance */
  {  3037,     0,     0, 1 },  /* financial */
  {  3047,     0,     0, 1 },  /* fire */
  {  3052,     0,     0, 1 },  /* firestone */
  {  3062,     0,     0, 1 },  /* firmdale */
  {  3071,     0,     0, 1 },  /* fish */
  {  3076,     0,     0, 1 },  /* fishing */
  {  3084,  4401,     1, 1 },  /* fit */
  {  3088,     0,     0, 1 },  /* fitness */
  {  3096,  4048,     1, 0 },  /* fj */
  {  3100,  4048,     1, 0 },  /* fk */
  {  3103,     0,     0, 1 },  /* flickr */
  {  3110,     0,     0, 1 },  /* flights */
  {  3118,     0,     0, 1 },  /* flir */
  {  3123,     0,     0, 1 },  /* florist */
  {  3131,     0,     0, 1 },  /* flowers */
  {  3139,     0,     0, 1 },  /* fly */
  {  3144,     0,     0, 1 },  /* fm */
  {  3151,     0,     0, 1 },  /* fo */
  {  3154,     0,     0, 1 },  /* foo */
  {  3158,     0,     0, 1 },  /* food */
  {  3163,     0,     0, 1 },  /* foodnetwork */
  {  3175,     0,     0, 1 },  /* football */
  {  3186,     0,     0, 1 },  /* ford */
  {  3191,     0,     0, 1 },  /* forex */
  {  3197,     0,     0, 1 },  /* forsale */
  {  3205,     0,     0, 1 },  /* forum */
  {  3211,     0,     0, 1 },  /* foundation */
  {  3222,     0,     0, 1 },  /* fox */
  {  3227,  4402,    30, 1 },  /* fr */
  {  3234,     0,     0, 1 },  /* free */
  {  3239,     0,     0, 1 },  /* fresenius */
  {  3249,     0,     0, 1 },  /* frl */
  {  3253,     0,     0, 1 },  /* frogans */
  {  3261,     0,     0, 1 },  /* frontdoor */
  {  3271,     0,     0, 1 },  /* frontier */
  {  3280,     0,     0, 1 },  /* ftr */
  {  3284,     0,     0, 1 },  /* fujitsu */
  {  3292,     0,     0, 1 },  /* fujixerox */
  {  3302,     0,     0, 1 },  /* fun */
  {  3306,     0,     0, 1 },  /* fund */
  {  3311,     0,     0, 1 },  /* furniture */
  {  3321,     0,     0, 1 },  /* futbol */
  {  3328,     0,     0, 1 },  /* fyi */
  {  3334,     0,     0, 1 },  /* ga */
  {  3339,     0,     0, 1 },  /* gal */
  {  3346,     0,     0, 1 },  /* gallery */
  {  3354,     0,     0, 1 },  /* gallo */
  {  3360,     0,     0, 1 },  /* gallup */
  {  3371,     0,     0, 1 },  /* game */
  {  3384,     0,     0, 1 },  /* games */
  {  3390,     0,     0, 1 },  /* gap */
  {  3396,     0,     0, 1 },  /* garden */
  {  3420,     0,     0, 1 },  /* gb */
  {  3423,     0,     0, 1 },  /* gbiz */
  {  3428,  3911,     1, 1 },  /* gd */
  {  3431,  4432,     1, 1 },  /* gdn */
  {  1896,  4433,     8, 1 },  /* ge */
  {  3440,     0,     0, 1 },  /* gea */
  {  3444,     0,     0, 1 },  /* gent */
  {  3449,     0,     0, 1 },  /* genting */
  {  3457,     0,     0, 1 },  /* george */
  {  3465,     0,     0, 1 },  /* gf */
  {  3468,  4441,     4, 1 },  /* gg */
  {  3471,     0,     0, 1 },  /* ggee */
  {  3484,  4445,     5, 1 },  /* gh */
  {  3489,  4450,     6, 1 },  /* gi */
  {  3492,     0,     0, 1 },  /* gift */
  {  3497,     0,     0, 1 },  /* gifts */
  {  3503,     0,     0, 1 },  /* gives */
  {  3509,     0,     0, 1 },  /* giving */
  {  3516,  4456,     6, 1 },  /* gl */
  {  3519,     0,     0, 1 },  /* glade */
  {  3525,     0,     0, 1 },  /* glass */
  {  3538,     0,     0, 1 },  /* gle */
  {  3542,     0,     0, 1 },  /* global */
  {  3549,     0,     0, 1 },  /* globo */
  {  3569,     0,     0, 1 },  /* gm */
  {  3572,     0,     0, 1 },  /* gmail */
  {   935,     0,     0, 1 },  /* gmbh */
  {  3578,     0,     0, 1 },  /* gmo */
  {  3582,     0,     0, 1 },  /* gmx */
  {  2374,  4462,     6, 1 },  /* gn */
  {  3592,     0,     0, 1 },  /* godaddy */
  {  3600,     0,     0, 1 },  /* gold */
  {  3605,     0,     0, 1 },  /* goldpoint */
  {  3615,     0,     0, 1 },  /* golf */
  {  3620,     0,     0, 1 },  /* goo */
  {  3624,     0,     0, 1 },  /* goodhands */
  {  3634,     0,     0, 1 },  /* goodyear */
  {  3643,  4468,     1, 1 },  /* goog */
  {  3535,     0,     0, 1 },  /* google */
  {  3648,     0,     0, 1 },  /* gop */
  {  3655,     0,     0, 1 },  /* got */
  {  3665,     0,     0, 1 },  /* gov */
  {  3669,  4469,     6, 1 },  /* gp */
  {  3672,     0,     0, 1 },  /* gq */
  {  3676,  4475,     7, 1 },  /* gr */
  {  3679,     0,     0, 1 },  /* grainger */
  {  3688,     0,     0, 1 },  /* graphics */
  {  3697,     0,     0, 1 },  /* gratis */
  {  3709,     0,     0, 1 },  /* green */
  {  3715,     0,     0, 1 },  /* gripe */
  {  3721,     0,     0, 1 },  /* grocery */
  {  3732,     0,     0, 1 },  /* group */
  {  3739,     0,     0, 1 },  /* gs */
  {  3742,  4482,     8, 1 },  /* gt */
  {  3747,  4490,     8, 1 },  /* gu */
  {  3750,     0,     0, 1 },  /* guardian */
  {  3759,     0,     0, 1 },  /* gucci */
  {  3765,     0,     0, 1 },  /* guge */
  {  3770,     0,     0, 1 },  /* guide */
  {  3776,     0,     0, 1 },  /* guitars */
  {  3789,     0,     0, 1 },  /* guru */
  {  3796,     0,     0, 1 },  /* gw */
  {  2665,  4498,     7, 1 },  /* gy */
  {  3799,     0,     0, 1 },  /* hair */
  {  3804,     0,     0, 1 },  /* hamburg */
  {  3812,     0,     0, 1 },  /* hangout */
  {   812,     0,     0, 1 },  /* haus */
  {  3820,     0,     0, 1 },  /* hbo */
  {  3824,     0,     0, 1 },  /* hdfc */
  {  3829,     0,     0, 1 },  /* hdfcbank */
  {  3838,     0,     0, 1 },  /* health */
  {  1438,     0,     0, 1 },  /* healthcare */
  {  3845,     0,     0, 1 },  /* help */
  {  3850,     0,     0, 1 },  /* helsinki */
  {  3863,     0,     0, 1 },  /* here */
  {  3868,     0,     0, 1 },  /* hermes */
  {  3875,     0,     0, 1 },  /* hgtv */
  {  3880,     0,     0, 1 },  /* hiphop */
  {  3887,     0,     0, 1 },  /* hisamitsu */
  {  3897,     0,     0, 1 },  /* hitachi */
  {  3911,     0,     0, 1 },  /* hiv */
  {  3916,  4505,    24, 1 },  /* hk */
  {  3919,     0,     0, 1 },  /* hkt */
  {  3923,     0,     0, 1 },  /* hm */
  {  3930,  4529,     7, 1 },  /* hn */
  {  3933,     0,     0, 1 },  /* hockey */
  {  3940,     0,     0, 1 },  /* holdings */
  {  3949,     0,     0, 1 },  /* holiday */
  {  3957,     0,     0, 1 },  /* homedepot */
  {  3967,     0,     0, 1 },  /* homegoods */
  {  3977,     0,     0, 1 },  /* homes */
  {  3983,     0,     0, 1 },  /* homesense */
  {  3993,     0,     0, 1 },  /* honda */
  {  3999,     0,     0, 1 },  /* honeywell */
  {  4009,     0,     0, 1 },  /* horse */
  {  4015,     0,     0, 1 },  /* hospital */
  {  4026,  4536,     4, 1 },  /* host */
  {  4034,  4540,     1, 1 },  /* hosting */
  {  4042,     0,     0, 1 },  /* hot */
  {  4046,     0,     0, 1 },  /* hoteles */
  {  4059,     0,     0, 1 },  /* hotels */
  {  4066,     0,     0, 1 },  /* hotmail */
  {  4077,     0,     0, 1 },  /* house */
  {  4084,     0,     0, 1 },  /* how */
  {  4090,  4541,     5, 1 },  /* hr */
  {  4093,     0,     0, 1 },  /* hsbc */
  {  4101,  4546,    17, 1 },  /* ht */
  {  4106,  4563,    32, 1 },  /* hu */
  {  4109,     0,     0, 1 },  /* hughes */
  {  4116,     0,     0, 1 },  /* hyatt */
  {  4122,     0,     0, 1 },  /* hyundai */
  {  1055,     0,     0, 1 },  /* ibm */
  {  4130,     0,     0, 1 },  /* icbc */
  {  4138,     0,     0, 1 },  /* ice */
  {  2158,     0,     0, 1 },  /* icu */
  {   437,  2310,    12, 1 },  /* id */
  {    31,  4595,     3, 1 },  /* ie */
  {  4146,     0,     0, 1 },  /* ieee */
  {  3143,     0,     0, 1 },  /* ifm */
  {  4151,     0,     0, 1 },  /* ikano */
  {  2651,  2322,     8, 1 },  /* il */
  {  4162,  2330,     9, 1 },  /* im */
  {  4165,     0,     0, 1 },  /* imamat */
  {  4172,     0,     0, 1 },  /* imdb */
  {  4177,     0,     0, 1 },  /* immo */
  {  4182,     0,     0, 1 },  /* immobilien */
  {   898,  4600,    15, 1 },  /* in */
  {  4197,     0,     0, 1 },  /* inc */
  {  4201,     0,     0, 1 },  /* industries */
  {  4212,     0,     0, 1 },  /* infiniti */
  {  3149,  4615,    20, 1 },  /* info */
  {   971,     0,     0, 1 },  /* ing */
  {  4228,     0,     0, 1 },  /* ink */
  {  4232,     0,     0, 1 },  /* institute */
  {  4246,     0,     0, 1 },  /* insurance */
  {  4256,     0,     0, 1 },  /* insure */
  {  3611,  4315,     1, 1 },  /* int */
  {  4268,     0,     0, 1 },  /* intel */
  {  4274,     0,     0, 1 },  /* international */
  {  4288,     0,     0, 1 },  /* intuit */
  {  4295,     0,     0, 1 },  /* investments */
  {   611,  2339,    34, 1 },  /* io */
  {  4307,     0,     0, 1 },  /* ipiranga */
  {  4316,  3904,     6, 1 },  /* iq */
  {  3120,  4638,     9, 1 },  /* ir */
  {  4323,     0,     0, 1 },  /* irish */
  {  3701,  4647,     8, 1 },  /* is */
  {  4334,     0,     0, 1 },  /* iselect */
  {  4342,     0,     0, 1 },  /* ismaili */
  {  2355,     0,     0, 1 },  /* ist */
  {  4350,     0,     0, 1 },  /* istanbul */
  {  2095,  4655,   410, 1 },  /* it */
  {   582,     0,     0, 1 },  /* itau */
  {  4359,     0,     0, 1 },  /* itv */
  {  2610,     0,     0, 1 },  /* iveco */
  {  4363,     0,     0, 1 },  /* iwc */
  {  4367,     0,     0, 1 },  /* jaguar */
  {  4374,     0,     0, 1 },  /* java */
  {  4379,     0,     0, 1 },  /* jcb */
  {  4383,     0,     0, 1 },  /* jcp */
  {  4390,  5065,     3, 1 },  /* je */
  {  4393,     0,     0, 1 },  /* jeep */
  {  4398,     0,     0, 1 },  /* jetzt */
  {  4404,     0,     0, 1 },  /* jewelry */
  {  4412,     0,     0, 1 },  /* jio */
  {  4416,     0,     0, 1 },  /* jlc */
  {  4420,     0,     0, 1 },  /* jll */
  {  4424,  4048,     1, 0 },  /* jm */
  {  4427,     0,     0, 1 },  /* jmp */
  {  4431,     0,     0, 1 },  /* jnj */
  {  4437,  5068,     8, 1 },  /* jo */
  {  4440,     0,     0, 1 },  /* jobs */
  {  4445,     0,     0, 1 },  /* joburg */
  {  4452,     0,     0, 1 },  /* jot */
  {  4456,     0,     0, 1 },  /* joy */
  {  4460,  2377,   111, 1 },  /* jp */
  {  4463,     0,     0, 1 },  /* jpmorgan */
  {  4472,     0,     0, 1 },  /* jprs */
  {  4477,     0,     0, 1 },  /* juegos */
  {  4484,     0,     0, 1 },  /* juniper */
  {  4492,     0,     0, 1 },  /* kaufen */
  {  4499,     0,     0, 1 },  /* kddi */
  {   963,  2488,    10, 1 },  /* ke */
  {  4054,     0,     0, 1 },  /* kerryhotels */
  {  4509,     0,     0, 1 },  /* kerrylogistics */
  {  4524,     0,     0, 1 },  /* kerryproperties */
  {  4540,     0,     0, 1 },  /* kfh */
  {  4544,  3904,     6, 1 },  /* kg */
  {  4547,  4048,     1, 0 },  /* kh */
  {  3856,  6751,     7, 1 },  /* ki */
  {  4556,     0,     0, 1 },  /* kia */
  {  4562,     0,     0, 1 },  /* kim */
  {  4566,     0,     0, 1 },  /* kinder */
  {  4573,     0,     0, 1 },  /* kindle */
  {  4580,     0,     0, 1 },  /* kitchen */
  {  4588,     0,     0, 1 },  /* kiwi */
  {  4593,  6758,    17, 1 },  /* km */
  {  4598,  6775,     4, 1 },  /* kn */
  {  4601,     0,     0, 1 },  /* koeln */
  {  4607,     0,     0, 1 },  /* komatsu */
  {  4615,     0,     0, 1 },  /* kosher */
  {  4630,  6779,     6, 1 },  /* kp */
  {  4633,     0,     0, 1 },  /* kpmg */
  {  4638,     0,     0, 1 },  /* kpn */
  {  3107,  6785,    30, 1 },  /* kr */
  {  4647,  6815,     2, 1 },  /* krd */
  {  4651,     0,     0, 1 },  /* kred */
  {  4656,     0,     0, 1 },  /* kuokgroup */
  {  4666,  4048,     1, 0 },  /* kw */
  {  4670,  4130,     5, 1 },  /* ky */
  {  4673,     0,     0, 1 },  /* kyoto */
  {  4679,  6817,     7, 1 },  /* kz */
  {  2170,  6824,    11, 1 },  /* la */
  {  4686,     0,     0, 1 },  /* lacaixa */
  {  4694,     0,     0, 1 },  /* ladbrokes */
  {  4704,     0,     0, 1 },  /* lamborghini */
  {  4716,     0,     0, 1 },  /* lamer */
  {  4722,     0,     0, 1 },  /* lancaster */
  {  4732,     0,     0, 1 },  /* lancia */
  {  4739,     0,     0, 1 },  /* lancome */
  {  4749,  2498,     1, 1 },  /* land */
  {  4754,     0,     0, 1 },  /* landrover */
  {  4764,     0,     0, 1 },  /* lanxess */
  {  4772,     0,     0, 1 },  /* lasalle */
  {  2792,     0,     0, 1 },  /* lat */
  {  4786,     0,     0, 1 },  /* latino */
  {  4793,     0,     0, 1 },  /* latrobe */
  {  4805,     0,     0, 1 },  /* law */
  {  4814,     0,     0, 1 },  /* lawyer */
  {  4822,  4130,     5, 1 },  /* lb */
  {  4417,  6837,     8, 1 },  /* lc */
  {  4829,     0,     0, 1 },  /* lds */
  {  4833,     0,     0, 1 },  /* lease */
  {  4839,     0,     0, 1 },  /* leclerc */
  {  4847,     0,     0, 1 },  /* lefrak */
  {  3337,     0,     0, 1 },  /* legal */
  {  4854,     0,     0, 1 },  /* lego */
  {  4859,     0,     0, 1 },  /* lexus */
  {  4865,     0,     0, 1 },  /* lgbt */
  {  4347,  6845,     3, 1 },  /* li */
  {  4875,     0,     0, 1 },  /* liaison */
  {  4883,     0,     0, 1 },  /* lidl */
  {  4891,     0,     0, 1 },  /* life */
  {  4242,     0,     0, 1 },  /* lifeinsurance */
  {  4896,     0,     0, 1 },  /* lifestyle */
  {  4906,     0,     0, 1 },  /* lighting */
  {  4915,     0,     0, 1 },  /* like */
  {  4920,     0,     0, 1 },  /* lilly */
  {  4926,     0,     0, 1 },  /* limited */
  {  4934,     0,     0, 1 },  /* limo */
  {  4939,     0,     0, 1 },  /* lincoln */
  {  4947,     0,     0, 1 },  /* linde */
  {  4957,  6848,     2, 1 },  /* link */
  {  4962,     0,     0, 1 },  /* lipsy */
  {  4972,     0,     0, 1 },  /* live */
  {  4977,     0,     0, 1 },  /* living */
  {  4984,     0,     0, 1 },  /* lixil */
  {  2264,  6850,    15, 1 },  /* lk */
  {  4994,     0,     0, 1 },  /* llc */
  {  4998,     0,     0, 1 },  /* loan */
  {  5003,     0,     0, 1 },  /* loans */
  {  5009,     0,     0, 1 },  /* locker */
  {  5016,     0,     0, 1 },  /* locus */
  {  5022,     0,     0, 1 },  /* loft */
  {  5027,     0,     0, 1 },  /* lol */
  {  5031,     0,     0, 1 },  /* london */
  {  5038,     0,     0, 1 },  /* lotte */
  {  5044,     0,     0, 1 },  /* lotto */
  {  5050,     0,     0, 1 },  /* love */
  {  5055,     0,     0, 1 },  /* lpl */
  {  3034,     0,     0, 1 },  /* lplfinancial */
  {  5059,  4130,     5, 1 },  /* lr */
  {  1231,  4230,     2, 1 },  /* ls */
  {   151,  4595,     3, 1 },  /* lt */
  {  5070,     0,     0, 1 },  /* ltd */
  {  5074,     0,     0, 1 },  /* ltda */
  {  5079,  6865,     2, 1 },  /* lu */
  {  5082,     0,     0, 1 },  /* lundbeck */
  {  5091,     0,     0, 1 },  /* lupin */
  {  5097,     0,     0, 1 },  /* luxe */
  {  5102,     0,     0, 1 },  /* luxury */
  {  5114,  6867,     9, 1 },  /* lv */
  {   339,  6876,     9, 1 },  /* ly */
  {  5118,  6885,     6, 1 },  /* ma */
  {  5121,     0,     0, 1 },  /* macys */
  {  5127,     0,     0, 1 },  /* madrid */
  {  5134,     0,     0, 1 },  /* maif */
  {  5148,     0,     0, 1 },  /* maison */
  {  5155,     0,     0, 1 },  /* makeup */
  {  5165,     0,     0, 1 },  /* man */
  {  5169,  6891,     1, 1 },  /* management */
  {  5180,     0,     0, 1 },  /* mango */
  {  5186,     0,     0, 1 },  /* map */
  {  5196,     0,     0, 1 },  /* market */
  {  5203,     0,     0, 1 },  /* marketing */
  {  5213,     0,     0, 1 },  /* markets */
  {  5221,     0,     0, 1 },  /* marriott */
  {  5230,     0,     0, 1 },  /* marshalls */
  {  5240,     0,     0, 1 },  /* maserati */
  {  5249,     0,     0, 1 },  /* mattel */
  {  5260,     0,     0, 1 },  /* mba */
  {  5274,  6892,     2, 1 },  /* mc */
  {  5277,     0,     0, 1 },  /* mckinsey */
  {  5287,  4032,     1, 1 },  /* md */
  {  1690,  2499,    31, 1 },  /* me */
  {  1855,     0,     0, 1 },  /* med */
  {  5294,     0,     0, 1 },  /* media */
  {  5300,     0,     0, 1 },  /* meet */
  {  5305,     0,     0, 1 },  /* melbourne */
  {  5315,     0,     0, 1 },  /* meme */
  {  5320,     0,     0, 1 },  /* memorial */
  {  5333,     0,     0, 1 },  /* men */
  {  5337,  6895,     1, 1 },  /* menu */
  {   299,     0,     0, 1 },  /* meo */
  {  5342,     0,     0, 1 },  /* merckmsd */
  {  4888,     0,     0, 1 },  /* metlife */
  {  4635,  6896,     9, 1 },  /* mg */
  {  5358,     0,     0, 1 },  /* mh */
  {  5361,     0,     0, 1 },  /* miami */
  {  5367,     0,     0, 1 },  /* microsoft */
  {  4157,     0,     0, 1 },  /* mil */
  {  5379,     0,     0, 1 },  /* mini */
  {  4263,     0,     0, 1 },  /* mint */
  {  5385,     0,     0, 1 },  /* mit */
  {  5389,     0,     0, 1 },  /* mitsubishi */
  {  5400,  6905,     9, 1 },  /* mk */
  {  5403,  6914,     7, 1 },  /* ml */
  {  4821,     0,     0, 1 },  /* mlb */
  {  5062,     0,     0, 1 },  /* mls */
  {  5408,  4048,     1, 0 },  /* mm */
  {  5117,     0,     0, 1 },  /* mma */
  {  5412,  6921,     5, 1 },  /* mn */
  {  3579,  4130,     5, 1 },  /* mo */
  {  5415,  6926,     2, 1 },  /* mobi */
  {  5426,     0,     0, 1 },  /* mobile */
  {  5433,     0,     0, 1 },  /* mobily */
  {  5443,     0,     0, 1 },  /* moda */
  {  5448,     0,     0, 1 },  /* moe */
  {  5452,     0,     0, 1 },  /* moi */
  {  5456,     0,     0, 1 },  /* mom */
  {  5460,     0,     0, 1 },  /* monash */
  {  5467,     0,     0, 1 },  /* money */
  {  5473,     0,     0, 1 },  /* monster */
  {  5481,     0,     0, 1 },  /* mopar */
  {  5487,     0,     0, 1 },  /* mormon */
  {  5494,     0,     0, 1 },  /* mortgage */
  {  5503,     0,     0, 1 },  /* moscow */
  {  5514,     0,     0, 1 },  /* moto */
  {  5519,     0,     0, 1 },  /* motorcycles */
  {  5531,     0,     0, 1 },  /* mov */
  {  5535,     0,     0, 1 },  /* movie */
  {  5541,     0,     0, 1 },  /* movistar */
  {  1368,     0,     0, 1 },  /* mp */
  {  5554,     0,     0, 1 },  /* mq */
  {  5558,  6928,     2, 1 },  /* mr */
  {  1060,  4130,     5, 1 },  /* ms */
  {  5347,     0,     0, 1 },  /* msd */
  {  5566,  2530,     4, 1 },  /* mt */
  {  5569,     0,     0, 1 },  /* mtn */
  {  5573,     0,     0, 1 },  /* mtr */
  {  5579,  6930,     7, 1 },  /* mu */
  {  5596,  6937,   548, 1 },  /* museum */
  {  5615,     0,     0, 1 },  /* mutual */
  {  5622,  7485,    14, 1 },  /* mv */
  {  1064,  7499,    11, 1 },  /* mw */
  {  3583,  7510,     7, 1 },  /* mx */
  {    70,  7517,     8, 1 },  /* my */
  {  5634,  7525,     8, 1 },  /* mz */
  {   172,  7533,    17, 1 },  /* na */
  {  5651,     0,     0, 1 },  /* nab */
  {  5655,     0,     0, 1 },  /* nadex */
  {  5661,     0,     0, 1 },  /* nagoya */
  {  5672,  2534,     2, 1 },  /* name */
  {  5677,     0,     0, 1 },  /* nationwide */
  {  5688,     0,     0, 1 },  /* natura */
  {  5698,     0,     0, 1 },  /* navy */
  {   688,     0,     0, 1 },  /* nba */
  {  4198,  7551,     2, 1 },  /* nc */
  {  1198,     0,     0, 1 },  /* ne */
  {  2606,     0,     0, 1 },  /* nec */
  {  5710,  2536,   106, 1 },  /* net */
  {  5714,     0,     0, 1 },  /* netbank */
  {  5722,     0,     0, 1 },  /* netflix */
  {  3167,  2646,     1, 1 },  /* network */
  {  5730,     0,     0, 1 },  /* neustar */
  {  5738,     0,     0, 1 },  /* new */
  {  5742,     0,     0, 1 },  /* newholland */
  {  5753,     0,     0, 1 },  /* news */
  {  5758,     0,     0, 1 },  /* next */
  {  2409,     0,     0, 1 },  /* nextdirect */
  {  5763,     0,     0, 1 },  /* nexus */
  {  5770,  7560,    10, 1 },  /* nf */
  {  5773,     0,     0, 1 },  /* nfl */
  {   972,  2647,    10, 1 },  /* ng */
  {   977,     0,     0, 1 },  /* ngo */
  {  3915,     0,     0, 1 },  /* nhk */
  {  1719,  7570,    14, 1 },  /* ni */
  {  5791,     0,     0, 1 },  /* nico */
  {  5796,     0,     0, 1 },  /* nike */
  {  5801,     0,     0, 1 },  /* nikon */
  {  5807,     0,     0, 1 },  /* ninja */
  {  5813,     0,     0, 1 },  /* nissan */
  {  5820,     0,     0, 1 },  /* nissay */
  {  1072,  2657,     8, 1 },  /* nl */
  {  1511,  2665,   726, 1 },  /* no */
  {  4554,     0,     0, 1 },  /* nokia */
  {  5603,     0,     0, 1 },  /* northwesternmutual */
  {  5832,     0,     0, 1 },  /* norton */
  {  5839,     0,     0, 1 },  /* now */
  {  5843,     0,     0, 1 },  /* nowruz */
  {  5850,     0,     0, 1 },  /* nowtv */
  {  2477,  4048,     1, 0 },  /* np */
  {  5857,  6751,     7, 1 },  /* nr */
  {  5862,     0,     0, 1 },  /* nra */
  {  5866,     0,     0, 1 },  /* nrw */
  {  5870,     0,     0, 1 },  /* ntt */
  {  5339,  7603,     4, 1 },  /* nu */
  {  5878,     0,     0, 1 },  /* nyc */
  {   325,  3391,    17, 1 },  /* nz */
  {  5416,     0,     0, 1 },  /* obi */
  {  5887,     0,     0, 1 },  /* observer */
  {  5896,     0,     0, 1 },  /* off */
  {  5904,     0,     0, 1 },  /* office */
  {  5911,     0,     0, 1 },  /* okinawa */
  {  5919,     0,     0, 1 },  /* olayan */
  {  5926,     0,     0, 1 },  /* olayangroup */
  {  5695,     0,     0, 1 },  /* oldnavy */
  {  5938,     0,     0, 1 },  /* ollo */
  {   353,  7607,     9, 1 },  /* om */
  {  5947,     0,     0, 1 },  /* omega */
  {  1197,  7616,     1, 1 },  /* one */
  {  5960,     0,     0, 1 },  /* ong */
  {  5964,     0,     0, 1 },  /* onion */
  {  5970,     0,     0, 1 },  /* onl */
  {  5979,  6895,     1, 1 },  /* online */
  {  5986,     0,     0, 1 },  /* onyourside */
  {  5997,     0,     0, 1 },  /* ooo */
  {  6001,     0,     0, 1 },  /* open */
  {  6006,     0,     0, 1 },  /* oracle */
  {  6013,     0,     0, 1 },  /* orange */
  {  6026,  3408,   106, 1 },  /* org */
  {  6037,     0,     0, 1 },  /* organic */
  {  6045,     0,     0, 1 },  /* origins */
  {  6054,     0,     0, 1 },  /* osaka */
  {  6063,     0,     0, 1 },  /* otsuka */
  {    23,     0,     0, 1 },  /* ott */
  {  6070,  7678,     1, 1 },  /* ovh */
  {   522,  7679,    11, 1 },  /* pa */
  {  6074,     0,     0, 1 },  /* page */
  {  6079,     0,     0, 1 },  /* panasonic */
  {  6089,     0,     0, 1 },  /* panerai */
  {  6097,     0,     0, 1 },  /* paris */
  {  6103,     0,     0, 1 },  /* pars */
  {  6108,     0,     0, 1 },  /* partners */
  {  6117,     0,     0, 1 },  /* parts */
  {  6123,  4395,     1, 1 },  /* party */
  {  6129,     0,     0, 1 },  /* passagens */
  {   314,     0,     0, 1 },  /* pay */
  {  2176,     0,     0, 1 },  /* pccw */
  {  3718,  7690,     9, 1 },  /* pe */
  {  6139,     0,     0, 1 },  /* pet */
  {  6143,  7699,     3, 1 },  /* pf */
  {  6146,     0,     0, 1 },  /* pfizer */
  {  6154,  4048,     1, 0 },  /* pg */
  {  6157,  7702,     8, 1 },  /* ph */
  {  6160,     0,     0, 1 },  /* pharmacy */
  {  6169,     0,     0, 1 },  /* phd */
  {  6173,     0,     0, 1 },  /* philips */
  {  5953,     0,     0, 1 },  /* phone */
  {  6181,     0,     0, 1 },  /* photo */
  {  6187,     0,     0, 1 },  /* photography */
  {  6201,     0,     0, 1 },  /* photos */
  {  6208,     0,     0, 1 },  /* physio */
  {  6215,     0,     0, 1 },  /* piaget */
  {  6227,     0,     0, 1 },  /* pics */
  {  6232,     0,     0, 1 },  /* pictet */
  {  6239,  7710,     1, 1 },  /* pictures */
  {  6248,     0,     0, 1 },  /* pid */
  {  5093,     0,     0, 1 },  /* pin */
  {  6256,     0,     0, 1 },  /* ping */
  {  4227,     0,     0, 1 },  /* pink */
  {  6261,     0,     0, 1 },  /* pioneer */
  {  6269,     0,     0, 1 },  /* pizza */
  {  6275,  7711,    14, 1 },  /* pk */
  {  5056,  3519,   166, 1 },  /* pl */
  {  6283,     0,     0, 1 },  /* place */
  {  6289,     0,     0, 1 },  /* play */
  {  6294,     0,     0, 1 },  /* playstation */
  {   966,     0,     0, 1 },  /* plumbing */
  {  6308,     0,     0, 1 },  /* plus */
  {  6315,  7772,     1, 1 },  /* pm */
  {  4639,  7773,     5, 1 },  /* pn */
  {  6318,     0,     0, 1 },  /* pnc */
  {  6322,     0,     0, 1 },  /* pohl */
  {  6327,     0,     0, 1 },  /* poker */
  {  6333,     0,     0, 1 },  /* politie */
  {  6341,     0,     0, 1 },  /* porn */
  {   617,     0,     0, 1 },  /* post */
  {  6351,  7778,    13, 1 },  /* pr */
  {  6354,     0,     0, 1 },  /* pramerica */
  {  6364,     0,     0, 1 },  /* praxi */
  {   371,     0,     0, 1 },  /* press */
  {  6370,     0,     0, 1 },  /* prime */
  {  6376,  3685,    14, 1 },  /* pro */
  {  6380,     0,     0, 1 },  /* prod */
  {  6385,     0,     0, 1 },  /* productions */
  {  6397,     0,     0, 1 },  /* prof */
  {  6402,     0,     0, 1 },  /* progressive */
  {  6414,     0,     0, 1 },  /* promo */
  {  4529,     0,     0, 1 },  /* properties */
  {  6420,     0,     0, 1 },  /* property */
  {  6429,     0,     0, 1 },  /* protection */
  {  6440,     0,     0, 1 },  /* pru */
  {  6444,     0,     0, 1 },  /* prudential */
  {  6178,  7792,     7, 1 },  /* ps */
  {  6459,  7799,    10, 1 },  /* pt */
  {  6462,  6895,     1, 1 },  /* pub */
  {  6466,  7809,     9, 1 },  /* pw */
  {  6469,     0,     0, 1 },  /* pwc */
  {  6474,  7818,     7, 1 },  /* py */
  {  6488,  7825,    10, 1 },  /* qa */
  {  6491,     0,     0, 1 },  /* qpon */
  {  6496,     0,     0, 1 },  /* quebec */
  {  6503,     0,     0, 1 },  /* quest */
  {  6509,     0,     0, 1 },  /* qvc */
  {  6513,     0,     0, 1 },  /* racing */
  {  6520,     0,     0, 1 },  /* radio */
  {  6526,     0,     0, 1 },  /* raid */
  {    80,  7835,     4, 1 },  /* re */
  {  6543,     0,     0, 1 },  /* read */
  {  2763,     0,     0, 1 },  /* realestate */
  {  6548,     0,     0, 1 },  /* realtor */
  {  6556,     0,     0, 1 },  /* realty */
  {  6563,     0,     0, 1 },  /* recipes */
  {  4652,     0,     0, 1 },  /* red */
  {  6571,     0,     0, 1 },  /* redstone */
  {  6580,     0,     0, 1 },  /* redumbrella */
  {  6592,     0,     0, 1 },  /* rehab */
  {  6598,     0,     0, 1 },  /* reise */
  {  6604,     0,     0, 1 },  /* reisen */
  {  6611,     0,     0, 1 },  /* reit */
  {  6616,     0,     0, 1 },  /* reliance */
  {  6627,     0,     0, 1 },  /* ren */
  {  6640,     0,     0, 1 },  /* rent */
  {  6645,     0,     0, 1 },  /* rentals */
  {  6653,     0,     0, 1 },  /* repair */
  {  6660,     0,     0, 1 },  /* report */
  {  6672,     0,     0, 1 },  /* republican */
  {  6683,     0,     0, 1 },  /* rest */
  {  6688,     0,     0, 1 },  /* restaurant */
  {  6699,  4395,     1, 1 },  /* review */
  {  6706,     0,     0, 1 },  /* reviews */
  {  6714,     0,     0, 1 },  /* rexroth */
  {  6725,     0,     0, 1 },  /* rich */
  {  6730,     0,     0, 1 },  /* richardli */
  {  6740,     0,     0, 1 },  /* ricoh */
  {  6746,     0,     0, 1 },  /* rightathome */
  {  6758,     0,     0, 1 },  /* ril */
  {  6766,     0,     0, 1 },  /* rio */
  {  6777,  7839,     1, 1 },  /* rip */
  {  5384,     0,     0, 1 },  /* rmit */
  {   166,  7840,    14, 1 },  /* ro */
  {  6781,     0,     0, 1 },  /* rocher */
  {  6788,  7854,     3, 1 },  /* rocks */
  {  6794,     0,     0, 1 },  /* rodeo */
  {  6800,     0,     0, 1 },  /* rogers */
  {  6807,     0,     0, 1 },  /* room */
  {  1267,  7857,     9, 1 },  /* rs */
  {  6812,     0,     0, 1 },  /* rsvp */
  {  2187,  3699,    32, 1 },  /* ru */
  {  6821,     0,     0, 1 },  /* rugby */
  {  4088,     0,     0, 1 },  /* ruhr */
  {  6827,  7867,     2, 1 },  /* run */
  {  5867,  7869,     9, 1 },  /* rw */
  {  6831,     0,     0, 1 },  /* rwe */
  {  6835,     0,     0, 1 },  /* ryukyu */
  {  1487,  7878,     8, 1 },  /* sa */
  {  6846,     0,     0, 1 },  /* saarland */
  {  6855,     0,     0, 1 },  /* safe */
  {  6860,     0,     0, 1 },  /* safety */
  {  6867,     0,     0, 1 },  /* sakura */
  {  3200,     0,     0, 1 },  /* sale */
  {  6874,     0,     0, 1 },  /* salon */
  {  6880,     0,     0, 1 },  /* samsclub */
  {  6889,     0,     0, 1 },  /* samsung */
  {  6897,     0,     0, 1 },  /* sandvik */
  {  6905,     0,     0, 1 },  /* sandvikcoromant */
  {  2989,     0,     0, 1 },  /* sanofi */
  {  6921,     0,     0, 1 },  /* sap */
  {  6925,     0,     0, 1 },  /* sapo */
  {  6930,     0,     0, 1 },  /* sarl */
  {  6935,     0,     0, 1 },  /* sas */
  {  6939,     0,     0, 1 },  /* save */
  {  6944,     0,     0, 1 },  /* saxo */
  {  6950,  4130,     5, 1 },  /* sb */
  {   947,     0,     0, 1 },  /* sbi */
  {  6953,     0,     0, 1 },  /* sbs */
  {  2155,  4130,     5, 1 },  /* sc */
  {  6961,     0,     0, 1 },  /* sca */
  {  6965,     0,     0, 1 },  /* scb */
  {  6969,     0,     0, 1 },  /* schaeffler */
  {  6980,     0,     0, 1 },  /* schmidt */
  {  6988,     0,     0, 1 },  /* scholarships */
  {  7001,     0,     0, 1 },  /* school */
  {  7008,     0,     0, 1 },  /* schule */
  {  7015,     0,     0, 1 },  /* schwarz */
  {  7032,  4395,     1, 1 },  /* science */
  {  7040,     0,     0, 1 },  /* scjohnson */
  {  7050,     0,     0, 1 },  /* scor */
  {  7055,     0,     0, 1 },  /* scot */
  {  5348,  7886,     8, 1 },  /* sd */
  {  1492,  7894,    41, 1 },  /* se */
  {  1379,     0,     0, 1 },  /* search */
  {  2601,     0,     0, 1 },  /* seat */
  {  7079,     0,     0, 1 },  /* secure */
  {  7086,     0,     0, 1 },  /* security */
  {  7095,     0,     0, 1 },  /* seek */
  {  4335,     0,     0, 1 },  /* select */
  {  7100,     0,     0, 1 },  /* sener */
  {  7106,     0,     0, 1 },  /* services */
  {  2084,     0,     0, 1 },  /* ses */
  {  7115,     0,     0, 1 },  /* seven */
  {  7121,     0,     0, 1 },  /* sew */
  {  7127,     0,     0, 1 },  /* sex */
  {  7131,     0,     0, 1 },  /* sexy */
  {  3226,     0,     0, 1 },  /* sfr */
  {  7151,  7935,     7, 1 },  /* sg */
  {  1504,  3735,     9, 1 },  /* sh */
  {  7154,     0,     0, 1 },  /* shangrila */
  {  7164,     0,     0, 1 },  /* sharp */
  {  7170,     0,     0, 1 },  /* shaw */
  {  7175,     0,     0, 1 },  /* shell */
  {  7181,     0,     0, 1 },  /* shia */
  {  7186,     0,     0, 1 },  /* shiksha */
  {  7194,     0,     0, 1 },  /* shoes */
  {  7204,  6895,     1, 1 },  /* shop */
  {  6252,     0,     0, 1 },  /* shopping */
  {  7209,     0,     0, 1 },  /* shouji */
  {  4083,     0,     0, 1 },  /* show */
  {  7216,     0,     0, 1 },  /* showtime */
  {  7225,     0,     0, 1 },  /* shriram */
  {  2361,  7942,     2, 1 },  /* si */
  {  7237,     0,     0, 1 },  /* silk */
  {  7245,     0,     0, 1 },  /* sina */
  {  7250,     0,     0, 1 },  /* singles */
  {  7262,  3744,     4, 1 },  /* site */
  {  7267,     0,     0, 1 },  /* sj */
  {  7271,  6865,     2, 1 },  /* sk */
  {  4550,     0,     0, 1 },  /* ski */
  {  7274,     0,     0, 1 },  /* skin */
  {  4669,     0,     0, 1 },  /* sky */
  {  7279,     0,     0, 1 },  /* skype */
  {  7286,  4130,     5, 1 },  /* sl */
  {  4221,     0,     0, 1 },  /* sling */
  {  7290,     0,     0, 1 },  /* sm */
  {   525,     0,     0, 1 },  /* smart */
  {  7293,     0,     0, 1 },  /* smile */
  {  7300,  7944,     8, 1 },  /* sn */
  {  1604,     0,     0, 1 },  /* sncf */
  {  7304,  7952,     3, 1 },  /* so */
  {  7307,     0,     0, 1 },  /* soccer */
  {  7314,     0,     0, 1 },  /* social */
  {  7321,     0,     0, 1 },  /* softbank */
  {  7330,     0,     0, 1 },  /* software */
  {  4104,     0,     0, 1 },  /* sohu */
  {  7339,     0,     0, 1 },  /* solar */
  {  7345,     0,     0, 1 },  /* solutions */
  {  5959,     0,     0, 1 },  /* song */
  {  7355,     0,     0, 1 },  /* sony */
  {  7362,     0,     0, 1 },  /* soy */
  {  2873,  7955,     4, 1 },  /* space */
  {  7375,     0,     0, 1 },  /* spiegel */
  {  7387,     0,     0, 1 },  /* sport */
  {  7396,     0,     0, 1 },  /* spot */
  {  7401,     0,     0, 1 },  /* spreadbetting */
  {  7416,     0,     0, 1 },  /* sr */
  {  7419,     0,     0, 1 },  /* srl */
  {  7423,     0,     0, 1 },  /* srt */
  {   619,  7959,    14, 1 },  /* st */
  {  7431,     0,     0, 1 },  /* stada */
  {  7437,     0,     0, 1 },  /* staples */
  {  5545,     0,     0, 1 },  /* star */
  {  7445,     0,     0, 1 },  /* starhub */
  {  7453,     0,     0, 1 },  /* statebank */
  {  2927,     0,     0, 1 },  /* statefarm */
  {  7463,     0,     0, 1 },  /* statoil */
  {  7471,     0,     0, 1 },  /* stc */
  {  3729,     0,     0, 1 },  /* stcgroup */
  {  7475,     0,     0, 1 },  /* stockholm */
  {  7485,     0,     0, 1 },  /* storage */
  {  7493,     0,     0, 1 },  /* store */
  {  7499,     0,     0, 1 },  /* stream */
  {  7506,     0,     0, 1 },  /* studio */
  {  7513,     0,     0, 1 },  /* study */
  {  4900,     0,     0, 1 },  /* style */
  {  3289,  7973,    53, 1 },  /* su */
  {  7524,     0,     0, 1 },  /* sucks */
  {  7530,     0,     0, 1 },  /* supplies */
  {  7539,     0,     0, 1 },  /* supply */
  {  7546,  6895,     1, 1 },  /* support */
  {  7554,     0,     0, 1 },  /* surf */
  {  7559,     0,     0, 1 },  /* surgery */
  {  7567,     0,     0, 1 },  /* suzuki */
  {  7574,  8026,     5, 1 },  /* sv */
  {  7577,     0,     0, 1 },  /* swatch */
  {  7584,     0,     0, 1 },  /* swiftcover */
  {  7595,     0,     0, 1 },  /* swiss */
  {  7604,  8031,     2, 1 },  /* sx */
  {  4965,  3904,     6, 1 },  /* sy */
  {  7607,     0,     0, 1 },  /* sydney */
  {  7614,     0,     0, 1 },  /* symantec */
  {  7623,  8033,     1, 1 },  /* systems */
  {  7633,  8034,     3, 1 },  /* sz */
  {  7636,     0,     0, 1 },  /* tab */
  {  7640,     0,     0, 1 },  /* taipei */
  {  7659,     0,     0, 1 },  /* talk */
  {  7664,     0,     0, 1 },  /* taobao */
  {  7671,     0,     0, 1 },  /* target */
  {  7678,     0,     0, 1 },  /* tatamotors */
  {  7689,     0,     0, 1 },  /* tatar */
  {  7695,     0,     0, 1 },  /* tattoo */
  {   662,     0,     0, 1 },  /* tax */
  {  7702,     0,     0, 1 },  /* taxi */
  {  7472,     0,     0, 1 },  /* tc */
  {  1709,     0,     0, 1 },  /* tci */
  {  5071,  4032,     1, 1 },  /* td */
  {  2468,     0,     0, 1 },  /* tdk */
  {  7712,     0,     0, 1 },  /* team */
  {  1617,     0,     0, 1 },  /* tech */
  {  7717,     0,     0, 1 },  /* technology */
  {   279,     0,     0, 1 },  /* tel */
  {  7734,     0,     0, 1 },  /* telecity */
  {  7743,     0,     0, 1 },  /* telefonica */
  {  7754,     0,     0, 1 },  /* temasek */
  {  7762,     0,     0, 1 },  /* tennis */
  {  7769,     0,     0, 1 },  /* teva */
  {  7775,     0,     0, 1 },  /* tf */
  {  7779,     0,     0, 1 },  /* tg */
  {    13,  8037,     7, 1 },  /* th */
  {  7786,     0,     0, 1 },  /* thd */
  {  7790,     0,     0, 1 },  /* theater */
  {  7798,     0,     0, 1 },  /* theatre */
  {  7806,     0,     0, 1 },  /* tiaa */
  {  7811,     0,     0, 1 },  /* tickets */
  {  7819,     0,     0, 1 },  /* tienda */
  {  7826,     0,     0, 1 },  /* tiffany */
  {  7834,     0,     0, 1 },  /* tips */
  {  7839,     0,     0, 1 },  /* tires */
  {  7854,     0,     0, 1 },  /* tirol */
  {  7860,  8044,    16, 1 },  /* tj */
  {  7863,     0,     0, 1 },  /* tjmaxx */
  {  7870,     0,     0, 1 },  /* tjx */
  {  7874,     0,     0, 1 },  /* tk */
  {  7877,     0,     0, 1 },  /* tkmaxx */
  {  7886,  4046,     1, 1 },  /* tl */
  {  7890,  8060,     8, 1 },  /* tm */
  {  7893,     0,     0, 1 },  /* tmall */
  {  5570,  8068,    20, 1 },  /* tn */
  {   631,  8088,     7, 1 },  /* to */
  {  2256,     0,     0, 1 },  /* today */
  {  7904,     0,     0, 1 },  /* tokyo */
  {  7915,     0,     0, 1 },  /* tools */
  {  7929,  8095,     2, 1 },  /* top */
  {  7933,     0,     0, 1 },  /* toray */
  {  7939,     0,     0, 1 },  /* toshiba */
  {  7947,     0,     0, 1 },  /* total */
  {  7953,     0,     0, 1 },  /* tours */
  {  1396,     0,     0, 1 },  /* town */
  {  7959,     0,     0, 1 },  /* toyota */
  {  7966,     0,     0, 1 },  /* toys */
  {  3281,  3748,    21, 1 },  /* tr */
  {  7975,  4395,     1, 1 },  /* trade */
  {  7981,     0,     0, 1 },  /* trading */
  {  7989,     0,     0, 1 },  /* training */
  {  7998,     0,     0, 1 },  /* travel */
  {  1629,     0,     0, 1 },  /* travelchannel */
  {  8005,     0,     0, 1 },  /* travelers */
  {  8015,     0,     0, 1 },  /* travelersinsurance */
  {  8034,     0,     0, 1 },  /* trust */
  {  8040,     0,     0, 1 },  /* trv */
  {    24,  8097,    17, 1 },  /* tt */
  {  8051,     0,     0, 1 },  /* tube */
  {  8056,     0,     0, 1 },  /* tui */
  {  8060,     0,     0, 1 },  /* tunes */
  {  8066,     0,     0, 1 },  /* tushu */
  {  2545,  8114,     4, 1 },  /* tv */
  {  8072,     0,     0, 1 },  /* tvs */
  {  8076,  3769,    16, 1 },  /* tw */
  {  8084,  8119,    12, 1 },  /* tz */
  {  8090,  8131,    82, 1 },  /* ua */
  {   730,     0,     0, 1 },  /* ubank */
  {  8093,     0,     0, 1 },  /* ubs */
  {  8097,     0,     0, 1 },  /* uconnect */
  {  8107,  8213,    10, 1 },  /* ug */
  {  8115,  3785,    12, 1 },  /* uk */
  {  8118,     0,     0, 1 },  /* unicom */
  {  8125,     0,     0, 1 },  /* university */
  {  8139,     0,     0, 1 },  /* uno */
  {  8143,     0,     0, 1 },  /* uol */
  {  6455,     0,     0, 1 },  /* ups */
  {   264,  3797,    69, 1 },  /* us */
  {   911,  3869,     7, 1 },  /* uy */
  {  5847,  8255,     4, 1 },  /* uz */
  {   834,     0,     0, 1 },  /* va */
  {  8157,     0,     0, 1 },  /* vacations */
  {  8167,     0,     0, 1 },  /* vana */
  {  8172,     0,     0, 1 },  /* vanguard */
  {  6510,  8259,     7, 1 },  /* vc */
  {   125,  8266,    17, 1 },  /* ve */
  {  8181,     0,     0, 1 },  /* vegas */
  {  8187,     0,     0, 1 },  /* ventures */
  {  8196,     0,     0, 1 },  /* verisign */
  {  8205,     0,     0, 1 },  /* versicherung */
  {  8223,     0,     0, 1 },  /* vet */
  {  8228,  3911,     1, 1 },  /* vg */
  {  8231,  8283,     5, 1 },  /* vi */
  {  8234,     0,     0, 1 },  /* viajes */
  {  8241,     0,     0, 1 },  /* video */
  {  8247,     0,     0, 1 },  /* vig */
  {  8251,     0,     0, 1 },  /* viking */
  {  8258,     0,     0, 1 },  /* villas */
  {  8269,     0,     0, 1 },  /* vin */
  {  8273,     0,     0, 1 },  /* vip */
  {  8277,     0,     0, 1 },  /* virgin */
  {  8284,     0,     0, 1 },  /* visa */
  {  2803,     0,     0, 1 },  /* vision */
  {  8302,     0,     0, 1 },  /* vista */
  {  8308,     0,     0, 1 },  /* vistaprint */
  {  8319,     0,     0, 1 },  /* viva */
  {  8324,     0,     0, 1 },  /* vivo */
  {  8329,     0,     0, 1 },  /* vlaanderen */
  {  8348,  8288,    13, 1 },  /* vn */
  {  8351,     0,     0, 1 },  /* vodka */
  {  8357,     0,     0, 1 },  /* volkswagen */
  {  8368,     0,     0, 1 },  /* volvo */
  {  8374,     0,     0, 1 },  /* vote */
  {  8379,     0,     0, 1 },  /* voting */
  {  8386,     0,     0, 1 },  /* voto */
  {  8391,     0,     0, 1 },  /* voyage */
  {  8398,  4334,     4, 1 },  /* vu */
  {  8401,     0,     0, 1 },  /* vuelos */
  {  8408,     0,     0, 1 },  /* wales */
  {  8414,     0,     0, 1 },  /* walmart */
  {  8422,     0,     0, 1 },  /* walter */
  {  8429,     0,     0, 1 },  /* wang */
  {  8434,     0,     0, 1 },  /* wanggou */
  {  8442,     0,     0, 1 },  /* warman */
  {  7578,     0,     0, 1 },  /* watch */
  {  8449,     0,     0, 1 },  /* watches */
  {  8457,     0,     0, 1 },  /* weather */
  {  8465,     0,     0, 1 },  /* weatherchannel */
  {  8480,     0,     0, 1 },  /* webcam */
  {  8487,     0,     0, 1 },  /* weber */
  {  8496,     0,     0, 1 },  /* website */
  {  8504,     0,     0, 1 },  /* wed */
  {  8508,     0,     0, 1 },  /* wedding */
  {  8516,     0,     0, 1 },  /* weibo */
  {  8522,     0,     0, 1 },  /* weir */
  {  8527,     0,     0, 1 },  /* wf */
  {  8530,     0,     0, 1 },  /* whoswho */
  {  8538,     0,     0, 1 },  /* wien */
  {  8550,     0,     0, 1 },  /* wiki */
  {  8555,     0,     0, 1 },  /* williamhill */
  {  8567,     0,     0, 1 },  /* win */
  {  8571,     0,     0, 1 },  /* windows */
  {  8579,     0,     0, 1 },  /* wine */
  {  8584,     0,     0, 1 },  /* winners */
  {  5290,     0,     0, 1 },  /* wme */
  {  8592,     0,     0, 1 },  /* wolterskluwer */
  {  8606,     0,     0, 1 },  /* woodside */
  {  3170,     0,     0, 1 },  /* work */
  {  8615,     0,     0, 1 },  /* works */
  {  8621,     0,     0, 1 },  /* world */
  {  8627,     0,     0, 1 },  /* wow */
  {   659,  3876,     9, 1 },  /* ws */
  {  8631,     0,     0, 1 },  /* wtc */
  {  7774,     0,     0, 1 },  /* wtf */
  {  1171,     0,     0, 1 },  /* xbox */
  {  3296,     0,     0, 1 },  /* xerox */
  {  8635,     0,     0, 1 },  /* xfinity */
  {  8643,     0,     0, 1 },  /* xihuan */
  {  8650,     0,     0, 1 },  /* xin */
  {  8654,     0,     0, 1 },  /* xn--11b4c3d */
  {  8666,     0,     0, 1 },  /* xn--1ck2e1b */
  {  8678,     0,     0, 1 },  /* xn--1qqw23a */
  {  8690,     0,     0, 1 },  /* xn--2scrj9c */
  {  8702,     0,     0, 1 },  /* xn--30rr7y */
  {  8713,     0,     0, 1 },  /* xn--3bst00m */
  {  8725,     0,     0, 1 },  /* xn--3ds443g */
  {  8737,     0,     0, 1 },  /* xn--3e0b707e */
  {  8750,     0,     0, 1 },  /* xn--3hcrj9c */
  {  8762,     0,     0, 1 },  /* xn--3oq18vl8pn36a */
  {  8780,     0,     0, 1 },  /* xn--3pxu8k */
  {  8791,     0,     0, 1 },  /* xn--42c2d9a */
  {  8803,     0,     0, 1 },  /* xn--45br5cyl */
  {  8816,     0,     0, 1 },  /* xn--45brj9c */
  {  8828,     0,     0, 1 },  /* xn--45q11c */
  {  8839,     0,     0, 1 },  /* xn--4gbrim */
  {  8850,     0,     0, 1 },  /* xn--54b7fta0cc */
  {  8865,     0,     0, 1 },  /* xn--55qw42g */
  {  8877,     0,     0, 1 },  /* xn--55qx5d */
  {  7136,     0,     0, 1 },  /* xn--5su34j936bgsg */
  {  8888,     0,     0, 1 },  /* xn--5tzm5g */
  {  8899,     0,     0, 1 },  /* xn--6frz82g */
  {  8911,     0,     0, 1 },  /* xn--6qq986b3xl */
  {  8926,     0,     0, 1 },  /* xn--80adxhks */
  {  8939,     0,     0, 1 },  /* xn--80ao21a */
  {  8951,     0,     0, 1 },  /* xn--80aqecdr1a */
  {  8966,     0,     0, 1 },  /* xn--80asehdb */
  {  8979,     0,     0, 1 },  /* xn--80aswg */
  {  8990,     0,     0, 1 },  /* xn--8y0a063a */
  {  9003,  8301,     6, 1 },  /* xn--90a3ac */
  {  9014,     0,     0, 1 },  /* xn--90ae */
  {  9023,     0,     0, 1 },  /* xn--90ais */
  {  9033,     0,     0, 1 },  /* xn--9dbq2a */
  {  9044,     0,     0, 1 },  /* xn--9et52u */
  {  9055,     0,     0, 1 },  /* xn--9krt00a */
  {  9067,     0,     0, 1 },  /* xn--b4w605ferd */
  {  9082,     0,     0, 1 },  /* xn--bck1b9a5dre4c */
  {  9100,     0,     0, 1 },  /* xn--c1avg */
  {  9110,     0,     0, 1 },  /* xn--c2br7g */
  {  9121,     0,     0, 1 },  /* xn--cck2b3b */
  {  9133,     0,     0, 1 },  /* xn--cg4bki */
  {  9144,     0,     0, 1 },  /* xn--clchc0ea0b2g2a9gcd */
  {  9167,     0,     0, 1 },  /* xn--czr694b */
  {  9179,     0,     0, 1 },  /* xn--czrs0t */
  {  9190,     0,     0, 1 },  /* xn--czru2d */
  {  9201,     0,     0, 1 },  /* xn--d1acj3b */
  {  9213,     0,     0, 1 },  /* xn--d1alf */
  {  9223,     0,     0, 1 },  /* xn--e1a4c */
  {  9233,     0,     0, 1 },  /* xn--eckvdtc9d */
  {  9247,     0,     0, 1 },  /* xn--efvy88h */
  {  9259,     0,     0, 1 },  /* xn--estv75g */
  {  9271,     0,     0, 1 },  /* xn--fct429k */
  {  9283,     0,     0, 1 },  /* xn--fhbei */
  {  9293,     0,     0, 1 },  /* xn--fiq228c5hs */
  {  9308,     0,     0, 1 },  /* xn--fiq64b */
  {  9319,     0,     0, 1 },  /* xn--fiqs8s */
  {  9330,     0,     0, 1 },  /* xn--fiqz9s */
  {  9341,     0,     0, 1 },  /* xn--fjq720a */
  {  9353,     0,     0, 1 },  /* xn--flw351e */
  {  9365,     0,     0, 1 },  /* xn--fpcrj9c3d */
  {  9379,     0,     0, 1 },  /* xn--fzc2c9e2c */
  {  3555,     0,     0, 1 },  /* xn--fzys8d69uvgm */
  {  9393,     0,     0, 1 },  /* xn--g2xx48c */
  {  9405,     0,     0, 1 },  /* xn--gckr3f0f */
  {  9418,     0,     0, 1 },  /* xn--gecrj9c */
  {  9430,     0,     0, 1 },  /* xn--gk3at1e */
  {  9442,     0,     0, 1 },  /* xn--h2breg3eve */
  {  9457,     0,     0, 1 },  /* xn--h2brj9c */
  {  9469,     0,     0, 1 },  /* xn--h2brj9c8c */
  {  9483,     0,     0, 1 },  /* xn--hxt814e */
  {  9495,     0,     0, 1 },  /* xn--i1b6b1a6a2e */
  {  9511,     0,     0, 1 },  /* xn--imr513n */
  {  9523,     0,     0, 1 },  /* xn--io0a7i */
  {  9534,     0,     0, 1 },  /* xn--j1aef */
  {  5351,     0,     0, 1 },  /* xn--j1amh */
  {  9544,  8307,     6, 1 },  /* xn--j6w193g */
  {  9556,     0,     0, 1 },  /* xn--jlq61u9w7b */
  {  9571,     0,     0, 1 },  /* xn--jvr189m */
  {  9583,     0,     0, 1 },  /* xn--kcrx77d1x4a */
  {  9599,     0,     0, 1 },  /* xn--kprw13d */
  {  9611,     0,     0, 1 },  /* xn--kpry57d */
  {  9623,     0,     0, 1 },  /* xn--kpu716f */
  {  9635,     0,     0, 1 },  /* xn--kput3i */
  {  1566,     0,     0, 1 },  /* xn--l1acc */
  {  9646,     0,     0, 1 },  /* xn--lgbbat1ad8j */
  {  9662,     0,     0, 1 },  /* xn--mgb2ddes */
  {   918,     0,     0, 1 },  /* xn--mgb9awbf */
  {  9675,     0,     0, 1 },  /* xn--mgba3a3ejt */
  {  9690,     0,     0, 1 },  /* xn--mgba3a4f16a */
  {  9706,     0,     0, 1 },  /* xn--mgba3a4fra */
  {  9721,     0,     0, 1 },  /* xn--mgba7c0bbn0a */
  {  9738,     0,     0, 1 },  /* xn--mgbaakc7dvf */
  {  9754,     0,     0, 1 },  /* xn--mgbaam7a8h */
  {   845,     0,     0, 1 },  /* xn--mgbab2bd */
  {  9769,     0,     0, 1 },  /* xn--mgbai9a5eva00b */
  {  9788,     0,     0, 1 },  /* xn--mgbai9azgqp6j */
  {  9806,     0,     0, 1 },  /* xn--mgbayh7gpa */
  {  9821,     0,     0, 1 },  /* xn--mgbb9fbpob */
  {  9836,     0,     0, 1 },  /* xn--mgbbh1a */
  {  9848,     0,     0, 1 },  /* xn--mgbbh1a71e */
  {  9863,     0,     0, 1 },  /* xn--mgbc0a9azcg */
  {  9879,     0,     0, 1 },  /* xn--mgbca7dzdo */
  {  9894,     0,     0, 1 },  /* xn--mgberp4a5d4a87g */
  {  9914,     0,     0, 1 },  /* xn--mgberp4a5d4ar */
  {  9932,     0,     0, 1 },  /* xn--mgbgu82a */
  {  9945,     0,     0, 1 },  /* xn--mgbi4ecexp */
  {  9960,     0,     0, 1 },  /* xn--mgbpl2fh */
  {  9973,     0,     0, 1 },  /* xn--mgbqly7c0a67fbc */
  {  9993,     0,     0, 1 },  /* xn--mgbqly7cvafr */
  { 10010,     0,     0, 1 },  /* xn--mgbt3dhd */
  { 10023,     0,     0, 1 },  /* xn--mgbtf8fl */
  { 10036,     0,     0, 1 },  /* xn--mgbtx2b */
  { 10048,     0,     0, 1 },  /* xn--mgbx4cd0ab */
  { 10063,     0,     0, 1 },  /* xn--mix082f */
  { 10075,     0,     0, 1 },  /* xn--mix891f */
  { 10087,     0,     0, 1 },  /* xn--mk1bu44c */
  { 10100,     0,     0, 1 },  /* xn--mxtq1m */
  { 10111,     0,     0, 1 },  /* xn--ngbc5azd */
  { 10124,     0,     0, 1 },  /* xn--ngbe9e0a */
  { 10137,     0,     0, 1 },  /* xn--ngbrx */
  { 10147,     0,     0, 1 },  /* xn--nnx388a */
  { 10159,     0,     0, 1 },  /* xn--node */
  { 10168,     0,     0, 1 },  /* xn--nqv7f */
  { 10178,     0,     0, 1 },  /* xn--nqv7fs00ema */
  { 10194,     0,     0, 1 },  /* xn--nyqy26a */
  { 10206,  8313,     6, 1 },  /* xn--o3cw4h */
  { 10217,     0,     0, 1 },  /* xn--ogbpf8fl */
  { 10230,     0,     0, 1 },  /* xn--otu796d */
  { 10242,     0,     0, 1 },  /* xn--p1acf */
  { 10252,     0,     0, 1 },  /* xn--p1ai */
  { 10261,     0,     0, 1 },  /* xn--pbt977c */
  { 10273,     0,     0, 1 },  /* xn--pgbs0dh */
  { 10285,     0,     0, 1 },  /* xn--pssy2u */
  { 10296,     0,     0, 1 },  /* xn--q9jyb4c */
  {  5264,     0,     0, 1 },  /* xn--qcka1pmc */
  { 10308,     0,     0, 1 },  /* xn--qxam */
  { 10317,     0,     0, 1 },  /* xn--rhqv96g */
  { 10329,     0,     0, 1 },  /* xn--rovu88b */
  { 10341,     0,     0, 1 },  /* xn--rvc1e0am3e */
  { 10356,     0,     0, 1 },  /* xn--s9brj9c */
  { 10368,     0,     0, 1 },  /* xn--ses554g */
  { 10380,     0,     0, 1 },  /* xn--t60b56a */
  { 10392,     0,     0, 1 },  /* xn--tckwe */
  { 10402,     0,     0, 1 },  /* xn--tiq49xqyj */
  { 10416,     0,     0, 1 },  /* xn--unup4y */
  { 10427,     0,     0, 1 },  /* xn--vermgensberater-ctb */
  { 10451,     0,     0, 1 },  /* xn--vermgensberatung-pwb */
  { 10476,     0,     0, 1 },  /* xn--vhquv */
  { 10486,     0,     0, 1 },  /* xn--vuq861b */
  { 10498,     0,     0, 1 },  /* xn--w4r85el8fhu5dnra */
  { 10519,     0,     0, 1 },  /* xn--w4rs40l */
  { 10531,     0,     0, 1 },  /* xn--wgbh1c */
  { 10542,     0,     0, 1 },  /* xn--wgbl6a */
  { 10553,     0,     0, 1 },  /* xn--xhq521b */
  { 10565,     0,     0, 1 },  /* xn--xkc2al3hye2a */
  { 10582,     0,     0, 1 },  /* xn--xkc2dl3a5ee0h */
  { 10600,     0,     0, 1 },  /* xn--y9a3aq */
  { 10611,     0,     0, 1 },  /* xn--yfro4i67o */
  { 10625,     0,     0, 1 },  /* xn--ygbi2ammx */
  { 10639,     0,     0, 1 },  /* xn--zfr164b */
  { 10651,     0,     0, 1 },  /* xperia */
  { 10658,     0,     0, 1 },  /* xxx */
  { 10662,  8319,     4, 1 },  /* xyz */
  { 10666,     0,     0, 1 },  /* yachts */
  { 10673,     0,     0, 1 },  /* yahoo */
  { 10679,     0,     0, 1 },  /* yamaxun */
  { 10687,     0,     0, 1 },  /* yandex */
  { 10694,  4048,     1, 0 },  /* ye */
  { 10697,     0,     0, 1 },  /* yodobashi */
  { 10715,     0,     0, 1 },  /* yoga */
  { 10720,     0,     0, 1 },  /* yokohama */
  {  2191,     0,     0, 1 },  /* you */
  {  8048,     0,     0, 1 },  /* youtube */
  { 10729,     0,     0, 1 },  /* yt */
  { 10732,     0,     0, 1 },  /* yun */
  {  6272,  3885,    17, 0 },  /* za */
  { 10741,     0,     0, 1 },  /* zappos */
  { 10748,     0,     0, 1 },  /* zara */
  { 10753,     0,     0, 1 },  /* zero */
  { 10758,     0,     0, 1 },  /* zip */
  { 10762,     0,     0, 1 },  /* zippo */
  { 10768,  8323,    11, 1 },  /* zm */
  { 10774,  3902,     2, 1 },  /* zone */
  {  6722,     0,     0, 1 },  /* zuerich */
  { 10779,  8334,     5, 1 },  /* zw */
  {  1910,  4032,     1, 1 },  /* com.ar */
  {  2622,     0,     0, 1 },  /* edu.ar */
  { 11461,     0,     0, 1 },  /* gob.ar */
  {  3665,     0,     0, 1 },  /* gov.ar */
  {  3611,     0,     0, 1 },  /* int.ar */
  {  4157,     0,     0, 1 },  /* mil.ar */
  { 11465,     0,     0, 1 },  /* musica.ar */
  {  5710,     0,     0, 1 },  /* net.ar */
  {  6026,     0,     0, 1 },  /* org.ar */
  { 11478,     0,     0, 1 },  /* tur.ar */
  { 11518,     0,     0, 1 },  /* 12hp.at */
  { 11523,     0,     0, 1 },  /* 2ix.at */
  { 11527,     0,     0, 1 },  /* 4lima.at */
  {    62,     0,     0, 1 },  /* ac.at */
  {   986,     0,     0, 1 },  /* biz.at */
  {   113,  4032,     1, 1 },  /* co.at */
  { 11533,  1580,     3, 0 },  /* futurecms.at */
  { 11543,     0,     0, 1 },  /* futurehosting.at */
  { 11557,     0,     0, 1 },  /* futuremailing.at */
  { 11443,     0,     0, 1 },  /* gv.at */
  {  3149,     0,     0, 1 },  /* info.at */
  { 11571,     0,     0, 1 },  /* lima-city.at */
  {   137,     0,     0, 1 },  /* or.at */
  { 11585,  1583,     2, 0 },  /* ortsinfo.at */
  { 11594,     0,     0, 1 },  /* priv.at */
  { 11599,     0,     0, 1 },  /* *.futurecms.at */
  {   397,  4048,     1, 0 },  /* ex.futurecms.at */
  {   898,  4048,     1, 0 },  /* in.futurecms.at */
  {   397,  4048,     1, 0 },  /* ex.ortsinfo.at */
  { 11606,  4048,     1, 0 },  /* kunden.ortsinfo.at */
  {  2000,     0,     0, 1 },  /* act.au */
  {  7299,     0,     0, 1 },  /* asn.au */
  {  1910,  4032,     1, 1 },  /* com.au */
  { 11613,     0,     0, 1 },  /* conf.au */
  {  2622,  4049,     8, 1 },  /* edu.au */
  {  3665,  4057,     5, 1 },  /* gov.au */
  {   437,     0,     0, 1 },  /* id.au */
  {  3149,     0,     0, 1 },  /* info.au */
  {  5710,     0,     0, 1 },  /* net.au */
  { 11618,     0,     0, 1 },  /* nsw.au */
  {    97,     0,     0, 1 },  /* nt.au */
  {  6026,     0,     0, 1 },  /* org.au */
  { 11627,     0,     0, 1 },  /* oz.au */
  { 11630,     0,     0, 1 },  /* qld.au */
  {  1487,     0,     0, 1 },  /* sa.au */
  {   536,     0,     0, 1 },  /* tas.au */
  { 11635,     0,     0, 1 },  /* vic.au */
  {  5916,     0,     0, 1 },  /* wa.au */
  {    62,     0,     0, 1 },  /* ac.be */
  { 10791,     0,     0, 1 },  /* blogspot.be */
  { 11650,  4048,     1, 0 },  /* transurl.be */
  {  4031,     0,     0, 1 },  /* webhosting.be */
  { 12079,     0,     0, 1 },  /* 9guacu.br */
  {    34,     0,     0, 1 },  /* abc.br */
  {  2472,     0,     0, 1 },  /* adm.br */
  { 12086,     0,     0, 1 },  /* adv.br */
  {  3675,     0,     0, 1 },  /* agr.br */
  { 12090,     0,     0, 1 },  /* aju.br */
  {   358,     0,     0, 1 },  /* am.br */
  { 12094,     0,     0, 1 },  /* anani.br */
  { 12100,     0,     0, 1 },  /* aparecida.br */
  { 12110,     0,     0, 1 },  /* arq.br */
  {   527,     0,     0, 1 },  /* art.br */
  { 12115,     0,     0, 1 },  /* ato.br */
  {    18,     0,     0, 1 },  /* b.br */
  { 12119,     0,     0, 1 },  /* barueri.br */
  { 12127,     0,     0, 1 },  /* belem.br */
  { 12133,     0,     0, 1 },  /* bhz.br */
  {   981,     0,     0, 1 },  /* bio.br */
  {  1035,     0,     0, 1 },  /* blog.br */
  {  5286,     0,     0, 1 },  /* bmd.br */
  { 12137,     0,     0, 1 },  /* boavista.br */
  {  6949,     0,     0, 1 },  /* bsb.br */
  { 12146,     0,     0, 1 },  /* campinagrande.br */
  { 12160,     0,     0, 1 },  /* campinas.br */
  { 12169,     0,     0, 1 },  /* caxias.br */
  {  4161,     0,     0, 1 },  /* cim.br */
  {  5777,     0,     0, 1 },  /* cng.br */
  { 11622,     0,     0, 1 },  /* cnt.br */
  {  1910,  4032,     1, 1 },  /* com.br */
  { 12176,     0,     0, 1 },  /* contagem.br */
  {  2044,     0,     0, 1 },  /* coop.br */
  { 12185,     0,     0, 1 },  /* cri.br */
  { 12189,     0,     0, 1 },  /* cuiaba.br */
  { 12196,     0,     0, 1 },  /* curitiba.br */
  { 12205,     0,     0, 1 },  /* def.br */
  {  1863,     0,     0, 1 },  /* ecn.br */
  {  2612,     0,     0, 1 },  /* eco.br */
  {  2622,     0,     0, 1 },  /* edu.br */
  {  5550,     0,     0, 1 },  /* emp.br */
  { 12209,     0,     0, 1 },  /* eng.br */
  { 12213,     0,     0, 1 },  /* esp.br */
  {  7707,     0,     0, 1 },  /* etc.br */
  { 12219,     0,     0, 1 },  /* eti.br */
  {   493,     0,     0, 1 },  /* far.br */
  { 12223,     0,     0, 1 },  /* feira.br */
  { 12229,     0,     0, 1 },  /* flog.br */
  { 12234,     0,     0, 1 },  /* floripa.br */
  {  3144,     0,     0, 1 },  /* fm.br */
  { 12242,     0,     0, 1 },  /* fnd.br */
  { 12246,     0,     0, 1 },  /* fortal.br */
  { 12253,     0,     0, 1 },  /* fot.br */
  { 11626,     0,     0, 1 },  /* foz.br */
  {  7427,     0,     0, 1 },  /* fst.br */
  { 12257,     0,     0, 1 },  /* g12.br */
  {  3464,     0,     0, 1 },  /* ggf.br */
  { 12261,     0,     0, 1 },  /* goiania.br */
  {  3665,  4197,    27, 1 },  /* gov.br */
  {  6817,     0,     0, 1 },  /* gru.br */
  { 12269,     0,     0, 1 },  /* imb.br */
  { 12273,     0,     0, 1 },  /* ind.br */
  {  5769,     0,     0, 1 },  /* inf.br */
  { 12277,     0,     0, 1 },  /* jab.br */
  { 12281,     0,     0, 1 },  /* jampa.br */
  { 12287,     0,     0, 1 },  /* jdf.br */
  { 12291,     0,     0, 1 },  /* joinville.br */
  { 11581,     0,     0, 1 },  /* jor.br */
  {  8147,     0,     0, 1 },  /* jus.br */
  {  2644,  4197,    27, 1 },  /* leg.br */
  { 12301,     0,     0, 1 },  /* lel.br */
  { 12305,     0,     0, 1 },  /* londrina.br */
  { 12314,     0,     0, 1 },  /* macapa.br */
  { 12321,     0,     0, 1 },  /* maceio.br */
  { 12328,     0,     0, 1 },  /* manaus.br */
  { 12335,     0,     0, 1 },  /* maringa.br */
  {  4168,     0,     0, 1 },  /* mat.br */
  {  1855,     0,     0, 1 },  /* med.br */
  {  4157,     0,     0, 1 },  /* mil.br */
  { 12343,     0,     0, 1 },  /* morena.br */
  {  1368,     0,     0, 1 },  /* mp.br */
  { 12350,     0,     0, 1 },  /* mus.br */
  { 12354,     0,     0, 1 },  /* natal.br */
  {  5710,     0,     0, 1 },  /* net.br */
  { 12360,     0,     0, 1 },  /* niteroi.br */
  {  5943,  4048,     1, 0 },  /* nom.br */
  { 12368,     0,     0, 1 },  /* not.br */
  {  7971,     0,     0, 1 },  /* ntr.br */
  {  2481,     0,     0, 1 },  /* odo.br */
  {  6026,     0,     0, 1 },  /* org.br */
  { 12372,     0,     0, 1 },  /* osasco.br */
  { 12379,     0,     0, 1 },  /* palmas.br */
  { 12395,     0,     0, 1 },  /* poa.br */
  {  6153,     0,     0, 1 },  /* ppg.br */
  {  6376,     0,     0, 1 },  /* pro.br */
  {  6957,     0,     0, 1 },  /* psc.br */
  {  7233,     0,     0, 1 },  /* psi.br */
  { 12399,     0,     0, 1 },  /* pvh.br */
  {  7285,     0,     0, 1 },  /* qsl.br */
  {  6520,     0,     0, 1 },  /* radio.br */
  { 12406,     0,     0, 1 },  /* rec.br */
  { 12410,     0,     0, 1 },  /* recife.br */
  { 12417,     0,     0, 1 },  /* ribeirao.br */
  {  6766,     0,     0, 1 },  /* rio.br */
  { 12426,     0,     0, 1 },  /* riobranco.br */
  { 12436,     0,     0, 1 },  /* riopreto.br */
  { 12445,     0,     0, 1 },  /* salvador.br */
  { 12454,     0,     0, 1 },  /* sampa.br */
  { 12460,     0,     0, 1 },  /* santamaria.br */
  { 12471,     0,     0, 1 },  /* santoandre.br */
  { 12482,     0,     0, 1 },  /* saobernardo.br */
  { 12494,     0,     0, 1 },  /* saogonca.br */
  { 12503,     0,     0, 1 },  /* sjc.br */
  { 12507,     0,     0, 1 },  /* slg.br */
  { 12511,     0,     0, 1 },  /* slz.br */
  { 12515,     0,     0, 1 },  /* sorocaba.br */
  { 12524,     0,     0, 1 },  /* srv.br */
  {  7702,     0,     0, 1 },  /* taxi.br */
  { 12528,     0,     0, 1 },  /* teo.br */
  { 11778,     0,     0, 1 },  /* the.br */
  { 12532,     0,     0, 1 },  /* tmp.br */
  { 12536,     0,     0, 1 },  /* trd.br */
  { 11478,     0,     0, 1 },  /* tur.br */
  {  2545,     0,     0, 1 },  /* tv.br */
  {   596,     0,     0, 1 },  /* udi.br */
  {  8223,     0,     0, 1 },  /* vet.br */
  { 12540,     0,     0, 1 },  /* vix.br */
  { 12544,     0,     0, 1 },  /* vlog.br */
  {  8550,     0,     0, 1 },  /* wiki.br */
  { 12549,     0,     0, 1 },  /* zlg.br */
  {  1910,  4032,     1, 1 },  /* com.by */
  {  3665,     0,     0, 1 },  /* gov.by */
  {  4157,     0,     0, 1 },  /* mil.by */
  { 12575,     0,     0, 1 },  /* nym.by */
  {  6399,     0,     0, 1 },  /* of.by */
  {   499,     0,     0, 1 },  /* ab.ca */
  {  2377,  4048,     1, 0 },  /* awdev.ca */
  {    35,     0,     0, 1 },  /* bc.ca */
  { 10791,     0,     0, 1 },  /* blogspot.ca */
  {   113,     0,     0, 1 },  /* co.ca */
  { 12579,     0,     0, 1 },  /* gc.ca */
  { 12270,     0,     0, 1 },  /* mb.ca */
  { 12584,     0,     0, 1 },  /* nb.ca */
  {  5770,     0,     0, 1 },  /* nf.ca */
  {  1072,     0,     0, 1 },  /* nl.ca */
  { 11795,     0,     0, 1 },  /* no-ip.ca */
  {   786,     0,     0, 1 },  /* ns.ca */
  {    97,     0,     0, 1 },  /* nt.ca */
  {  5339,     0,     0, 1 },  /* nu.ca */
  {   592,     0,     0, 1 },  /* on.ca */
  {  3718,     0,     0, 1 },  /* pe.ca */
  { 11698,     0,     0, 1 },  /* qc.ca */
  {  7271,     0,     0, 1 },  /* sk.ca */
  { 11707,     0,     0, 1 },  /* yk.ca */
  { 12716,     0,     0, 1 },  /* linkyard.cloud */
  { 12725,  4048,     1, 0 },  /* magentosite.cloud */
  { 12737,  4048,     1, 0 },  /* sensiosite.cloud */
  { 12748,  4048,     1, 0 },  /* statics.cloud */
  { 12756,     0,     0, 1 },  /* trafficplex.cloud */
  { 12768,     0,     0, 1 },  /* vapor.cloud */
  {    62,     0,     0, 1 },  /* ac.cn */
  { 12776,     0,     0, 1 },  /* ah.cn */
  {   990,     0,     0, 1 },  /* bj.cn */
  {  1910,  1808,     1, 1 },  /* com.cn */
  { 11713,     0,     0, 1 },  /* cq.cn */
  {  2622,     0,     0, 1 },  /* edu.cn */
  {  3096,     0,     0, 1 },  /* fj.cn */
  {  3428,     0,     0, 1 },  /* gd.cn */
  {  3665,     0,     0, 1 },  /* gov.cn */
  {  3739,     0,     0, 1 },  /* gs.cn */
  { 11722,     0,     0, 1 },  /* gx.cn */
  { 12779,     0,     0, 1 },  /* gz.cn */
  {  2514,     0,     0, 1 },  /* ha.cn */
  { 12806,     0,     0, 1 },  /* hb.cn */
  { 11779,     0,     0, 1 },  /* he.cn */
  {   512,     0,     0, 1 },  /* hi.cn */
  {  3916,     0,     0, 1 },  /* hk.cn */
  {  2384,     0,     0, 1 },  /* hl.cn */
  {  3930,     0,     0, 1 },  /* hn.cn */
  { 11710,     0,     0, 1 },  /* jl.cn */
  { 11719,     0,     0, 1 },  /* js.cn */
  {  7871,     0,     0, 1 },  /* jx.cn */
  {  4604,     0,     0, 1 },  /* ln.cn */
  {  4157,     0,     0, 1 },  /* mil.cn */
  {  3579,     0,     0, 1 },  /* mo.cn */
  {  5710,     0,     0, 1 },  /* net.cn */
  { 12825,     0,     0, 1 },  /* nm.cn */
  { 12830,     0,     0, 1 },  /* nx.cn */
  {  6026,     0,     0, 1 },  /* org.cn */
  { 11704,     0,     0, 1 },  /* qh.cn */
  {  2155,     0,     0, 1 },  /* sc.cn */
  {  5348,     0,     0, 1 },  /* sd.cn */
  {  1504,     0,     0, 1 },  /* sh.cn */
  {  7300,     0,     0, 1 },  /* sn.cn */
  {  7604,     0,     0, 1 },  /* sx.cn */
  {  7860,     0,     0, 1 },  /* tj.cn */
  {  8076,     0,     0, 1 },  /* tw.cn */
  { 12833,     0,     0, 1 },  /* xj.cn */
  {  8877,     0,     0, 1 },  /* xn--55qx5d.cn */
  {  9523,     0,     0, 1 },  /* xn--io0a7i.cn */
  { 12836,     0,     0, 1 },  /* xn--od0alg.cn */
  { 12847,     0,     0, 1 },  /* xz.cn */
  { 12853,     0,     0, 1 },  /* yn.cn */
  { 12856,     0,     0, 1 },  /* zj.cn */
  {   652,  1809,     4, 0 },  /* amazonaws.com.cn */
  { 12859,  4284,     1, 0 },  /* cn-north-1.amazonaws.com.cn */
  { 12870,  4048,     1, 0 },  /* compute.amazonaws.com.cn */
  {  1582,  4285,     1, 0 },  /* eb.amazonaws.com.cn */
  { 12878,  4048,     1, 0 },  /* elb.amazonaws.com.cn */
  {  6118,     0,     0, 1 },  /* arts.co */
  {  1910,  4032,     1, 1 },  /* com.co */
  {  2622,     0,     0, 1 },  /* edu.co */
  { 12882,     0,     0, 1 },  /* firm.co */
  {  3665,     0,     0, 1 },  /* gov.co */
  {  3149,     0,     0, 1 },  /* info.co */
  {  3611,     0,     0, 1 },  /* int.co */
  {  4157,     0,     0, 1 },  /* mil.co */
  { 12564,     0,     0, 1 },  /* mypi.co */
  { 12887,     0,     0, 1 },  /* n4t.co */
  {  5710,     0,     0, 1 },  /* net.co */
  { 12891,     0,     0, 1 },  /* nodum.co */
  {  5943,     0,     0, 1 },  /* nom.co */
  {  6026,     0,     0, 1 },  /* org.co */
  { 12897,  4048,     1, 0 },  /* otap.co */
  { 12406,     0,     0, 1 },  /* rec.co */
  { 12075,     0,     0, 1 },  /* web.co */
  { 12902,     0,     0, 1 },  /* 001www.com */
  {  5406,  4048,     1, 0 },  /* 0emm.com */
  { 12909,     0,     0, 1 },  /* 1kapp.com */
  { 12915,     0,     0, 1 },  /* 3utilities.com */
  { 12934,     0,     0, 1 },  /* 4u.com */
  {   217,     0,     0, 1 },  /* africa.com */
  { 12937,     0,     0, 1 },  /* alpha-myqnapcloud.com */
  {   652,  2133,    42, 0 },  /* amazonaws.com */
  { 12955,     0,     0, 1 },  /* appchizi.com */
  { 12964,     0,     0, 1 },  /* applinzi.com */
  {  7393,     0,     0, 1 },  /* appspot.com */
  {   494,     0,     0, 1 },  /* ar.com */
  { 12973,     0,     0, 1 },  /* barsycenter.com */
  {  5974,     0,     0, 1 },  /* barsyonline.com */
  { 12985,     0,     0, 1 },  /* betainabox.com */
  { 12996,     0,     0, 1 },  /* bitballoon.com */
  { 13007,     0,     0, 1 },  /* blogdns.com */
  { 10791,     0,     0, 1 },  /* blogspot.com */
  { 13015,     0,     0, 1 },  /* blogsyte.com */
  { 13024,     0,     0, 1 },  /* bloxcms.com */
  { 13032,  4286,     2, 1 },  /* bounty-full.com */
  { 13044,     0,     0, 1 },  /* bplaced.com */
  {  1177,     0,     0, 1 },  /* br.com */
  { 13052,     0,     0, 1 },  /* cechire.com */
  { 13060,     0,     0, 1 },  /* ciscofreak.com */
  { 13071,     0,     0, 1 },  /* cloudcontrolapp.com */
  { 13087,     0,     0, 1 },  /* cloudcontrolled.com */
  {   842,     0,     0, 1 },  /* cn.com */
  {   113,     0,     0, 1 },  /* co.com */
  { 13103,     0,     0, 1 },  /* codespot.com */
  { 13112,     0,     0, 1 },  /* damnserver.com */
  { 13123,     0,     0, 1 },  /* dattolocal.com */
  { 13134,     0,     0, 1 },  /* dattorelay.com */
  { 13145,     0,     0, 1 },  /* dattoweb.com */
  {  3230,     0,     0, 1 },  /* ddnsfree.com */
  { 13154,     0,     0, 1 },  /* ddnsgeek.com */
  { 12649,     0,     0, 1 },  /* ddnsking.com */
  {  4968,     0,     0, 1 },  /* ddnslive.com */
  {  2273,     0,     0, 1 },  /* de.com */
  { 13163,     0,     0, 1 },  /* dev-myqnapcloud.com */
  { 13179,     0,     0, 1 },  /* ditchyourip.com */
  { 13191,     0,     0, 1 },  /* dnsalias.com */
  { 13200,     0,     0, 1 },  /* dnsdojo.com */
  { 13208,     0,     0, 1 },  /* dnsiskinky.com */
  { 13219,     0,     0, 1 },  /* doesntexist.com */
  { 13231,     0,     0, 1 },  /* dontexist.com */
  { 13241,     0,     0, 1 },  /* doomdns.com */
  { 13249,     0,     0, 1 },  /* drayddns.com */
  { 13258,     0,     0, 1 },  /* dreamhosters.com */
  { 13271,     0,     0, 1 },  /* dsmynas.com */
  { 13279,     0,     0, 1 },  /* dyn-o-saur.com */
  { 13290,     0,     0, 1 },  /* dynalias.com */
  { 13299,     0,     0, 1 },  /* dyndns-at-home.com */
  { 13314,     0,     0, 1 },  /* dyndns-at-work.com */
  { 13329,     0,     0, 1 },  /* dyndns-blog.com */
  { 13341,     0,     0, 1 },  /* dyndns-free.com */
  { 13353,     0,     0, 1 },  /* dyndns-home.com */
  { 13365,     0,     0, 1 },  /* dyndns-ip.com */
  { 13375,     0,     0, 1 },  /* dyndns-mail.com */
  { 13387,     0,     0, 1 },  /* dyndns-office.com */
  { 13401,     0,     0, 1 },  /* dyndns-pics.com */
  { 13413,     0,     0, 1 },  /* dyndns-remote.com */
  { 13427,     0,     0, 1 },  /* dyndns-server.com */
  { 13441,     0,     0, 1 },  /* dyndns-web.com */
  {  8543,     0,     0, 1 },  /* dyndns-wiki.com */
  { 13452,     0,     0, 1 },  /* dyndns-work.com */
  { 13464,     0,     0, 1 },  /* dynns.com */
  {  7647,  4288,    17, 1 },  /* elasticbeanstalk.com */
  {  5139,     0,     0, 1 },  /* est-a-la-maison.com */
  { 13470,     0,     0, 1 },  /* est-a-la-masion.com */
  { 13486,     0,     0, 1 },  /* est-le-patron.com */
  { 13500,     0,     0, 1 },  /* est-mon-blogueur.com */
  {  2796,     0,     0, 1 },  /* eu.com */
  { 13517,  4305,     8, 0 },  /* evennode.com */
  { 13526,     0,     0, 1 },  /* familyds.com */
  { 13535,     0,     0, 1 },  /* fastvps-server.com */
  { 13550,  4313,     1, 0 },  /* fbsbx.com */
  { 13556,     0,     0, 1 },  /* firebaseapp.com */
  { 13568,     0,     0, 1 },  /* firewall-gateway.com */
  { 13585,     0,     0, 1 },  /* flynnhub.com */
  { 13594,     0,     0, 1 },  /* freebox-os.com */
  { 13605,     0,     0, 1 },  /* freeboxos.com */
  { 13615,     0,     0, 1 },  /* from-ak.com */
  { 13623,     0,     0, 1 },  /* from-al.com */
  { 13631,     0,     0, 1 },  /* from-ar.com */
  { 13639,     0,     0, 1 },  /* from-ca.com */
  { 13647,     0,     0, 1 },  /* from-ct.com */
  { 13655,     0,     0, 1 },  /* from-dc.com */
  { 13663,     0,     0, 1 },  /* from-de.com */
  { 13671,     0,     0, 1 },  /* from-fl.com */
  { 13679,     0,     0, 1 },  /* from-ga.com */
  { 13687,     0,     0, 1 },  /* from-hi.com */
  { 13695,     0,     0, 1 },  /* from-ia.com */
  { 13703,     0,     0, 1 },  /* from-id.com */
  { 13711,     0,     0, 1 },  /* from-il.com */
  { 13719,     0,     0, 1 },  /* from-in.com */
  { 13727,     0,     0, 1 },  /* from-ks.com */
  { 13735,     0,     0, 1 },  /* from-ky.com */
  { 13743,     0,     0, 1 },  /* from-ma.com */
  { 13751,     0,     0, 1 },  /* from-md.com */
  { 13759,     0,     0, 1 },  /* from-mi.com */
  { 13767,     0,     0, 1 },  /* from-mn.com */
  { 13775,     0,     0, 1 },  /* from-mo.com */
  { 13783,     0,     0, 1 },  /* from-ms.com */
  {  5561,     0,     0, 1 },  /* from-mt.com */
  { 13791,     0,     0, 1 },  /* from-nc.com */
  { 13799,     0,     0, 1 },  /* from-nd.com */
  { 13807,     0,     0, 1 },  /* from-ne.com */
  { 13815,     0,     0, 1 },  /* from-nh.com */
  { 13823,     0,     0, 1 },  /* from-nj.com */
  { 12820,     0,     0, 1 },  /* from-nm.com */
  { 13831,     0,     0, 1 },  /* from-nv.com */
  { 13839,     0,     0, 1 },  /* from-oh.com */
  { 13847,     0,     0, 1 },  /* from-ok.com */
  { 13855,     0,     0, 1 },  /* from-or.com */
  { 13863,     0,     0, 1 },  /* from-pa.com */
  {  6346,     0,     0, 1 },  /* from-pr.com */
  { 13871,     0,     0, 1 },  /* from-ri.com */
  { 13879,     0,     0, 1 },  /* from-sc.com */
  {  7060,     0,     0, 1 },  /* from-sd.com */
  { 13887,     0,     0, 1 },  /* from-tn.com */
  { 13895,     0,     0, 1 },  /* from-tx.com */
  { 13903,     0,     0, 1 },  /* from-ut.com */
  { 13911,     0,     0, 1 },  /* from-va.com */
  { 13919,     0,     0, 1 },  /* from-vt.com */
  { 13927,     0,     0, 1 },  /* from-wa.com */
  { 13935,     0,     0, 1 },  /* from-wi.com */
  { 13943,     0,     0, 1 },  /* from-wv.com */
  { 13951,     0,     0, 1 },  /* from-wy.com */
  {  3420,     0,     0, 1 },  /* gb.com */
  { 13959,     0,     0, 1 },  /* geekgalaxy.com */
  { 13970,     0,     0, 1 },  /* getmyip.com */
  { 13978,     0,     0, 1 },  /* giize.com */
  { 13984,     0,     0, 1 },  /* githubusercontent.com */
  { 14002,     0,     0, 1 },  /* gleeze.com */
  { 14009,     0,     0, 1 },  /* googleapis.com */
  { 14020,     0,     0, 1 },  /* googlecode.com */
  { 12658,     0,     0, 1 },  /* gotdns.com */
  { 14031,     0,     0, 1 },  /* gotpantheon.com */
  {  3676,     0,     0, 1 },  /* gr.com */
  { 14043,     0,     0, 1 },  /* health-carereform.com */
  { 14061,     0,     0, 1 },  /* herokuapp.com */
  { 14071,     0,     0, 1 },  /* herokussl.com */
  {  3916,     0,     0, 1 },  /* hk.com */
  { 14081,     0,     0, 1 },  /* hobby-site.com */
  { 14092,     0,     0, 1 },  /* homelinux.com */
  { 14102,     0,     0, 1 },  /* homesecuritymac.com */
  { 14118,     0,     0, 1 },  /* homesecuritypc.com */
  { 14133,     0,     0, 1 },  /* homeunix.com */
  {  4106,     0,     0, 1 },  /* hu.com */
  { 14142,     0,     0, 1 },  /* iamallama.com */
  { 14152,     0,     0, 1 },  /* is-a-anarchist.com */
  { 14167,     0,     0, 1 },  /* is-a-blogger.com */
  { 14180,     0,     0, 1 },  /* is-a-bookkeeper.com */
  { 14196,     0,     0, 1 },  /* is-a-bulls-fan.com */
  { 14211,     0,     0, 1 },  /* is-a-caterer.com */
  { 14224,     0,     0, 1 },  /* is-a-chef.com */
  { 14234,     0,     0, 1 },  /* is-a-conservative.com */
  { 14252,     0,     0, 1 },  /* is-a-cpa.com */
  { 14261,     0,     0, 1 },  /* is-a-cubicle-slave.com */
  {  2330,     0,     0, 1 },  /* is-a-democrat.com */
  { 14280,     0,     0, 1 },  /* is-a-designer.com */
  {  2490,     0,     0, 1 },  /* is-a-doctor.com */
  { 14294,     0,     0, 1 },  /* is-a-financialadvisor.com */
  { 14316,     0,     0, 1 },  /* is-a-geek.com */
  {  3704,     0,     0, 1 },  /* is-a-green.com */
  {  3784,     0,     0, 1 },  /* is-a-guru.com */
  { 14326,     0,     0, 1 },  /* is-a-hard-worker.com */
  { 14343,     0,     0, 1 },  /* is-a-hunter.com */
  { 14355,     0,     0, 1 },  /* is-a-landscaper.com */
  {  4809,     0,     0, 1 },  /* is-a-lawyer.com */
  { 14371,     0,     0, 1 },  /* is-a-liberal.com */
  { 14384,     0,     0, 1 },  /* is-a-libertarian.com */
  { 14401,     0,     0, 1 },  /* is-a-llama.com */
  { 14412,     0,     0, 1 },  /* is-a-musician.com */
  { 14426,     0,     0, 1 },  /* is-a-nascarfan.com */
  { 14441,     0,     0, 1 },  /* is-a-nurse.com */
  { 14452,     0,     0, 1 },  /* is-a-painter.com */
  { 11405,     0,     0, 1 },  /* is-a-personaltrainer.com */
  { 14465,     0,     0, 1 },  /* is-a-photographer.com */
  { 14483,     0,     0, 1 },  /* is-a-player.com */
  {  6667,     0,     0, 1 },  /* is-a-republican.com */
  { 14495,     0,     0, 1 },  /* is-a-rockstar.com */
  { 14509,     0,     0, 1 },  /* is-a-socialist.com */
  { 11385,     0,     0, 1 },  /* is-a-student.com */
  { 14524,     0,     0, 1 },  /* is-a-teacher.com */
  { 14537,     0,     0, 1 },  /* is-a-techie.com */
  { 14549,     0,     0, 1 },  /* is-a-therapist.com */
  {    83,     0,     0, 1 },  /* is-an-accountant.com */
  {   128,     0,     0, 1 },  /* is-an-actor.com */
  { 14564,     0,     0, 1 },  /* is-an-actress.com */
  { 14578,     0,     0, 1 },  /* is-an-anarchist.com */
  { 14594,     0,     0, 1 },  /* is-an-artist.com */
  {  2668,     0,     0, 1 },  /* is-an-engineer.com */
  { 14607,     0,     0, 1 },  /* is-an-entertainer.com */
  { 14625,     0,     0, 1 },  /* is-certified.com */
  { 14638,     0,     0, 1 },  /* is-gone.com */
  { 14646,     0,     0, 1 },  /* is-into-anime.com */
  {  1464,     0,     0, 1 },  /* is-into-cars.com */
  { 14660,     0,     0, 1 },  /* is-into-cartoons.com */
  {  3376,     0,     0, 1 },  /* is-into-games.com */
  { 14677,     0,     0, 1 },  /* is-leet.com */
  { 14685,     0,     0, 1 },  /* is-not-certified.com */
  { 14702,     0,     0, 1 },  /* is-slick.com */
  { 14711,     0,     0, 1 },  /* is-uberleet.com */
  { 14723,     0,     0, 1 },  /* is-with-theband.com */
  { 14739,     0,     0, 1 },  /* isa-geek.com */
  { 14748,     0,     0, 1 },  /* isa-hockeynut.com */
  { 14762,     0,     0, 1 },  /* issmarterthanyou.com */
  { 14779,     0,     0, 1 },  /* jdevcloud.com */
  { 14789,  2202,     1, 0 },  /* joyent.com */
  { 14796,     0,     0, 1 },  /* jpn.com */
  { 14800,     0,     0, 1 },  /* kozow.com */
  {  3107,     0,     0, 1 },  /* kr.com */
  { 14806,     0,     0, 1 },  /* likes-pie.com */
  { 14816,     0,     0, 1 },  /* likescandy.com */
  {  6313,  4314,     1, 0 },  /* lmpm.com */
  { 14827,     0,     0, 1 },  /* logoip.com */
  {  6770,     0,     0, 1 },  /* loseyourip.com */
  { 14834,  4315,     1, 1 },  /* meteorapp.com */
  {   396,     0,     0, 1 },  /* mex.com */
  { 14844,     0,     0, 1 },  /* miniserver.com */
  {  2420,     0,     0, 1 },  /* myactivedirectory.com */
  { 14855,     0,     0, 1 },  /* myasustor.com */
  { 14865,     0,     0, 1 },  /* mydatto.com */
  { 14873,     0,     0, 1 },  /* mydrobo.com */
  { 14881,     0,     0, 1 },  /* myiphost.com */
  { 12943,     0,     0, 1 },  /* myqnapcloud.com */
  { 14890,     0,     0, 1 },  /* myravendb.com */
  {  1341,     0,     0, 1 },  /* mysecuritycamera.com */
  { 14900,     0,     0, 1 },  /* myshopblocks.com */
  { 14913,     0,     0, 1 },  /* mytuleap.com */
  { 14922,     0,     0, 1 },  /* myvnc.com */
  { 14928,     0,     0, 1 },  /* neat-url.com */
  { 14937,     0,     0, 1 },  /* net-freaks.com */
  { 14948,     0,     0, 1 },  /* netlify.com */
  { 14956,     0,     0, 1 },  /* nfshost.com */
  {  1511,     0,     0, 1 },  /* no.com */
  { 14964,     0,     0, 1 },  /* on-aptible.com */
  { 14975,     0,     0, 1 },  /* onthewifi.com */
  {  8151,     0,     0, 1 },  /* ooguy.com */
  { 14985,     0,     0, 1 },  /* operaunite.com */
  { 14996,     0,     0, 1 },  /* outsystemscloud.com */
  { 15012,     0,     0, 1 },  /* ownprovider.com */
  { 15024,     0,     0, 1 },  /* pagefrontapp.com */
  { 15037,     0,     0, 1 },  /* pagespeedmobilizer.com */
  { 15056,     0,     0, 1 },  /* pgfog.com */
  { 15062,     0,     0, 1 },  /* pixolino.com */
  { 15071,     0,     0, 1 },  /* point2this.com */
  { 15082,  4316,     1, 0 },  /* prgmr.com */
  { 15088,     0,     0, 1 },  /* publishproxy.com */
  { 15101,     0,     0, 1 },  /* qa2.com */
  { 11698,     0,     0, 1 },  /* qc.com */
  { 15105,     0,     0, 1 },  /* quicksytes.com */
  { 15116,  4048,     1, 0 },  /* quipelements.com */
  { 15129,     0,     0, 1 },  /* rackmaze.com */
  { 15138,     0,     0, 1 },  /* remotewd.com */
  {  1834,     0,     0, 1 },  /* rhcloud.com */
  {  2187,     0,     0, 1 },  /* ru.com */
  {  1487,     0,     0, 1 },  /* sa.com */
  { 15147,     0,     0, 1 },  /* saves-the-whales.com */
  { 15164,     0,     0, 1 },  /* scrysec.com */
  { 15172,     0,     0, 1 },  /* securitytactics.com */
  { 11801,     0,     0, 1 },  /* selfip.com */
  { 15188,     0,     0, 1 },  /* sells-for-less.com */
  { 15203,     0,     0, 1 },  /* sells-for-u.com */
  { 15215,     0,     0, 1 },  /* servebbs.com */
  {   876,     0,     0, 1 },  /* servebeer.com */
  { 15224,     0,     0, 1 },  /* servecounterstrike.com */
  {  2830,     0,     0, 1 },  /* serveexchange.com */
  { 15243,     0,     0, 1 },  /* serveftp.com */
  { 15252,     0,     0, 1 },  /* servegame.com */
  { 15262,     0,     0, 1 },  /* servehalflife.com */
  { 15276,     0,     0, 1 },  /* servehttp.com */
  { 15286,     0,     0, 1 },  /* servehumour.com */
  { 15298,     0,     0, 1 },  /* serveirc.com */
  { 15307,     0,     0, 1 },  /* servemp3.com */
  { 15316,     0,     0, 1 },  /* servep2p.com */
  {  6222,     0,     0, 1 },  /* servepics.com */
  { 15325,     0,     0, 1 },  /* servequake.com */
  { 15336,     0,     0, 1 },  /* servesarcasm.com */
  { 15349,     0,     0, 1 },  /* simple-url.com */
  { 15363,     0,     0, 1 },  /* sinaapp.com */
  {  6631,     0,     0, 1 },  /* space-to-rent.com */
  {  6536,     0,     0, 1 },  /* stufftoread.com */
  { 10707,     0,     0, 1 },  /* teaches-yoga.com */
  { 15371,     0,     0, 1 },  /* temp-dns.com */
  { 15380,     0,     0, 1 },  /* theworkpc.com */
  { 15390,     0,     0, 1 },  /* townnews-staging.com */
  {  8115,     0,     0, 1 },  /* uk.com */
  { 15407,     0,     0, 1 },  /* unusualperson.com */
  {   264,     0,     0, 1 },  /* us.com */
  {   911,     0,     0, 1 },  /* uy.com */
  { 15360,     0,     0, 1 },  /* vipsinaapp.com */
  {  3531,     0,     0, 1 },  /* withgoogle.com */
  {  8044,     0,     0, 1 },  /* withyoutube.com */
  { 15421,     0,     0, 1 },  /* workisboring.com */
  { 15434,     0,     0, 1 },  /* wpdevcloud.com */
  { 15445,     0,     0, 1 },  /* writesthisblog.com */
  {   674,     0,     0, 1 },  /* xenapponazure.com */
  { 15460,  4317,     2, 1 },  /* xnbay.com */
  { 15466,     0,     0, 1 },  /* yolasite.com */
  {  6272,     0,     0, 1 },  /* za.com */
  { 15478,  2175,     1, 0 },  /* ap-northeast-1.amazonaws.com */
  { 15496,  2176,     3, 0 },  /* ap-northeast-2.amazonaws.com */
  { 15514,  2179,     3, 0 },  /* ap-south-1.amazonaws.com */
  { 15528,  2182,     1, 0 },  /* ap-southeast-1.amazonaws.com */
  { 15546,  2183,     1, 0 },  /* ap-southeast-2.amazonaws.com */
  { 15564,  2184,     3, 0 },  /* ca-central-1.amazonaws.com */
  { 12870,  4048,     1, 0 },  /* compute.amazonaws.com */
  { 15577,  4048,     1, 0 },  /* compute-1.amazonaws.com */
  { 12878,  4048,     1, 0 },  /* elb.amazonaws.com */
  { 15590,  2187,     3, 0 },  /* eu-central-1.amazonaws.com */
  { 15606,  2190,     1, 0 },  /* eu-west-1.amazonaws.com */
  { 15619,  2191,     3, 0 },  /* eu-west-2.amazonaws.com */
  { 15632,  2194,     3, 0 },  /* eu-west-3.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.amazonaws.com */
  { 15475,     0,     0, 1 },  /* s3-ap-northeast-1.amazonaws.com */
  { 15493,     0,     0, 1 },  /* s3-ap-northeast-2.amazonaws.com */
  { 15511,     0,     0, 1 },  /* s3-ap-south-1.amazonaws.com */
  { 15525,     0,     0, 1 },  /* s3-ap-southeast-1.amazonaws.com */
  { 15543,     0,     0, 1 },  /* s3-ap-southeast-2.amazonaws.com */
  { 15561,     0,     0, 1 },  /* s3-ca-central-1.amazonaws.com */
  { 15587,     0,     0, 1 },  /* s3-eu-central-1.amazonaws.com */
  { 15603,     0,     0, 1 },  /* s3-eu-west-1.amazonaws.com */
  { 15616,     0,     0, 1 },  /* s3-eu-west-2.amazonaws.com */
  { 15629,     0,     0, 1 },  /* s3-eu-west-3.amazonaws.com */
  { 15642,     0,     0, 1 },  /* s3-external-1.amazonaws.com */
  { 15656,     0,     0, 1 },  /* s3-fips-us-gov-west-1.amazonaws.com */
  { 15678,     0,     0, 1 },  /* s3-sa-east-1.amazonaws.com */
  { 15691,     0,     0, 1 },  /* s3-us-east-2.amazonaws.com */
  { 15704,     0,     0, 1 },  /* s3-us-gov-west-1.amazonaws.com */
  { 15721,     0,     0, 1 },  /* s3-us-west-1.amazonaws.com */
  { 15734,     0,     0, 1 },  /* s3-us-west-2.amazonaws.com */
  { 15747,     0,     0, 1 },  /* s3-website-ap-northeast-1.amazonaws.com */
  { 15773,     0,     0, 1 },  /* s3-website-ap-southeast-1.amazonaws.com */
  { 15799,     0,     0, 1 },  /* s3-website-ap-southeast-2.amazonaws.com */
  { 15825,     0,     0, 1 },  /* s3-website-eu-west-1.amazonaws.com */
  { 15846,     0,     0, 1 },  /* s3-website-sa-east-1.amazonaws.com */
  { 15867,     0,     0, 1 },  /* s3-website-us-east-1.amazonaws.com */
  { 15888,     0,     0, 1 },  /* s3-website-us-west-1.amazonaws.com */
  { 15909,     0,     0, 1 },  /* s3-website-us-west-2.amazonaws.com */
  { 15681,  2197,     1, 0 },  /* sa-east-1.amazonaws.com */
  { 15878,  2198,     1, 1 },  /* us-east-1.amazonaws.com */
  { 15694,  2199,     3, 0 },  /* us-east-2.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.ap-northeast-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.ap-northeast-2.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.ap-northeast-2.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.ap-northeast-2.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.ap-south-1.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.ap-south-1.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.ap-south-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.ap-southeast-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.ap-southeast-2.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.ca-central-1.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.ca-central-1.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.ca-central-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.eu-central-1.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.eu-central-1.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.eu-central-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.eu-west-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.eu-west-2.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.eu-west-2.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.eu-west-2.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.eu-west-3.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.eu-west-3.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.eu-west-3.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.sa-east-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.us-east-1.amazonaws.com */
  { 15930,  4284,     1, 0 },  /* dualstack.us-east-2.amazonaws.com */
  { 11672,     0,     0, 1 },  /* s3.us-east-2.amazonaws.com */
  {  8493,     0,     0, 1 },  /* s3-website.us-east-2.amazonaws.com */
  { 16012,  4048,     1, 0 },  /* cns.joyent.com */
  {    62,     0,     0, 1 },  /* ac.cy */
  {   986,     0,     0, 1 },  /* biz.cy */
  {  1910,  4032,     1, 1 },  /* com.cy */
  { 16029,     0,     0, 1 },  /* ekloges.cy */
  {  3665,     0,     0, 1 },  /* gov.cy */
  {  5070,     0,     0, 1 },  /* ltd.cy */
  {  5672,     0,     0, 1 },  /* name.cy */
  {  5710,     0,     0, 1 },  /* net.cy */
  {  6026,     0,     0, 1 },  /* org.cy */
  { 16037,     0,     0, 1 },  /* parliament.cy */
  {   371,     0,     0, 1 },  /* press.cy */
  {  6376,     0,     0, 1 },  /* pro.cy */
  {  7890,     0,     0, 1 },  /* tm.cy */
  { 10791,     0,     0, 1 },  /* blogspot.cz */
  {   113,     0,     0, 1 },  /* co.cz */
  { 11675,     0,     0, 1 },  /* e4.cz */
  { 16048,  4341,     2, 0 },  /* metacentrum.cz */
  { 16060,  2222,     1, 0 },  /* muni.cz */
  { 16065,     0,     0, 1 },  /* realm.cz */
  {  1836,  4343,     2, 0 },  /* cloud.muni.cz */
  { 11518,     0,     0, 1 },  /* 12hp.de */
  { 11523,     0,     0, 1 },  /* 2ix.de */
  { 11527,     0,     0, 1 },  /* 4lima.de */
  { 11692,     0,     0, 1 },  /* barsy.de */
  { 10791,     0,     0, 1 },  /* blogspot.de */
  { 13044,     0,     0, 1 },  /* bplaced.de */
  {  1910,     0,     0, 1 },  /* com.de */
  { 16082,  4345,     1, 0 },  /* cosidns.de */
  { 16090,     0,     0, 1 },  /* dd-dns.de */
  { 16097,  4346,     2, 1 },  /* ddnss.de */
  { 16103,     0,     0, 1 },  /* dnshome.de */
  { 16111,     0,     0, 1 },  /* dnsupdater.de */
  { 16122,     0,     0, 1 },  /* dray-dns.de */
  { 16131,     0,     0, 1 },  /* draydns.de */
  { 16139,     0,     0, 1 },  /* dyn-ip24.de */
  { 16148,     0,     0, 1 },  /* dyn-vpn.de */
  { 16156,     0,     0, 1 },  /* dynamisches-dns.de */
  { 16172,     0,     0, 1 },  /* dyndns1.de */
  { 16180,     0,     0, 1 },  /* dynvpn.de */
  { 13568,     0,     0, 1 },  /* firewall-gateway.de */
  { 16187,     0,     0, 1 },  /* fuettertdasnetz.de */
  { 16203,     0,     0, 1 },  /* git-repos.de */
  { 14829,     0,     0, 1 },  /* goip.de */
  { 16213,  4345,     1, 1 },  /* home-webserver.de */
  { 16228,     0,     0, 1 },  /* internet-dns.de */
  { 16241,     0,     0, 1 },  /* isteingeek.de */
  { 16252,     0,     0, 1 },  /* istmein.de */
  { 16260,     0,     0, 1 },  /* keymachine.de */
  { 16271,     0,     0, 1 },  /* l-o-g-i-n.de */
  { 16281,     0,     0, 1 },  /* lcube-server.de */
  { 16294,     0,     0, 1 },  /* lebtimnetz.de */
  { 16305,     0,     0, 1 },  /* leitungsen.de */
  { 11571,     0,     0, 1 },  /* lima-city.de */
  { 14827,     0,     0, 1 },  /* logoip.de */
  { 16316,     0,     0, 1 },  /* mein-iserv.de */
  { 16327,     0,     0, 1 },  /* mein-vigor.de */
  { 16338,     0,     0, 1 },  /* my-gateway.de */
  { 16349,     0,     0, 1 },  /* my-router.de */
  { 16359,     0,     0, 1 },  /* my-vigor.de */
  { 16368,     0,     0, 1 },  /* my-wan.de */
  { 16375,     0,     0, 1 },  /* myhome-server.de */
  { 16389,     0,     0, 1 },  /* spdns.de */
  { 16395,  4348,     1, 0 },  /* speedpartner.de */
  { 12680,     0,     0, 1 },  /* square7.de */
  { 16408,     0,     0, 1 },  /* svn-repos.de */
  { 16418,     0,     0, 1 },  /* syno-ds.de */
  { 16426,     0,     0, 1 },  /* synology-diskstation.de */
  { 16447,     0,     0, 1 },  /* synology-ds.de */
  { 16459,     0,     0, 1 },  /* taifun-dns.de */
  { 16470,     0,     0, 1 },  /* test-iserv.de */
  { 16481,     0,     0, 1 },  /* traeumtgerade.de */
  { 16495,  4048,     1, 0 },  /* uberspace.de */
  { 16505,     0,     0, 1 },  /* virtual-user.de */
  { 16518,     0,     0, 1 },  /* virtualuser.de */
  { 16575,     0,     0, 1 },  /* aip.ee */
  {  1910,  4032,     1, 1 },  /* com.ee */
  {  2622,     0,     0, 1 },  /* edu.ee */
  {  4142,     0,     0, 1 },  /* fie.ee */
  {  3665,     0,     0, 1 },  /* gov.ee */
  { 16579,     0,     0, 1 },  /* lib.ee */
  {  1855,     0,     0, 1 },  /* med.ee */
  {  6026,     0,     0, 1 },  /* org.ee */
  { 16583,     0,     0, 1 },  /* pri.ee */
  { 16587,     0,     0, 1 },  /* riik.ee */
  {  1910,  4032,     1, 1 },  /* com.eg */
  {  2622,     0,     0, 1 },  /* edu.eg */
  { 16592,     0,     0, 1 },  /* eun.eg */
  {  3665,     0,     0, 1 },  /* gov.eg */
  {  4157,     0,     0, 1 },  /* mil.eg */
  {  5672,     0,     0, 1 },  /* name.eg */
  {  5710,     0,     0, 1 },  /* net.eg */
  {  6026,     0,     0, 1 },  /* org.eg */
  { 16606,     0,     0, 1 },  /* sci.eg */
  {  1910,  4032,     1, 1 },  /* com.es */
  {  2622,     0,     0, 1 },  /* edu.es */
  { 11461,     0,     0, 1 },  /* gob.es */
  {  5943,     0,     0, 1 },  /* nom.es */
  {  6026,     0,     0, 1 },  /* org.es */
  { 12870,  4048,     1, 0 },  /* compute.estate */
  { 11692,     0,     0, 1 },  /* barsy.eu */
  { 11510,     0,     0, 1 },  /* cloudns.eu */
  { 16435,     0,     0, 1 },  /* diskstation.eu */
  {  1576,     0,     0, 1 },  /* mycd.eu */
  { 16389,     0,     0, 1 },  /* spdns.eu */
  { 11650,  4048,     1, 0 },  /* transurl.eu */
  { 16610,     0,     0, 1 },  /* wellbeingzone.eu */
  {  6123,  4394,     1, 0 },  /* party.eus */
  {    62,     0,     0, 1 },  /* ac.id */
  {   986,     0,     0, 1 },  /* biz.id */
  {   113,  4032,     1, 1 },  /* co.id */
  { 17102,     0,     0, 1 },  /* desa.id */
  {   257,     0,     0, 1 },  /* go.id */
  {  4157,     0,     0, 1 },  /* mil.id */
  {    70,     0,     0, 1 },  /* my.id */
  {  5710,     0,     0, 1 },  /* net.id */
  {   137,     0,     0, 1 },  /* or.id */
  {  1140,     0,     0, 1 },  /* sch.id */
  { 12075,     0,     0, 1 },  /* web.id */
  { 10774,     0,     0, 1 },  /* zone.id */
  {    62,     0,     0, 1 },  /* ac.il */
  {   113,  4032,     1, 1 },  /* co.il */
  {  3665,     0,     0, 1 },  /* gov.il */
  { 17107,     0,     0, 1 },  /* idf.il */
  { 16571,     0,     0, 1 },  /* k12.il */
  { 16060,     0,     0, 1 },  /* muni.il */
  {  5710,     0,     0, 1 },  /* net.il */
  {  6026,     0,     0, 1 },  /* org.il */
  {    62,     0,     0, 1 },  /* ac.im */
  {   113,  4598,     2, 1 },  /* co.im */
  {  1910,     0,     0, 1 },  /* com.im */
  {  5710,     0,     0, 1 },  /* net.im */
  {  5943,     0,     0, 1 },  /* nom.im */
  {  6026,     0,     0, 1 },  /* org.im */
  {   166,     0,     0, 1 },  /* ro.im */
  {    24,     0,     0, 1 },  /* tt.im */
  {  2545,     0,     0, 1 },  /* tv.im */
  { 11685,     0,     0, 1 },  /* 2038.io */
  { 17236,     0,     0, 1 },  /* azurecontainer.io */
  { 17251,     0,     0, 1 },  /* backplaneapp.io */
  { 11692,     0,     0, 1 },  /* barsy.io */
  { 17264,     0,     0, 1 },  /* boxfuse.io */
  { 17272,     0,     0, 1 },  /* browsersafetymark.io */
  { 16001,     0,     0, 1 },  /* cleverapps.io */
  {  1910,     0,     0, 1 },  /* com.io */
  { 16530,     0,     0, 1 },  /* dedyn.io */
  { 17290,     0,     0, 1 },  /* definima.io */
  { 17299,     0,     0, 1 },  /* drud.io */
  { 17304,  4348,     1, 1 },  /* enonic.io */
  { 17311,     0,     0, 1 },  /* github.io */
  { 17318,     0,     0, 1 },  /* gitlab.io */
  { 17325,     0,     0, 1 },  /* hasura-app.io */
  { 17336,     0,     0, 1 },  /* hzc.io */
  { 17340,  4313,     1, 0 },  /* lair.io */
  { 17345,     0,     0, 1 },  /* ngrok.io */
  { 17351,     0,     0, 1 },  /* nid.io */
  { 17355,  4635,     1, 0 },  /* nodeart.io */
  { 12891,     0,     0, 1 },  /* nodum.io */
  { 17363,     0,     0, 1 },  /* pantheonsite.io */
  { 17376,     0,     0, 1 },  /* protonet.io */
  { 17385,     0,     0, 1 },  /* resindevice.io */
  { 17397,  4636,     1, 0 },  /* resinstaging.io */
  { 17410,  4048,     1, 0 },  /* s5y.io */
  { 17414,     0,     0, 1 },  /* sandcats.io */
  { 17423,     0,     0, 1 },  /* shiftedit.io */
  { 17433,     0,     0, 1 },  /* spacekit.io */
  { 17442,  4048,     1, 0 },  /* stolos.io */
  { 17449,  2373,     4, 0 },  /* thingdust.io */
  { 17459,     0,     0, 1 },  /* utwente.io */
  { 17467,     0,     0, 1 },  /* vaporcloud.io */
  { 17478,     0,     0, 1 },  /* wedeploy.io */
  {  2379,  4637,     1, 0 },  /* dev.thingdust.io */
  { 12403,  4637,     1, 0 },  /* disrec.thingdust.io */
  {  6380,  4637,     1, 0 },  /* prod.thingdust.io */
  { 17501,  4637,     1, 0 },  /* testing.thingdust.io */
  {    62,     0,     0, 1 },  /* ac.jp */
  {   141,     0,     0, 1 },  /* ad.jp */
  { 20808,  5076,    52, 1 },  /* aichi.jp */
  { 20817,  5128,    28, 1 },  /* akita.jp */
  { 20823,  5156,    22, 1 },  /* aomori.jp */
  { 10791,     0,     0, 1 },  /* blogspot.jp */
  { 20835,  5178,    58, 1 },  /* chiba.jp */
  {   113,     0,     0, 1 },  /* co.jp */
  {  1856,     0,     0, 1 },  /* ed.jp */
  { 20841,  5236,    22, 1 },  /* ehime.jp */
  { 20847,  5258,    15, 1 },  /* fukui.jp */
  { 20853,  5273,    63, 1 },  /* fukuoka.jp */
  { 20865,  5336,    51, 1 },  /* fukushima.jp */
  { 20875,  5387,    38, 1 },  /* gifu.jp */
  {   257,     0,     0, 1 },  /* go.jp */
  {  3676,     0,     0, 1 },  /* gr.jp */
  { 20880,  5425,    36, 1 },  /* gunma.jp */
  { 20890,  5461,    25, 1 },  /* hiroshima.jp */
  { 20900,  5486,   142, 1 },  /* hokkaido.jp */
  { 20909,  5628,    46, 1 },  /* hyogo.jp */
  { 20915,  5674,    51, 1 },  /* ibaraki.jp */
  { 20924,  5725,    19, 1 },  /* ishikawa.jp */
  { 20933,  5744,    34, 1 },  /* iwate.jp */
  { 20941,  5778,    15, 1 },  /* kagawa.jp */
  { 20948,  5793,    20, 1 },  /* kagoshima.jp */
  { 20958,  5813,    30, 1 },  /* kanagawa.jp */
  { 20967,  5843,     2, 0 },  /* kawasaki.jp */
  { 20976,  5843,     2, 0 },  /* kitakyushu.jp */
  {   858,  5843,     2, 0 },  /* kobe.jp */
  { 20987,  5845,    31, 1 },  /* kochi.jp */
  {  5510,  5876,    23, 1 },  /* kumamoto.jp */
  {  4673,  5899,    31, 1 },  /* kyoto.jp */
  { 12508,     0,     0, 1 },  /* lg.jp */
  { 20995,  5930,    30, 1 },  /* mie.jp */
  { 20999,  5960,    32, 1 },  /* miyagi.jp */
  { 21006,  5992,    27, 1 },  /* miyazaki.jp */
  { 21022,  6019,    75, 1 },  /* nagano.jp */
  { 21029,  6094,    22, 1 },  /* nagasaki.jp */
  {  5661,  5843,     2, 0 },  /* nagoya.jp */
  { 19285,  6116,    38, 1 },  /* nara.jp */
  {  1198,     0,     0, 1 },  /* ne.jp */
  { 21038,  6154,    34, 1 },  /* niigata.jp */
  { 21047,  6188,    19, 1 },  /* oita.jp */
  { 21052,  6207,    26, 1 },  /* okayama.jp */
  {  5911,  6233,    42, 1 },  /* okinawa.jp */
  {   137,     0,     0, 1 },  /* or.jp */
  {  6054,  6275,    50, 1 },  /* osaka.jp */
  {  3332,  6325,    26, 1 },  /* saga.jp */
  { 21060,  6351,    69, 1 },  /* saitama.jp */
  { 21068,  5843,     2, 0 },  /* sapporo.jp */
  { 21083,  5843,     2, 0 },  /* sendai.jp */
  { 21090,  6420,    23, 1 },  /* shiga.jp */
  { 21096,  6443,    23, 1 },  /* shimane.jp */
  { 21104,  6466,    36, 1 },  /* shizuoka.jp */
  { 21113,  6502,    31, 1 },  /* tochigi.jp */
  { 21121,  6533,    17, 1 },  /* tokushima.jp */
  {  7904,  6550,    57, 1 },  /* tokyo.jp */
  { 21131,  6607,    13, 1 },  /* tottori.jp */
  { 21141,  6620,    24, 1 },  /* toyama.jp */
  { 21148,  6644,    29, 1 },  /* wakayama.jp */
  { 21157,     0,     0, 1 },  /* xn--0trq7p7nn.jp */
  { 21171,     0,     0, 1 },  /* xn--1ctwo.jp */
  { 21181,     0,     0, 1 },  /* xn--1lqs03n.jp */
  { 21193,     0,     0, 1 },  /* xn--1lqs71d.jp */
  { 21205,     0,     0, 1 },  /* xn--2m4a15e.jp */
  { 21217,     0,     0, 1 },  /* xn--32vp30h.jp */
  { 21229,     0,     0, 1 },  /* xn--4it168d.jp */
  { 21241,     0,     0, 1 },  /* xn--4it797k.jp */
  { 21253,     0,     0, 1 },  /* xn--4pvxs.jp */
  { 21263,     0,     0, 1 },  /* xn--5js045d.jp */
  { 21275,     0,     0, 1 },  /* xn--5rtp49c.jp */
  { 21287,     0,     0, 1 },  /* xn--5rtq34k.jp */
  { 21299,     0,     0, 1 },  /* xn--6btw5a.jp */
  { 21310,     0,     0, 1 },  /* xn--6orx2r.jp */
  { 21321,     0,     0, 1 },  /* xn--7t0a264c.jp */
  { 21334,     0,     0, 1 },  /* xn--8ltr62k.jp */
  { 12926,     0,     0, 1 },  /* xn--8pvr4u.jp */
  { 21346,     0,     0, 1 },  /* xn--c3s14m.jp */
  { 21357,     0,     0, 1 },  /* xn--d5qv7z876c.jp */
  { 21372,     0,     0, 1 },  /* xn--djrs72d6uy.jp */
  { 21387,     0,     0, 1 },  /* xn--djty4k.jp */
  { 21398,     0,     0, 1 },  /* xn--efvn9s.jp */
  { 21409,     0,     0, 1 },  /* xn--ehqz56n.jp */
  { 21421,     0,     0, 1 },  /* xn--elqq16h.jp */
  { 21433,     0,     0, 1 },  /* xn--f6qx53a.jp */
  { 21445,     0,     0, 1 },  /* xn--k7yn95e.jp */
  { 21457,     0,     0, 1 },  /* xn--kbrq7o.jp */
  { 21468,     0,     0, 1 },  /* xn--klt787d.jp */
  { 21480,     0,     0, 1 },  /* xn--kltp7d.jp */
  { 21491,     0,     0, 1 },  /* xn--kltx9a.jp */
  { 21502,     0,     0, 1 },  /* xn--klty5x.jp */
  { 21513,     0,     0, 1 },  /* xn--mkru45i.jp */
  { 21525,     0,     0, 1 },  /* xn--nit225k.jp */
  { 21537,     0,     0, 1 },  /* xn--ntso0iqx3a.jp */
  { 21552,     0,     0, 1 },  /* xn--ntsq17g.jp */
  { 21564,     0,     0, 1 },  /* xn--pssu33l.jp */
  { 21576,     0,     0, 1 },  /* xn--qqqt11m.jp */
  { 21588,     0,     0, 1 },  /* xn--rht27z.jp */
  { 21599,     0,     0, 1 },  /* xn--rht3d.jp */
  { 21609,     0,     0, 1 },  /* xn--rht61e.jp */
  { 21620,     0,     0, 1 },  /* xn--rny31h.jp */
  { 21631,     0,     0, 1 },  /* xn--tor131o.jp */
  { 21643,     0,     0, 1 },  /* xn--uist22h.jp */
  { 21655,     0,     0, 1 },  /* xn--uisz3g.jp */
  { 21666,     0,     0, 1 },  /* xn--uuwu58a.jp */
  { 21678,     0,     0, 1 },  /* xn--vgu402c.jp */
  { 21690,     0,     0, 1 },  /* xn--zbx025d.jp */
  { 21702,  6673,    34, 1 },  /* yamagata.jp */
  { 21711,  6707,    16, 1 },  /* yamaguchi.jp */
  { 21721,  6723,    28, 1 },  /* yamanashi.jp */
  { 10720,  5843,     2, 0 },  /* yokohama.jp */
  {    62,     0,     0, 1 },  /* ac.ke */
  {   113,  4032,     1, 1 },  /* co.ke */
  {   257,     0,     0, 1 },  /* go.ke */
  {  3149,     0,     0, 1 },  /* info.ke */
  {  1690,     0,     0, 1 },  /* me.ke */
  {  5415,     0,     0, 1 },  /* mobi.ke */
  {  1198,     0,     0, 1 },  /* ne.ke */
  {  5943,     0,     0, 1 },  /* nom.ke */
  {   137,     0,     0, 1 },  /* or.ke */
  {  2155,     0,     0, 1 },  /* sc.ke */
  { 31967,  6835,     2, 1 },  /* static.land */
  {    62,     0,     0, 1 },  /* ac.me */
  { 11692,     0,     0, 1 },  /* barsy.me */
  { 32012,     0,     0, 1 },  /* brasilia.me */
  { 32021,     0,     0, 1 },  /* c66.me */
  {   113,     0,     0, 1 },  /* co.me */
  { 32025,  6894,     1, 1 },  /* daplie.me */
  { 13253,     0,     0, 1 },  /* ddns.me */
  { 16435,     0,     0, 1 },  /* diskstation.me */
  { 32039,     0,     0, 1 },  /* dnsfor.me */
  { 11725,     0,     0, 1 },  /* dscloud.me */
  {  2622,     0,     0, 1 },  /* edu.me */
  { 32046,     0,     0, 1 },  /* filegear.me */
  {  3665,     0,     0, 1 },  /* gov.me */
  { 32055,     0,     0, 1 },  /* hopto.me */
  { 32061,     0,     0, 1 },  /* i234.me */
  { 20078,     0,     0, 1 },  /* its.me */
  { 32066,     0,     0, 1 },  /* loginto.me */
  { 32074,     0,     0, 1 },  /* myds.me */
  {  5710,     0,     0, 1 },  /* net.me */
  {  4024,     0,     0, 1 },  /* nohost.me */
  { 32079,     0,     0, 1 },  /* noip.me */
  { 12575,     0,     0, 1 },  /* nym.me */
  {  6026,     0,     0, 1 },  /* org.me */
  { 11594,     0,     0, 1 },  /* priv.me */
  { 14892,     0,     0, 1 },  /* ravendb.me */
  { 32084,     0,     0, 1 },  /* soundcast.me */
  { 32094,     0,     0, 1 },  /* synology.me */
  { 32103,     0,     0, 1 },  /* tcp4.me */
  { 11808,     0,     0, 1 },  /* webhop.me */
  { 17478,     0,     0, 1 },  /* wedeploy.me */
  { 32108,     0,     0, 1 },  /* yombo.me */
  {  1910,  4032,     1, 1 },  /* com.mt */
  {  2622,     0,     0, 1 },  /* edu.mt */
  {  5710,     0,     0, 1 },  /* net.mt */
  {  6026,     0,     0, 1 },  /* org.mt */
  {  1221,  7550,     1, 0 },  /* her.name */
  { 15078,  7550,     1, 0 },  /* his.name */
  {  2222,     0,     0, 1 },  /* alwaysdata.net */
  {  1358,     0,     0, 1 },  /* at-band-camp.net */
  {  5420,     0,     0, 1 },  /* azure-mobile.net */
  { 31974,     0,     0, 1 },  /* azurewebsites.net */
  { 11692,     0,     0, 1 },  /* barsy.net */
  { 36158,     0,     0, 1 },  /* blackbaudcdn.net */
  { 13007,     0,     0, 1 },  /* blogdns.net */
  { 36171,     0,     0, 1 },  /* boomla.net */
  { 36178,     0,     0, 1 },  /* bounceme.net */
  { 13044,     0,     0, 1 },  /* bplaced.net */
  { 36187,     0,     0, 1 },  /* broke-it.net */
  { 36196,     0,     0, 1 },  /* buyshouses.net */
  { 36207,     0,     0, 1 },  /* casacam.net */
  { 36215,  7553,     1, 0 },  /* cdn77.net */
  { 36221,     0,     0, 1 },  /* cdn77-ssl.net */
  { 36231,     0,     0, 1 },  /* channelsdvr.net */
  { 16980,     0,     0, 1 },  /* cloudaccess.net */
  { 36243,     0,     0, 1 },  /* cloudapp.net */
  { 36252,     0,     0, 1 },  /* cloudeity.net */
  { 36262,     0,     0, 1 },  /* cloudfront.net */
  { 36273,     0,     0, 1 },  /* cloudfunctions.net */
  { 36288,     0,     0, 1 },  /* cloudycluster.net */
  { 36302,  4048,     1, 0 },  /* cryptonomic.net */
  { 13123,     0,     0, 1 },  /* dattolocal.net */
  { 13253,     0,     0, 1 },  /* ddns.net */
  { 36314,     0,     0, 1 },  /* debian.net */
  { 17290,     0,     0, 1 },  /* definima.net */
  { 13191,     0,     0, 1 },  /* dnsalias.net */
  { 13200,     0,     0, 1 },  /* dnsdojo.net */
  { 36321,     0,     0, 1 },  /* dnsup.net */
  { 36327,     0,     0, 1 },  /* does-it.net */
  { 13231,     0,     0, 1 },  /* dontexist.net */
  { 13271,     0,     0, 1 },  /* dsmynas.net */
  { 13290,     0,     0, 1 },  /* dynalias.net */
  { 36335,     0,     0, 1 },  /* dynathome.net */
  { 36345,     0,     0, 1 },  /* dynu.net */
  { 36350,     0,     0, 1 },  /* dynv6.net */
  {  6030,     0,     0, 1 },  /* eating-organic.net */
  { 36356,     0,     0, 1 },  /* endofinternet.net */
  { 13526,     0,     0, 1 },  /* familyds.net */
  { 36370,  2642,     4, 0 },  /* fastly.net */
  { 36377,  7559,     1, 1 },  /* fastlylb.net */
  { 36386,     0,     0, 1 },  /* feste-ip.net */
  { 13568,     0,     0, 1 },  /* firewall-gateway.net */
  { 36395,     0,     0, 1 },  /* flynnhosting.net */
  { 36408,     0,     0, 1 },  /* from-az.net */
  { 36416,     0,     0, 1 },  /* from-co.net */
  { 36424,     0,     0, 1 },  /* from-la.net */
  { 36432,     0,     0, 1 },  /* from-ny.net */
  {  3420,     0,     0, 1 },  /* gb.net */
  { 36440,     0,     0, 1 },  /* gets-it.net */
  { 36448,     0,     0, 1 },  /* ham-radio-op.net */
  {  1335,     0,     0, 1 },  /* hicam.net */
  { 36461,     0,     0, 1 },  /* homeftp.net */
  { 36469,     0,     0, 1 },  /* homeip.net */
  { 14092,     0,     0, 1 },  /* homelinux.net */
  { 14133,     0,     0, 1 },  /* homeunix.net */
  {  4106,     0,     0, 1 },  /* hu.net */
  {   898,     0,     0, 1 },  /* in.net */
  {   718,     0,     0, 1 },  /* in-the-band.net */
  { 36476,     0,     0, 1 },  /* ipifony.net */
  { 14224,     0,     0, 1 },  /* is-a-chef.net */
  { 14316,     0,     0, 1 },  /* is-a-geek.net */
  { 14739,     0,     0, 1 },  /* isa-geek.net */
  {  4460,     0,     0, 1 },  /* jp.net */
  { 36484,     0,     0, 1 },  /* kicks-ass.net */
  { 36494,     0,     0, 1 },  /* knx-server.net */
  { 36505,     0,     0, 1 },  /* memset.net */
  { 36512,     0,     0, 1 },  /* moonscale.net */
  { 14865,     0,     0, 1 },  /* mydatto.net */
  { 36522,     0,     0, 1 },  /* mydissent.net */
  { 36532,     0,     0, 1 },  /* myeffect.net */
  {  8079,     0,     0, 1 },  /* myfritz.net */
  { 36541,     0,     0, 1 },  /* mymediapc.net */
  {  7601,     0,     0, 1 },  /* mypsx.net */
  {  1341,     0,     0, 1 },  /* mysecuritycamera.net */
  { 36551,     0,     0, 1 },  /* nhlfan.net */
  { 11795,     0,     0, 1 },  /* no-ip.net */
  { 36558,     0,     0, 1 },  /* now-dns.net */
  { 36566,     0,     0, 1 },  /* office-on-the.net */
  { 36580,     0,     0, 1 },  /* ownip.net */
  { 36586,     0,     0, 1 },  /* pgafan.net */
  { 10771,     0,     0, 1 },  /* podzone.net */
  { 36593,     0,     0, 1 },  /* privatizehealthinsurance.net */
  { 15129,     0,     0, 1 },  /* rackmaze.net */
  { 36618,     0,     0, 1 },  /* redirectme.net */
  {  2187,     0,     0, 1 },  /* ru.net */
  { 36629,     0,     0, 1 },  /* schokokeks.net */
  { 36640,     0,     0, 1 },  /* scrapper-site.net */
  {  1492,     0,     0, 1 },  /* se.net */
  { 11801,     0,     0, 1 },  /* selfip.net */
  { 36654,     0,     0, 1 },  /* sells-it.net */
  { 15215,     0,     0, 1 },  /* servebbs.net */
  {  1030,     0,     0, 1 },  /* serveblog.net */
  { 15243,     0,     0, 1 },  /* serveftp.net */
  { 36663,     0,     0, 1 },  /* serveminecraft.net */
  { 12680,     0,     0, 1 },  /* square7.net */
  { 36678,     0,     0, 1 },  /* static-access.net */
  { 15110,     0,     0, 1 },  /* sytes.net */
  { 36692,     0,     0, 1 },  /* t3l3p0rt.net */
  {  3859,     0,     0, 1 },  /* thruhere.net */
  { 12642,     0,     0, 1 },  /* twmail.net */
  {  8115,     0,     0, 1 },  /* uk.net */
  { 36701,     0,     0, 1 },  /* vpndns.net */
  { 11808,     0,     0, 1 },  /* webhop.net */
  {  6272,     0,     0, 1 },  /* za.net */
  { 36708,     0,     0, 1 },  /* freetls.fastly.net */
  {  5186,     0,     0, 1 },  /* map.fastly.net */
  {  6380,  7554,     2, 0 },  /* prod.fastly.net */
  { 14077,  7556,     3, 0 },  /* ssl.fastly.net */
  { 36716,  4048,     1, 0 },  /* alces.network */
  {  1910,  4032,     1, 1 },  /* com.ng */
  {  2622,     0,     0, 1 },  /* edu.ng */
  {  3665,     0,     0, 1 },  /* gov.ng */
  {    58,     0,     0, 1 },  /* i.ng */
  {  4157,     0,     0, 1 },  /* mil.ng */
  {  5415,     0,     0, 1 },  /* mobi.ng */
  {  5672,     0,     0, 1 },  /* name.ng */
  {  5710,     0,     0, 1 },  /* net.ng */
  {  6026,     0,     0, 1 },  /* org.ng */
  {  1140,     0,     0, 1 },  /* sch.ng */
  { 10791,     0,     0, 1 },  /* blogspot.nl */
  {  1284,     0,     0, 1 },  /* bv.nl */
  { 36722,     0,     0, 1 },  /* cistron.nl */
  {   113,     0,     0, 1 },  /* co.nl */
  { 36730,     0,     0, 1 },  /* demon.nl */
  { 36736,     0,     0, 1 },  /* hosting-cluster.nl */
  { 11650,  4048,     1, 0 },  /* transurl.nl */
  { 36752,     0,     0, 1 },  /* virtueeldomein.nl */
  {     1,  7584,     1, 1 },  /* aa.no */
  { 36767,     0,     0, 1 },  /* aarborte.no */
  { 36776,     0,     0, 1 },  /* aejrie.no */
  { 36784,     0,     0, 1 },  /* afjord.no */
  { 36791,     0,     0, 1 },  /* agdenes.no */
  { 12776,  7584,     1, 1 },  /* ah.no */
  { 36799,  7585,     1, 0 },  /* akershus.no */
  { 36808,     0,     0, 1 },  /* aknoluokta.no */
  { 36819,     0,     0, 1 },  /* akrehamn.no */
  {   290,     0,     0, 1 },  /* al.no */
  { 36828,     0,     0, 1 },  /* alaheadju.no */
  { 36838,     0,     0, 1 },  /* alesund.no */
  { 36846,     0,     0, 1 },  /* algard.no */
  { 36853,     0,     0, 1 },  /* alstahaug.no */
  { 36864,     0,     0, 1 },  /* alta.no */
  { 36869,     0,     0, 1 },  /* alvdal.no */
  { 36876,     0,     0, 1 },  /* amli.no */
  { 36881,     0,     0, 1 },  /* amot.no */
  { 36886,     0,     0, 1 },  /* andasuolo.no */
  { 36896,     0,     0, 1 },  /* andebu.no */
  { 36904,     0,     0, 1 },  /* andoy.no */
  { 36911,     0,     0, 1 },  /* ardal.no */
  { 36917,     0,     0, 1 },  /* aremark.no */
  { 36925,     0,     0, 1 },  /* arendal.no */
  {  5637,     0,     0, 1 },  /* arna.no */
  { 36933,     0,     0, 1 },  /* aseral.no */
  { 36940,     0,     0, 1 },  /* asker.no */
  {  4560,     0,     0, 1 },  /* askim.no */
  { 36946,     0,     0, 1 },  /* askoy.no */
  { 36952,     0,     0, 1 },  /* askvoll.no */
  { 36960,     0,     0, 1 },  /* asnes.no */
  { 36966,     0,     0, 1 },  /* audnedaln.no */
  { 36976,     0,     0, 1 },  /* aukra.no */
  { 36982,     0,     0, 1 },  /* aure.no */
  { 36987,     0,     0, 1 },  /* aurland.no */
  { 36995,     0,     0, 1 },  /* aurskog-holand.no */
  { 37010,     0,     0, 1 },  /* austevoll.no */
  { 37020,     0,     0, 1 },  /* austrheim.no */
  { 37030,     0,     0, 1 },  /* averoy.no */
  { 37037,     0,     0, 1 },  /* badaddja.no */
  { 37046,     0,     0, 1 },  /* bahcavuotna.no */
  { 37058,     0,     0, 1 },  /* bahccavuotna.no */
  { 37071,     0,     0, 1 },  /* baidar.no */
  { 37078,     0,     0, 1 },  /* bajddar.no */
  {  4780,     0,     0, 1 },  /* balat.no */
  { 37086,     0,     0, 1 },  /* balestrand.no */
  { 37097,     0,     0, 1 },  /* ballangen.no */
  { 37107,     0,     0, 1 },  /* balsfjord.no */
  { 37117,     0,     0, 1 },  /* bamble.no */
  { 37124,     0,     0, 1 },  /* bardu.no */
  { 37130,     0,     0, 1 },  /* barum.no */
  { 37136,     0,     0, 1 },  /* batsfjord.no */
  { 37146,     0,     0, 1 },  /* bearalvahki.no */
  { 37158,     0,     0, 1 },  /* beardu.no */
  { 37165,     0,     0, 1 },  /* beiarn.no */
  {  1045,     0,     0, 1 },  /* berg.no */
  { 17111,     0,     0, 1 },  /* bergen.no */
  { 37181,     0,     0, 1 },  /* berlevag.no */
  { 37190,     0,     0, 1 },  /* bievat.no */
  { 37197,     0,     0, 1 },  /* bindal.no */
  { 37204,     0,     0, 1 },  /* birkenes.no */
  { 37213,     0,     0, 1 },  /* bjarkoy.no */
  { 37221,     0,     0, 1 },  /* bjerkreim.no */
  {  3586,     0,     0, 1 },  /* bjugn.no */
  { 10791,     0,     0, 1 },  /* blogspot.no */
  { 37231,     0,     0, 1 },  /* bodo.no */
  {  4596,     0,     0, 1 },  /* bokn.no */
  { 37236,     0,     0, 1 },  /* bomlo.no */
  { 37242,     0,     0, 1 },  /* bremanger.no */
  { 37252,     0,     0, 1 },  /* bronnoy.no */
  { 37260,     0,     0, 1 },  /* bronnoysund.no */
  { 37272,     0,     0, 1 },  /* brumunddal.no */
  { 37283,     0,     0, 1 },  /* bryne.no */
  { 21937,  7584,     1, 1 },  /* bu.no */
  { 37289,     0,     0, 1 },  /* budejju.no */
  { 37297,  7585,     1, 0 },  /* buskerud.no */
  { 37306,     0,     0, 1 },  /* bygland.no */
  { 37314,     0,     0, 1 },  /* bykle.no */
  { 37320,     0,     0, 1 },  /* cahcesuolo.no */
  {   113,     0,     0, 1 },  /* co.no */
  { 37331,     0,     0, 1 },  /* davvenjarga.no */
  { 27931,     0,     0, 1 },  /* davvesiida.no */
  { 37343,     0,     0, 1 },  /* deatnu.no */
  { 37350,     0,     0, 1 },  /* dep.no */
  { 37354,     0,     0, 1 },  /* dielddanuorri.no */
  { 37368,     0,     0, 1 },  /* divtasvuodna.no */
  { 37381,     0,     0, 1 },  /* divttasvuotna.no */
  { 29221,     0,     0, 1 },  /* donna.no */
  { 37395,     0,     0, 1 },  /* dovre.no */
  {  5329,     0,     0, 1 },  /* drammen.no */
  { 37401,     0,     0, 1 },  /* drangedal.no */
  { 37411,     0,     0, 1 },  /* drobak.no */
  { 37418,     0,     0, 1 },  /* dyroy.no */
  { 37424,     0,     0, 1 },  /* egersund.no */
  { 37436,     0,     0, 1 },  /* eid.no */
  { 37440,     0,     0, 1 },  /* eidfjord.no */
  { 37172,     0,     0, 1 },  /* eidsberg.no */
  { 37449,     0,     0, 1 },  /* eidskog.no */
  { 37457,     0,     0, 1 },  /* eidsvoll.no */
  { 37466,     0,     0, 1 },  /* eigersund.no */
  { 37476,     0,     0, 1 },  /* elverum.no */
  { 37484,     0,     0, 1 },  /* enebakk.no */
  { 37492,     0,     0, 1 },  /* engerdal.no */
  {  5703,     0,     0, 1 },  /* etne.no */
  { 37501,     0,     0, 1 },  /* etnedal.no */
  { 37509,     0,     0, 1 },  /* evenassi.no */
  { 37518,     0,     0, 1 },  /* evenes.no */
  { 37525,     0,     0, 1 },  /* evje-og-hornnes.no */
  { 37541,     0,     0, 1 },  /* farsund.no */
  { 37549,     0,     0, 1 },  /* fauske.no */
  {  4387,     0,     0, 1 },  /* fedje.no */
  {  2783,     0,     0, 1 },  /* fet.no */
  { 37556,     0,     0, 1 },  /* fetsund.no */
  { 31936,     0,     0, 1 },  /* fhs.no */
  { 37564,     0,     0, 1 },  /* finnoy.no */
  { 37571,     0,     0, 1 },  /* fitjar.no */
  { 37578,     0,     0, 1 },  /* fjaler.no */
  { 37585,     0,     0, 1 },  /* fjell.no */
  {  4682,     0,     0, 1 },  /* fla.no */
  { 37591,     0,     0, 1 },  /* flakstad.no */
  { 37600,     0,     0, 1 },  /* flatanger.no */
  { 37610,     0,     0, 1 },  /* flekkefjord.no */
  { 37622,     0,     0, 1 },  /* flesberg.no */
  { 37631,     0,     0, 1 },  /* flora.no */
  { 37637,     0,     0, 1 },  /* floro.no */
  {  3144,  7584,     1, 1 },  /* fm.no */
  { 37643,     0,     0, 1 },  /* folkebibl.no */
  { 37653,     0,     0, 1 },  /* folldal.no */
  { 37661,     0,     0, 1 },  /* forde.no */
  { 37667,     0,     0, 1 },  /* forsand.no */
  { 37675,     0,     0, 1 },  /* fosnes.no */
  { 37682,     0,     0, 1 },  /* frana.no */
  { 37688,     0,     0, 1 },  /* fredrikstad.no */
  { 37700,     0,     0, 1 },  /* frei.no */
  { 37705,     0,     0, 1 },  /* frogn.no */
  { 37711,     0,     0, 1 },  /* froland.no */
  { 37719,     0,     0, 1 },  /* frosta.no */
  { 37726,     0,     0, 1 },  /* froya.no */
  { 37732,     0,     0, 1 },  /* fuoisku.no */
  { 37740,     0,     0, 1 },  /* fuossko.no */
  { 22765,     0,     0, 1 },  /* fusa.no */
  { 37748,     0,     0, 1 },  /* fylkesbibl.no */
  { 37759,     0,     0, 1 },  /* fyresdal.no */
  { 37768,     0,     0, 1 },  /* gaivuotna.no */
  { 37778,     0,     0, 1 },  /* galsa.no */
  { 37784,     0,     0, 1 },  /* gamvik.no */
  { 37791,     0,     0, 1 },  /* gangaviika.no */
  { 37802,     0,     0, 1 },  /* gaular.no */
  { 37809,     0,     0, 1 },  /* gausdal.no */
  { 37817,     0,     0, 1 },  /* giehtavuoatna.no */
  { 37831,     0,     0, 1 },  /* gildeskal.no */
  { 37841,     0,     0, 1 },  /* giske.no */
  { 37847,     0,     0, 1 },  /* gjemnes.no */
  { 37855,     0,     0, 1 },  /* gjerdrum.no */
  { 37864,     0,     0, 1 },  /* gjerstad.no */
  { 37873,     0,     0, 1 },  /* gjesdal.no */
  { 37881,     0,     0, 1 },  /* gjovik.no */
  { 37888,     0,     0, 1 },  /* gloppen.no */
  { 37896,     0,     0, 1 },  /* gol.no */
  { 37900,     0,     0, 1 },  /* gran.no */
  { 37905,     0,     0, 1 },  /* grane.no */
  {  8265,     0,     0, 1 },  /* granvin.no */
  { 37911,     0,     0, 1 },  /* gratangen.no */
  { 37921,     0,     0, 1 },  /* grimstad.no */
  { 37930,     0,     0, 1 },  /* grong.no */
  { 37936,     0,     0, 1 },  /* grue.no */
  { 37941,     0,     0, 1 },  /* gulen.no */
  { 37947,     0,     0, 1 },  /* guovdageaidnu.no */
  {  2514,     0,     0, 1 },  /* ha.no */
  { 37961,     0,     0, 1 },  /* habmer.no */
  { 37968,     0,     0, 1 },  /* hadsel.no */
  { 37975,     0,     0, 1 },  /* hagebostad.no */
  { 37986,     0,     0, 1 },  /* halden.no */
  { 37993,     0,     0, 1 },  /* halsa.no */
  { 18867,     0,     0, 1 },  /* hamar.no */
  { 37999,     0,     0, 1 },  /* hamaroy.no */
  { 38007,     0,     0, 1 },  /* hammarfeasta.no */
  { 38020,     0,     0, 1 },  /* hammerfest.no */
  { 38031,     0,     0, 1 },  /* hapmir.no */
  { 38038,     0,     0, 1 },  /* haram.no */
  { 37433,     0,     0, 1 },  /* hareid.no */
  { 38044,     0,     0, 1 },  /* harstad.no */
  { 38052,     0,     0, 1 },  /* hasvik.no */
  { 38059,     0,     0, 1 },  /* hattfjelldal.no */
  { 38072,     0,     0, 1 },  /* haugesund.no */
  { 38082,  7586,     3, 0 },  /* hedmark.no */
  { 38090,     0,     0, 1 },  /* hemne.no */
  { 38096,     0,     0, 1 },  /* hemnes.no */
  { 38103,     0,     0, 1 },  /* hemsedal.no */
  { 38115,     0,     0, 1 },  /* herad.no */
  { 31847,     0,     0, 1 },  /* hitra.no */
  { 38121,     0,     0, 1 },  /* hjartdal.no */
  { 38130,     0,     0, 1 },  /* hjelmeland.no */
  {  2384,  7584,     1, 1 },  /* hl.no */
  {  3923,  7584,     1, 1 },  /* hm.no */
  { 38141,     0,     0, 1 },  /* hobol.no */
  { 32707,     0,     0, 1 },  /* hof.no */
  { 38147,     0,     0, 1 },  /* hokksund.no */
  { 38156,     0,     0, 1 },  /* hol.no */
  { 38160,     0,     0, 1 },  /* hole.no */
  { 38165,     0,     0, 1 },  /* holmestrand.no */
  { 38177,     0,     0, 1 },  /* holtalen.no */
  { 38186,     0,     0, 1 },  /* honefoss.no */
  { 16628,  7589,     1, 0 },  /* hordaland.no */
  { 38195,     0,     0, 1 },  /* hornindal.no */
  { 38205,     0,     0, 1 },  /* horten.no */
  { 38212,     0,     0, 1 },  /* hoyanger.no */
  { 38221,     0,     0, 1 },  /* hoylandet.no */
  { 38231,     0,     0, 1 },  /* hurdal.no */
  { 38238,     0,     0, 1 },  /* hurum.no */
  { 38244,     0,     0, 1 },  /* hvaler.no */
  { 38251,     0,     0, 1 },  /* hyllestad.no */
  { 38261,     0,     0, 1 },  /* ibestad.no */
  { 38269,     0,     0, 1 },  /* idrett.no */
  { 38276,     0,     0, 1 },  /* inderoy.no */
  { 38284,     0,     0, 1 },  /* iveland.no */
  {  3745,     0,     0, 1 },  /* ivgu.no */
  { 38292,  7584,     1, 1 },  /* jan-mayen.no */
  { 38302,     0,     0, 1 },  /* jessheim.no */
  { 38311,     0,     0, 1 },  /* jevnaker.no */
  { 38320,     0,     0, 1 },  /* jolster.no */
  { 38328,     0,     0, 1 },  /* jondal.no */
  { 38335,     0,     0, 1 },  /* jorpeland.no */
  { 36783,     0,     0, 1 },  /* kafjord.no */
  { 38345,     0,     0, 1 },  /* karasjohka.no */
  { 38356,     0,     0, 1 },  /* karasjok.no */
  { 38365,     0,     0, 1 },  /* karlsoy.no */
  { 38373,     0,     0, 1 },  /* karmoy.no */
  { 38380,     0,     0, 1 },  /* kautokeino.no */
  { 38391,     0,     0, 1 },  /* kirkenes.no */
  { 38400,     0,     0, 1 },  /* klabu.no */
  { 11644,     0,     0, 1 },  /* klepp.no */
  { 38406,     0,     0, 1 },  /* kommune.no */
  { 38414,     0,     0, 1 },  /* kongsberg.no */
  { 38424,     0,     0, 1 },  /* kongsvinger.no */
  { 38436,     0,     0, 1 },  /* kopervik.no */
  { 38445,     0,     0, 1 },  /* kraanghke.no */
  { 38455,     0,     0, 1 },  /* kragero.no */
  { 38463,     0,     0, 1 },  /* kristiansand.no */
  { 38476,     0,     0, 1 },  /* kristiansund.no */
  { 38489,     0,     0, 1 },  /* krodsherad.no */
  { 38500,     0,     0, 1 },  /* krokstadelva.no */
  { 38513,     0,     0, 1 },  /* kvafjord.no */
  { 38522,     0,     0, 1 },  /* kvalsund.no */
  { 38531,     0,     0, 1 },  /* kvam.no */
  { 38536,     0,     0, 1 },  /* kvanangen.no */
  { 38546,     0,     0, 1 },  /* kvinesdal.no */
  { 38556,     0,     0, 1 },  /* kvinnherad.no */
  { 38567,     0,     0, 1 },  /* kviteseid.no */
  { 38577,     0,     0, 1 },  /* kvitsoy.no */
  { 38585,     0,     0, 1 },  /* laakesvuemie.no */
  { 38598,     0,     0, 1 },  /* lahppi.no */
  { 38605,     0,     0, 1 },  /* langevag.no */
  { 36910,     0,     0, 1 },  /* lardal.no */
  { 38614,     0,     0, 1 },  /* larvik.no */
  { 38621,     0,     0, 1 },  /* lavagis.no */
  { 38629,     0,     0, 1 },  /* lavangen.no */
  { 38638,     0,     0, 1 },  /* leangaviika.no */
  { 38650,     0,     0, 1 },  /* lebesby.no */
  { 38658,     0,     0, 1 },  /* leikanger.no */
  { 38668,     0,     0, 1 },  /* leirfjord.no */
  { 38678,     0,     0, 1 },  /* leirvik.no */
  { 38691,     0,     0, 1 },  /* leka.no */
  { 38696,     0,     0, 1 },  /* leksvik.no */
  { 38704,     0,     0, 1 },  /* lenvik.no */
  { 38711,     0,     0, 1 },  /* lerdal.no */
  { 38718,     0,     0, 1 },  /* lesja.no */
  { 38724,     0,     0, 1 },  /* levanger.no */
  {  2733,     0,     0, 1 },  /* lier.no */
  { 38733,     0,     0, 1 },  /* lierne.no */
  { 38740,     0,     0, 1 },  /* lillehammer.no */
  { 38752,     0,     0, 1 },  /* lillesand.no */
  { 38762,     0,     0, 1 },  /* lindas.no */
  { 38769,     0,     0, 1 },  /* lindesnes.no */
  { 38779,     0,     0, 1 },  /* loabat.no */
  { 38786,     0,     0, 1 },  /* lodingen.no */
  { 18813,     0,     0, 1 },  /* lom.no */
  { 38795,     0,     0, 1 },  /* loppa.no */
  { 38801,     0,     0, 1 },  /* lorenskog.no */
  { 38811,     0,     0, 1 },  /* loten.no */
  { 38819,     0,     0, 1 },  /* lund.no */
  { 38824,     0,     0, 1 },  /* lunner.no */
  { 38831,     0,     0, 1 },  /* luroy.no */
  { 36295,     0,     0, 1 },  /* luster.no */
  { 38837,     0,     0, 1 },  /* lyngdal.no */
  { 38845,     0,     0, 1 },  /* lyngen.no */
  { 38852,     0,     0, 1 },  /* malatvuopmi.no */
  {  5109,     0,     0, 1 },  /* malselv.no */
  { 38864,     0,     0, 1 },  /* malvik.no */
  { 38871,     0,     0, 1 },  /* mandal.no */
  { 38878,     0,     0, 1 },  /* marker.no */
  { 38885,     0,     0, 1 },  /* marnardal.no */
  { 38895,     0,     0, 1 },  /* masfjorden.no */
  {  7360,     0,     0, 1 },  /* masoy.no */
  { 38906,     0,     0, 1 },  /* matta-varjjat.no */
  { 38134,     0,     0, 1 },  /* meland.no */
  { 38920,     0,     0, 1 },  /* meldal.no */
  { 38927,     0,     0, 1 },  /* melhus.no */
  { 38934,     0,     0, 1 },  /* meloy.no */
  { 38940,     0,     0, 1 },  /* meraker.no */
  { 38948,     0,     0, 1 },  /* midsund.no */
  { 38956,     0,     0, 1 },  /* midtre-gauldal.no */
  {  4157,     0,     0, 1 },  /* mil.no */
  { 38971,     0,     0, 1 },  /* mjondalen.no */
  { 38981,     0,     0, 1 },  /* mo-i-rana.no */
  { 38991,     0,     0, 1 },  /* moareke.no */
  { 38999,     0,     0, 1 },  /* modalen.no */
  { 39007,     0,     0, 1 },  /* modum.no */
  { 39013,     0,     0, 1 },  /* molde.no */
  { 39019,  7590,     2, 0 },  /* more-og-romsdal.no */
  { 39035,     0,     0, 1 },  /* mosjoen.no */
  { 39043,     0,     0, 1 },  /* moskenes.no */
  { 19442,     0,     0, 1 },  /* moss.no */
  { 39052,     0,     0, 1 },  /* mosvik.no */
  {  5558,  7584,     1, 1 },  /* mr.no */
  { 39059,     0,     0, 1 },  /* muosat.no */
  {  5596,     0,     0, 1 },  /* museum.no */
  { 39066,     0,     0, 1 },  /* naamesjevuemie.no */
  { 39081,     0,     0, 1 },  /* namdalseid.no */
  { 39092,     0,     0, 1 },  /* namsos.no */
  { 39099,     0,     0, 1 },  /* namsskogan.no */
  { 39110,     0,     0, 1 },  /* nannestad.no */
  { 39120,     0,     0, 1 },  /* naroy.no */
  { 39126,     0,     0, 1 },  /* narviika.no */
  { 39135,     0,     0, 1 },  /* narvik.no */
  { 39142,     0,     0, 1 },  /* naustdal.no */
  { 39151,     0,     0, 1 },  /* navuotna.no */
  { 39160,     0,     0, 1 },  /* nedre-eiker.no */
  { 39172,     0,     0, 1 },  /* nesna.no */
  { 39178,     0,     0, 1 },  /* nesodden.no */
  { 39187,     0,     0, 1 },  /* nesoddtangen.no */
  { 39200,     0,     0, 1 },  /* nesseby.no */
  { 39208,     0,     0, 1 },  /* nesset.no */
  { 39215,     0,     0, 1 },  /* nissedal.no */
  { 39224,     0,     0, 1 },  /* nittedal.no */
  {  1072,  7584,     1, 1 },  /* nl.no */
  { 39233,     0,     0, 1 },  /* nord-aurdal.no */
  { 39245,     0,     0, 1 },  /* nord-fron.no */
  { 39255,     0,     0, 1 },  /* nord-odal.no */
  { 39265,     0,     0, 1 },  /* norddal.no */
  { 39273,     0,     0, 1 },  /* nordkapp.no */
  { 39282,  7592,     4, 0 },  /* nordland.no */
  { 39291,     0,     0, 1 },  /* nordre-land.no */
  { 39303,     0,     0, 1 },  /* nordreisa.no */
  { 39313,     0,     0, 1 },  /* nore-og-uvdal.no */
  { 39327,     0,     0, 1 },  /* notodden.no */
  { 39336,     0,     0, 1 },  /* notteroy.no */
  {    97,  7584,     1, 1 },  /* nt.no */
  { 39345,     0,     0, 1 },  /* odda.no */
  {  6399,  7584,     1, 1 },  /* of.no */
  { 39350,     0,     0, 1 },  /* oksnes.no */
  {   452,  7584,     1, 1 },  /* ol.no */
  { 39357,     0,     0, 1 },  /* omasvuotna.no */
  { 39368,     0,     0, 1 },  /* oppdal.no */
  { 39375,     0,     0, 1 },  /* oppegard.no */
  { 39384,     0,     0, 1 },  /* orkanger.no */
  { 39393,     0,     0, 1 },  /* orkdal.no */
  {  4747,     0,     0, 1 },  /* orland.no */
  { 39400,     0,     0, 1 },  /* orskog.no */
  { 39407,     0,     0, 1 },  /* orsta.no */
  { 28608,     0,     0, 1 },  /* osen.no */
  { 39413,  7584,     1, 1 },  /* oslo.no */
  { 39418,     0,     0, 1 },  /* osoyro.no */
  { 39425,     0,     0, 1 },  /* osteroy.no */
  { 39433,  7596,     1, 0 },  /* ostfold.no */
  { 39441,     0,     0, 1 },  /* ostre-toten.no */
  { 39453,     0,     0, 1 },  /* overhalla.no */
  { 39463,     0,     0, 1 },  /* ovre-eiker.no */
  { 39474,     0,     0, 1 },  /* oyer.no */
  { 39479,     0,     0, 1 },  /* oygarden.no */
  { 39488,     0,     0, 1 },  /* oystre-slidre.no */
  { 39502,     0,     0, 1 },  /* porsanger.no */
  { 39512,     0,     0, 1 },  /* porsangu.no */
  { 39521,     0,     0, 1 },  /* porsgrunn.no */
  { 11594,     0,     0, 1 },  /* priv.no */
  {  7976,     0,     0, 1 },  /* rade.no */
  { 39531,     0,     0, 1 },  /* radoy.no */
  { 39537,     0,     0, 1 },  /* rahkkeravju.no */
  { 39549,     0,     0, 1 },  /* raholt.no */
  { 39556,     0,     0, 1 },  /* raisa.no */
  { 39562,     0,     0, 1 },  /* rakkestad.no */
  { 39572,     0,     0, 1 },  /* ralingen.no */
  { 37683,     0,     0, 1 },  /* rana.no */
  { 39581,     0,     0, 1 },  /* randaberg.no */
  { 39591,     0,     0, 1 },  /* rauma.no */
  { 39597,     0,     0, 1 },  /* rendalen.no */
  { 39606,     0,     0, 1 },  /* rennebu.no */
  { 39614,     0,     0, 1 },  /* rennesoy.no */
  { 39623,     0,     0, 1 },  /* rindal.no */
  { 39630,     0,     0, 1 },  /* ringebu.no */
  { 39638,     0,     0, 1 },  /* ringerike.no */
  { 39648,     0,     0, 1 },  /* ringsaker.no */
  { 39658,     0,     0, 1 },  /* risor.no */
  { 39664,     0,     0, 1 },  /* rissa.no */
  {  3250,  7584,     1, 1 },  /* rl.no */
  { 39670,     0,     0, 1 },  /* roan.no */
  { 39675,     0,     0, 1 },  /* rodoy.no */
  { 39681,     0,     0, 1 },  /* rollag.no */
  { 39689,     0,     0, 1 },  /* romsa.no */
  { 39695,     0,     0, 1 },  /* romskog.no */
  { 39703,     0,     0, 1 },  /* roros.no */
  { 39709,     0,     0, 1 },  /* rost.no */
  { 39714,     0,     0, 1 },  /* royken.no */
  { 39721,     0,     0, 1 },  /* royrvik.no */
  { 39729,     0,     0, 1 },  /* ruovat.no */
  { 39736,     0,     0, 1 },  /* rygge.no */
  { 39742,     0,     0, 1 },  /* salangen.no */
  {  2790,     0,     0, 1 },  /* salat.no */
  { 39751,     0,     0, 1 },  /* saltdal.no */
  { 39759,     0,     0, 1 },  /* samnanger.no */
  { 39769,     0,     0, 1 },  /* sandefjord.no */
  { 39780,     0,     0, 1 },  /* sandnes.no */
  { 39788,     0,     0, 1 },  /* sandnessjoen.no */
  { 36903,     0,     0, 1 },  /* sandoy.no */
  {  6020,     0,     0, 1 },  /* sarpsborg.no */
  { 39801,     0,     0, 1 },  /* sauda.no */
  { 38112,     0,     0, 1 },  /* sauherad.no */
  { 32459,     0,     0, 1 },  /* sel.no */
  { 39807,     0,     0, 1 },  /* selbu.no */
  { 39813,     0,     0, 1 },  /* selje.no */
  { 39819,     0,     0, 1 },  /* seljord.no */
  { 11701,  7584,     1, 1 },  /* sf.no */
  { 39827,     0,     0, 1 },  /* siellak.no */
  { 39835,     0,     0, 1 },  /* sigdal.no */
  { 39842,     0,     0, 1 },  /* siljan.no */
  { 39849,     0,     0, 1 },  /* sirdal.no */
  { 39856,     0,     0, 1 },  /* skanit.no */
  { 39863,     0,     0, 1 },  /* skanland.no */
  { 39872,     0,     0, 1 },  /* skaun.no */
  { 39878,     0,     0, 1 },  /* skedsmo.no */
  { 39886,     0,     0, 1 },  /* skedsmokorset.no */
  {  4550,     0,     0, 1 },  /* ski.no */
  { 39900,     0,     0, 1 },  /* skien.no */
  { 39906,     0,     0, 1 },  /* skierva.no */
  {  8218,     0,     0, 1 },  /* skiptvet.no */
  { 39914,     0,     0, 1 },  /* skjak.no */
  { 39920,     0,     0, 1 },  /* skjervoy.no */
  { 39929,     0,     0, 1 },  /* skodje.no */
  { 39936,     0,     0, 1 },  /* slattum.no */
  { 39944,     0,     0, 1 },  /* smola.no */
  { 39950,     0,     0, 1 },  /* snaase.no */
  { 39957,     0,     0, 1 },  /* snasa.no */
  { 39963,     0,     0, 1 },  /* snillfjord.no */
  { 39974,     0,     0, 1 },  /* snoasa.no */
  { 39981,     0,     0, 1 },  /* sogndal.no */
  { 39989,     0,     0, 1 },  /* sogne.no */
  { 39995,     0,     0, 1 },  /* sokndal.no */
  { 40003,     0,     0, 1 },  /* sola.no */
  { 38817,     0,     0, 1 },  /* solund.no */
  { 40008,     0,     0, 1 },  /* somna.no */
  { 40014,     0,     0, 1 },  /* sondre-land.no */
  { 40026,     0,     0, 1 },  /* songdalen.no */
  { 40036,     0,     0, 1 },  /* sor-aurdal.no */
  { 40047,     0,     0, 1 },  /* sor-fron.no */
  { 40056,     0,     0, 1 },  /* sor-odal.no */
  { 40065,     0,     0, 1 },  /* sor-varanger.no */
  { 40078,     0,     0, 1 },  /* sorfold.no */
  { 40086,     0,     0, 1 },  /* sorreisa.no */
  { 40095,     0,     0, 1 },  /* sortland.no */
  { 40104,     0,     0, 1 },  /* sorum.no */
  { 40110,     0,     0, 1 },  /* spjelkavik.no */
  { 40121,     0,     0, 1 },  /* spydeberg.no */
  {   619,  7584,     1, 1 },  /* st.no */
  { 40131,     0,     0, 1 },  /* stange.no */
  { 40138,     0,     0, 1 },  /* stat.no */
  { 40143,     0,     0, 1 },  /* stathelle.no */
  { 40153,     0,     0, 1 },  /* stavanger.no */
  { 40163,     0,     0, 1 },  /* stavern.no */
  { 40171,     0,     0, 1 },  /* steigen.no */
  { 40179,     0,     0, 1 },  /* steinkjer.no */
  { 40189,     0,     0, 1 },  /* stjordal.no */
  { 40198,     0,     0, 1 },  /* stjordalshalsen.no */
  { 40214,     0,     0, 1 },  /* stokke.no */
  { 40221,     0,     0, 1 },  /* stor-elvdal.no */
  { 40233,     0,     0, 1 },  /* stord.no */
  { 40239,     0,     0, 1 },  /* stordal.no */
  { 40247,     0,     0, 1 },  /* storfjord.no */
  { 37090,     0,     0, 1 },  /* strand.no */
  { 40257,     0,     0, 1 },  /* stranda.no */
  { 12850,     0,     0, 1 },  /* stryn.no */
  { 40265,     0,     0, 1 },  /* sula.no */
  { 40270,     0,     0, 1 },  /* suldal.no */
  { 36841,     0,     0, 1 },  /* sund.no */
  { 40277,     0,     0, 1 },  /* sunndal.no */
  { 40285,     0,     0, 1 },  /* surnadal.no */
  { 40294,  7584,     1, 1 },  /* svalbard.no */
  { 40303,     0,     0, 1 },  /* sveio.no */
  { 40309,     0,     0, 1 },  /* svelvik.no */
  { 40317,     0,     0, 1 },  /* sykkylven.no */
  { 28310,     0,     0, 1 },  /* tana.no */
  { 40327,     0,     0, 1 },  /* tananger.no */
  { 40336,  7597,     2, 0 },  /* telemark.no */
  {  7220,     0,     0, 1 },  /* time.no */
  { 40345,     0,     0, 1 },  /* tingvoll.no */
  { 40354,     0,     0, 1 },  /* tinn.no */
  { 40359,     0,     0, 1 },  /* tjeldsund.no */
  { 40369,     0,     0, 1 },  /* tjome.no */
  {  7890,  7584,     1, 1 },  /* tm.no */
  { 40215,     0,     0, 1 },  /* tokke.no */
  { 40375,     0,     0, 1 },  /* tolga.no */
  { 40381,     0,     0, 1 },  /* tonsberg.no */
  { 40390,     0,     0, 1 },  /* torsken.no */
  {  3281,  7584,     1, 1 },  /* tr.no */
  { 40398,     0,     0, 1 },  /* trana.no */
  { 40404,     0,     0, 1 },  /* tranby.no */
  { 40411,     0,     0, 1 },  /* tranoy.no */
  { 40418,     0,     0, 1 },  /* troandin.no */
  { 40427,     0,     0, 1 },  /* trogstad.no */
  { 39688,     0,     0, 1 },  /* tromsa.no */
  { 40436,     0,     0, 1 },  /* tromso.no */
  { 40443,     0,     0, 1 },  /* trondheim.no */
  { 40453,     0,     0, 1 },  /* trysil.no */
  { 40460,     0,     0, 1 },  /* tvedestrand.no */
  { 40472,     0,     0, 1 },  /* tydal.no */
  { 40478,     0,     0, 1 },  /* tynset.no */
  { 40485,     0,     0, 1 },  /* tysfjord.no */
  { 40494,     0,     0, 1 },  /* tysnes.no */
  { 40501,     0,     0, 1 },  /* tysvar.no */
  { 40508,     0,     0, 1 },  /* ullensaker.no */
  { 40519,     0,     0, 1 },  /* ullensvang.no */
  { 40530,     0,     0, 1 },  /* ulvik.no */
  { 40536,     0,     0, 1 },  /* unjarga.no */
  { 40544,     0,     0, 1 },  /* utsira.no */
  {   834,  7584,     1, 1 },  /* va.no */
  { 40551,     0,     0, 1 },  /* vaapste.no */
  { 40559,     0,     0, 1 },  /* vadso.no */
  { 40565,     0,     0, 1 },  /* vaga.no */
  { 40570,     0,     0, 1 },  /* vagan.no */
  { 40576,     0,     0, 1 },  /* vagsoy.no */
  { 40583,     0,     0, 1 },  /* vaksdal.no */
  { 40591,     0,     0, 1 },  /* valle.no */
  { 40525,     0,     0, 1 },  /* vang.no */
  { 40597,     0,     0, 1 },  /* vanylven.no */
  { 40606,     0,     0, 1 },  /* vardo.no */
  { 40612,     0,     0, 1 },  /* varggat.no */
  { 40620,     0,     0, 1 },  /* varoy.no */
  { 40626,     0,     0, 1 },  /* vefsn.no */
  { 40632,     0,     0, 1 },  /* vega.no */
  { 40637,     0,     0, 1 },  /* vegarshei.no */
  { 40647,     0,     0, 1 },  /* vennesla.no */
  { 40656,     0,     0, 1 },  /* verdal.no */
  { 40663,     0,     0, 1 },  /* verran.no */
  { 40670,     0,     0, 1 },  /* vestby.no */
  { 40677,  7599,     1, 0 },  /* vestfold.no */
  { 40686,     0,     0, 1 },  /* vestnes.no */
  { 40694,     0,     0, 1 },  /* vestre-slidre.no */
  { 40708,     0,     0, 1 },  /* vestre-toten.no */
  { 40721,     0,     0, 1 },  /* vestvagoy.no */
  { 40731,     0,     0, 1 },  /* vevelstad.no */
  {  9751,  7584,     1, 1 },  /* vf.no */
  {  3738,     0,     0, 1 },  /* vgs.no */
  {  6901,     0,     0, 1 },  /* vik.no */
  { 40741,     0,     0, 1 },  /* vikna.no */
  { 40747,     0,     0, 1 },  /* vindafjord.no */
  { 40758,     0,     0, 1 },  /* voagat.no */
  { 40765,     0,     0, 1 },  /* volda.no */
  { 40771,     0,     0, 1 },  /* voss.no */
  { 40776,     0,     0, 1 },  /* vossevangen.no */
  { 40788,     0,     0, 1 },  /* xn--andy-ira.no */
  { 40801,     0,     0, 1 },  /* xn--asky-ira.no */
  { 40814,     0,     0, 1 },  /* xn--aurskog-hland-jnb.no */
  { 40836,     0,     0, 1 },  /* xn--avery-yua.no */
  { 40850,     0,     0, 1 },  /* xn--bdddj-mrabd.no */
  { 40866,     0,     0, 1 },  /* xn--bearalvhki-y4a.no */
  { 40885,     0,     0, 1 },  /* xn--berlevg-jxa.no */
  { 40901,     0,     0, 1 },  /* xn--bhcavuotna-s4a.no */
  { 40920,     0,     0, 1 },  /* xn--bhccavuotna-k7a.no */
  { 40940,     0,     0, 1 },  /* xn--bidr-5nac.no */
  {  6477,     0,     0, 1 },  /* xn--bievt-0qa.no */
  { 40954,     0,     0, 1 },  /* xn--bjarky-fya.no */
  { 40969,     0,     0, 1 },  /* xn--bjddar-pta.no */
  { 40984,     0,     0, 1 },  /* xn--blt-elab.no */
  { 40997,     0,     0, 1 },  /* xn--bmlo-gra.no */
  { 41010,     0,     0, 1 },  /* xn--bod-2na.no */
  { 41022,     0,     0, 1 },  /* xn--brnny-wuac.no */
  { 41037,     0,     0, 1 },  /* xn--brnnysund-m8ac.no */
  { 41056,     0,     0, 1 },  /* xn--brum-voa.no */
  { 41069,     0,     0, 1 },  /* xn--btsfjord-9za.no */
  { 41086,     0,     0, 1 },  /* xn--davvenjrga-y4a.no */
  { 41105,     0,     0, 1 },  /* xn--dnna-gra.no */
  { 41118,     0,     0, 1 },  /* xn--drbak-wua.no */
  { 41132,     0,     0, 1 },  /* xn--dyry-ira.no */
  { 41145,     0,     0, 1 },  /* xn--eveni-0qa01ga.no */
  { 41163,     0,     0, 1 },  /* xn--finny-yua.no */
  { 41177,     0,     0, 1 },  /* xn--fjord-lra.no */
  { 41191,     0,     0, 1 },  /* xn--fl-zia.no */
  { 41202,     0,     0, 1 },  /* xn--flor-jra.no */
  { 41215,     0,     0, 1 },  /* xn--frde-gra.no */
  { 41228,     0,     0, 1 },  /* xn--frna-woa.no */
  { 41241,     0,     0, 1 },  /* xn--frya-hra.no */
  { 41254,     0,     0, 1 },  /* xn--ggaviika-8ya47h.no */
  { 41274,     0,     0, 1 },  /* xn--gildeskl-g0a.no */
  { 41291,     0,     0, 1 },  /* xn--givuotna-8ya.no */
  { 41308,     0,     0, 1 },  /* xn--gjvik-wua.no */
  { 41322,     0,     0, 1 },  /* xn--gls-elac.no */
  { 41335,     0,     0, 1 },  /* xn--h-2fa.no */
  { 41345,     0,     0, 1 },  /* xn--hbmer-xqa.no */
  { 41359,     0,     0, 1 },  /* xn--hcesuolo-7ya35b.no */
  { 41379,     0,     0, 1 },  /* xn--hgebostad-g3a.no */
  { 41397,     0,     0, 1 },  /* xn--hmmrfeasta-s4ac.no */
  { 41417,     0,     0, 1 },  /* xn--hnefoss-q1a.no */
  { 41433,     0,     0, 1 },  /* xn--hobl-ira.no */
  { 41446,     0,     0, 1 },  /* xn--holtlen-hxa.no */
  { 41462,     0,     0, 1 },  /* xn--hpmir-xqa.no */
  { 41476,     0,     0, 1 },  /* xn--hyanger-q1a.no */
  { 41492,     0,     0, 1 },  /* xn--hylandet-54a.no */
  { 41509,     0,     0, 1 },  /* xn--indery-fya.no */
  { 41524,     0,     0, 1 },  /* xn--jlster-bya.no */
  { 41539,     0,     0, 1 },  /* xn--jrpeland-54a.no */
  { 41556,     0,     0, 1 },  /* xn--karmy-yua.no */
  { 41570,     0,     0, 1 },  /* xn--kfjord-iua.no */
  { 41585,     0,     0, 1 },  /* xn--klbu-woa.no */
  { 41598,     0,     0, 1 },  /* xn--koluokta-7ya57h.no */
  { 41618,     0,     0, 1 },  /* xn--krager-gya.no */
  { 41633,     0,     0, 1 },  /* xn--kranghke-b0a.no */
  { 41650,     0,     0, 1 },  /* xn--krdsherad-m8a.no */
  { 41668,     0,     0, 1 },  /* xn--krehamn-dxa.no */
  { 41684,     0,     0, 1 },  /* xn--krjohka-hwab49j.no */
  { 41704,     0,     0, 1 },  /* xn--ksnes-uua.no */
  { 41718,     0,     0, 1 },  /* xn--kvfjord-nxa.no */
  { 41734,     0,     0, 1 },  /* xn--kvitsy-fya.no */
  { 41749,     0,     0, 1 },  /* xn--kvnangen-k0a.no */
  { 41766,     0,     0, 1 },  /* xn--l-1fa.no */
  { 41776,     0,     0, 1 },  /* xn--laheadju-7ya.no */
  { 41793,     0,     0, 1 },  /* xn--langevg-jxa.no */
  { 41809,     0,     0, 1 },  /* xn--ldingen-q1a.no */
  { 41825,     0,     0, 1 },  /* xn--leagaviika-52b.no */
  { 41844,     0,     0, 1 },  /* xn--lesund-hua.no */
  { 41859,     0,     0, 1 },  /* xn--lgrd-poac.no */
  { 41873,     0,     0, 1 },  /* xn--lhppi-xqa.no */
  { 41887,     0,     0, 1 },  /* xn--linds-pra.no */
  { 41901,     0,     0, 1 },  /* xn--loabt-0qa.no */
  { 41915,     0,     0, 1 },  /* xn--lrdal-sra.no */
  { 41929,     0,     0, 1 },  /* xn--lrenskog-54a.no */
  { 41946,     0,     0, 1 },  /* xn--lt-liac.no */
  { 41958,     0,     0, 1 },  /* xn--lten-gra.no */
  { 41971,     0,     0, 1 },  /* xn--lury-ira.no */
  { 41984,     0,     0, 1 },  /* xn--mely-ira.no */
  { 41997,     0,     0, 1 },  /* xn--merker-kua.no */
  { 42012,     0,     0, 1 },  /* xn--mjndalen-64a.no */
  { 42029,     0,     0, 1 },  /* xn--mlatvuopmi-s4a.no */
  { 42048,     0,     0, 1 },  /* xn--mli-tla.no */
  { 42060,     0,     0, 1 },  /* xn--mlselv-iua.no */
  { 42075,     0,     0, 1 },  /* xn--moreke-jua.no */
  { 42090,     0,     0, 1 },  /* xn--mosjen-eya.no */
  { 42105,     0,     0, 1 },  /* xn--mot-tla.no */
  { 42117,  7600,     2, 0 },  /* xn--mre-og-romsdal-qqb.no */
  { 42140,     0,     0, 1 },  /* xn--msy-ula0h.no */
  { 42154,     0,     0, 1 },  /* xn--mtta-vrjjat-k7af.no */
  { 42175,     0,     0, 1 },  /* xn--muost-0qa.no */
  {  1539,     0,     0, 1 },  /* xn--nmesjevuemie-tcba.no */
  { 42189,     0,     0, 1 },  /* xn--nry-yla5g.no */
  { 42203,     0,     0, 1 },  /* xn--nttery-byae.no */
  { 42219,     0,     0, 1 },  /* xn--nvuotna-hwa.no */
  { 42235,     0,     0, 1 },  /* xn--oppegrd-ixa.no */
  { 42251,     0,     0, 1 },  /* xn--ostery-fya.no */
  { 42266,     0,     0, 1 },  /* xn--osyro-wua.no */
  { 42280,     0,     0, 1 },  /* xn--porsgu-sta26f.no */
  { 42298,     0,     0, 1 },  /* xn--rady-ira.no */
  { 12386,     0,     0, 1 },  /* xn--rdal-poa.no */
  { 42311,     0,     0, 1 },  /* xn--rde-ula.no */
  {  5642,     0,     0, 1 },  /* xn--rdy-0nab.no */
  { 42323,     0,     0, 1 },  /* xn--rennesy-v1a.no */
  {   175,     0,     0, 1 },  /* xn--rhkkervju-01af.no */
  { 42339,     0,     0, 1 },  /* xn--rholt-mra.no */
  { 42353,     0,     0, 1 },  /* xn--risa-5na.no */
  { 42366,     0,     0, 1 },  /* xn--risr-ira.no */
  { 42379,     0,     0, 1 },  /* xn--rland-uua.no */
  { 42393,     0,     0, 1 },  /* xn--rlingen-mxa.no */
  { 42409,     0,     0, 1 },  /* xn--rmskog-bya.no */
  { 42424,     0,     0, 1 },  /* xn--rros-gra.no */
  { 42437,     0,     0, 1 },  /* xn--rskog-uua.no */
  { 42451,     0,     0, 1 },  /* xn--rst-0na.no */
  { 42463,     0,     0, 1 },  /* xn--rsta-fra.no */
  { 42476,     0,     0, 1 },  /* xn--ryken-vua.no */
  { 42490,     0,     0, 1 },  /* xn--ryrvik-bya.no */
  { 42505,     0,     0, 1 },  /* xn--s-1fa.no */
  {  3403,     0,     0, 1 },  /* xn--sandnessjen-ogb.no */
  { 42515,     0,     0, 1 },  /* xn--sandy-yua.no */
  { 42529,     0,     0, 1 },  /* xn--seral-lra.no */
  { 42543,     0,     0, 1 },  /* xn--sgne-gra.no */
  { 42556,     0,     0, 1 },  /* xn--skierv-uta.no */
  { 42571,     0,     0, 1 },  /* xn--skjervy-v1a.no */
  { 42587,     0,     0, 1 },  /* xn--skjk-soa.no */
  { 42600,     0,     0, 1 },  /* xn--sknit-yqa.no */
  { 42614,     0,     0, 1 },  /* xn--sknland-fxa.no */
  { 42630,     0,     0, 1 },  /* xn--slat-5na.no */
  { 42643,     0,     0, 1 },  /* xn--slt-elab.no */
  { 42656,     0,     0, 1 },  /* xn--smla-hra.no */
  { 42669,     0,     0, 1 },  /* xn--smna-gra.no */
  { 42682,     0,     0, 1 },  /* xn--snase-nra.no */
  { 42696,     0,     0, 1 },  /* xn--sndre-land-0cb.no */
  { 42715,     0,     0, 1 },  /* xn--snes-poa.no */
  { 42728,     0,     0, 1 },  /* xn--snsa-roa.no */
  { 42741,     0,     0, 1 },  /* xn--sr-aurdal-l8a.no */
  { 42759,     0,     0, 1 },  /* xn--sr-fron-q1a.no */
  { 42775,     0,     0, 1 },  /* xn--sr-odal-q1a.no */
  { 42791,     0,     0, 1 },  /* xn--sr-varanger-ggb.no */
  { 42811,     0,     0, 1 },  /* xn--srfold-bya.no */
  { 42826,     0,     0, 1 },  /* xn--srreisa-q1a.no */
  { 42842,     0,     0, 1 },  /* xn--srum-gra.no */
  { 42855,  7602,     1, 0 },  /* xn--stfold-9xa.no */
  { 42870,     0,     0, 1 },  /* xn--stjrdal-s1a.no */
  { 42886,     0,     0, 1 },  /* xn--stjrdalshalsen-sqb.no */
  { 42909,     0,     0, 1 },  /* xn--stre-toten-zcb.no */
  { 42928,     0,     0, 1 },  /* xn--tjme-hra.no */
  { 42941,     0,     0, 1 },  /* xn--tnsberg-q1a.no */
  { 42957,     0,     0, 1 },  /* xn--trany-yua.no */
  { 42971,     0,     0, 1 },  /* xn--trgstad-r1a.no */
  { 42987,     0,     0, 1 },  /* xn--trna-woa.no */
  { 43000,     0,     0, 1 },  /* xn--troms-zua.no */
  { 43014,     0,     0, 1 },  /* xn--tysvr-vra.no */
  { 43028,     0,     0, 1 },  /* xn--unjrga-rta.no */
  { 43043,     0,     0, 1 },  /* xn--vads-jra.no */
  { 43056,     0,     0, 1 },  /* xn--vard-jra.no */
  { 43069,     0,     0, 1 },  /* xn--vegrshei-c0a.no */
  { 43086,     0,     0, 1 },  /* xn--vestvgy-ixa6o.no */
  { 43104,     0,     0, 1 },  /* xn--vg-yiab.no */
  { 43116,     0,     0, 1 },  /* xn--vgan-qoa.no */
  { 43129,     0,     0, 1 },  /* xn--vgsy-qoa0j.no */
  { 43144,     0,     0, 1 },  /* xn--vre-eiker-k8a.no */
  { 43162,     0,     0, 1 },  /* xn--vrggt-xqad.no */
  { 43177,     0,     0, 1 },  /* xn--vry-yla5g.no */
  { 43191,     0,     0, 1 },  /* xn--yer-zna.no */
  { 43203,     0,     0, 1 },  /* xn--ygarden-p1a.no */
  { 43219,     0,     0, 1 },  /* xn--ystre-slidre-ujb.no */
  {    62,     0,     0, 1 },  /* ac.nz */
  {   113,  4032,     1, 1 },  /* co.nz */
  { 12185,     0,     0, 1 },  /* cri.nz */
  { 13158,     0,     0, 1 },  /* geek.nz */
  {  8364,     0,     0, 1 },  /* gen.nz */
  { 43311,     0,     0, 1 },  /* govt.nz */
  {  3838,     0,     0, 1 },  /* health.nz */
  {  4589,     0,     0, 1 },  /* iwi.nz */
  {  4588,     0,     0, 1 },  /* kiwi.nz */
  { 43316,     0,     0, 1 },  /* maori.nz */
  {  4157,     0,     0, 1 },  /* mil.nz */
  {  5710,     0,     0, 1 },  /* net.nz */
  { 12575,     0,     0, 1 },  /* nym.nz */
  {  6026,     0,     0, 1 },  /* org.nz */
  { 16037,     0,     0, 1 },  /* parliament.nz */
  {  7001,     0,     0, 1 },  /* school.nz */
  { 43322,     0,     0, 1 },  /* xn--mori-qsa.nz */
  { 43335,     0,     0, 1 },  /* accesscam.org */
  {   157,     0,     0, 1 },  /* ae.org */
  { 43345,  7617,     1, 0 },  /* amune.org */
  { 11692,     0,     0, 1 },  /* barsy.org */
  { 13007,     0,     0, 1 },  /* blogdns.org */
  { 43351,     0,     0, 1 },  /* blogsite.org */
  { 43360,     0,     0, 1 },  /* bmoattachments.org */
  { 43375,     0,     0, 1 },  /* boldlygoingnowhere.org */
  { 43394,     0,     0, 1 },  /* cable-modem.org */
  {  2580,     0,     0, 1 },  /* camdvr.org */
  { 36215,  7618,     2, 0 },  /* cdn77.org */
  {  7073,  3514,     1, 0 },  /* cdn77-secure.org */
  { 43406,     0,     0, 1 },  /* certmgr.org */
  { 11510,     0,     0, 1 },  /* cloudns.org */
  { 43414,     0,     0, 1 },  /* collegefan.org */
  { 43425,     0,     0, 1 },  /* couchpotatofries.org */
  { 16097,     0,     0, 1 },  /* ddnss.org */
  { 16435,     0,     0, 1 },  /* diskstation.org */
  { 13191,     0,     0, 1 },  /* dnsalias.org */
  { 13200,     0,     0, 1 },  /* dnsdojo.org */
  { 13219,     0,     0, 1 },  /* doesntexist.org */
  { 13231,     0,     0, 1 },  /* dontexist.org */
  { 13241,     0,     0, 1 },  /* doomdns.org */
  { 13271,     0,     0, 1 },  /* dsmynas.org */
  { 43442,     0,     0, 1 },  /* duckdns.org */
  { 43450,     0,     0, 1 },  /* dvrdns.org */
  { 13290,     0,     0, 1 },  /* dynalias.org */
  { 11733,  7621,     2, 1 },  /* dyndns.org */
  { 43457,     0,     0, 1 },  /* dynserv.org */
  { 36356,     0,     0, 1 },  /* endofinternet.org */
  { 43465,     0,     0, 1 },  /* endoftheinternet.org */
  {  2796,  7623,    55, 1 },  /* eu.org */
  { 13526,     0,     0, 1 },  /* familyds.org */
  { 43482,     0,     0, 1 },  /* fedorainfracloud.org */
  { 43499,     0,     0, 1 },  /* fedorapeople.org */
  { 35227,  3515,     3, 0 },  /* fedoraproject.org */
  { 43512,     0,     0, 1 },  /* freeddns.org */
  {  7921,     0,     0, 1 },  /* freedesktop.org */
  { 43521,     0,     0, 1 },  /* from-me.org */
  { 43529,     0,     0, 1 },  /* game-host.org */
  { 12658,     0,     0, 1 },  /* gotdns.org */
  { 43539,     0,     0, 1 },  /* hepforge.org */
  {  3916,     0,     0, 1 },  /* hk.org */
  { 14081,     0,     0, 1 },  /* hobby-site.org */
  { 43548,     0,     0, 1 },  /* homedns.org */
  { 36461,     0,     0, 1 },  /* homeftp.org */
  { 14092,     0,     0, 1 },  /* homelinux.org */
  { 14133,     0,     0, 1 },  /* homeunix.org */
  { 32055,     0,     0, 1 },  /* hopto.org */
  { 43556,     0,     0, 1 },  /* is-a-bruinsfan.org */
  { 43571,     0,     0, 1 },  /* is-a-candidate.org */
  { 43586,     0,     0, 1 },  /* is-a-celticsfan.org */
  { 14224,     0,     0, 1 },  /* is-a-chef.org */
  { 14316,     0,     0, 1 },  /* is-a-geek.org */
  { 43602,     0,     0, 1 },  /* is-a-knight.org */
  { 43614,     0,     0, 1 },  /* is-a-linux-user.org */
  { 43630,     0,     0, 1 },  /* is-a-patsfan.org */
  { 43643,     0,     0, 1 },  /* is-a-soxfan.org */
  { 43655,     0,     0, 1 },  /* is-found.org */
  { 43664,     0,     0, 1 },  /* is-lost.org */
  { 43672,     0,     0, 1 },  /* is-saved.org */
  { 43681,     0,     0, 1 },  /* is-very-bad.org */
  { 43693,     0,     0, 1 },  /* is-very-evil.org */
  { 43706,     0,     0, 1 },  /* is-very-good.org */
  { 43719,     0,     0, 1 },  /* is-very-nice.org */
  { 43732,     0,     0, 1 },  /* is-very-sweet.org */
  { 14739,     0,     0, 1 },  /* isa-geek.org */
  { 11719,     0,     0, 1 },  /* js.org */
  { 36484,     0,     0, 1 },  /* kicks-ass.org */
  { 17218,     0,     0, 1 },  /* mayfirst.org */
  { 43746,     0,     0, 1 },  /* misconfused.org */
  {  2915,     0,     0, 1 },  /* mlbfan.org */
  { 43758,     0,     0, 1 },  /* mozilla-iot.org */
  { 43770,     0,     0, 1 },  /* my-firewall.org */
  { 43782,     0,     0, 1 },  /* myfirewall.org */
  { 11789,     0,     0, 1 },  /* myftp.org */
  {  1341,     0,     0, 1 },  /* mysecuritycamera.org */
  { 43793,     0,     0, 1 },  /* mywire.org */
  { 43800,     0,     0, 1 },  /* nflfan.org */
  { 11795,     0,     0, 1 },  /* no-ip.org */
  { 36558,     0,     0, 1 },  /* now-dns.org */
  { 43807,     0,     0, 1 },  /* pimienta.org */
  { 10771,     0,     0, 1 },  /* podzone.org */
  { 43816,     0,     0, 1 },  /* poivron.org */
  { 43824,     0,     0, 1 },  /* potager.org */
  { 43832,     0,     0, 1 },  /* read-books.org */
  { 43843,     0,     0, 1 },  /* readmyblog.org */
  { 11801,     0,     0, 1 },  /* selfip.org */
  { 43854,     0,     0, 1 },  /* sellsyourhome.org */
  { 15215,     0,     0, 1 },  /* servebbs.org */
  { 15243,     0,     0, 1 },  /* serveftp.org */
  { 15252,     0,     0, 1 },  /* servegame.org */
  { 16389,     0,     0, 1 },  /* spdns.org */
  { 43868,     0,     0, 1 },  /* stuff-4-sale.org */
  { 43881,     0,     0, 1 },  /* sweetpepper.org */
  { 43893,     0,     0, 1 },  /* tunk.org */
  {  2905,     0,     0, 1 },  /* tuxfamily.org */
  { 12642,     0,     0, 1 },  /* twmail.org */
  { 43898,     0,     0, 1 },  /* ufcfan.org */
  { 43905,     0,     0, 1 },  /* uklugs.org */
  {   264,     0,     0, 1 },  /* us.org */
  { 11808,     0,     0, 1 },  /* webhop.org */
  { 43912,     0,     0, 1 },  /* webredirect.org */
  { 43924,     0,     0, 1 },  /* wmflabs.org */
  {  6272,     0,     0, 1 },  /* za.org */
  { 43932,     0,     0, 1 },  /* zapto.org */
  { 43947,  7620,     1, 0 },  /* origin.cdn77-secure.org */
  {  1836,     0,     0, 1 },  /* cloud.fedoraproject.org */
  {   637,  4314,     1, 0 },  /* os.fedoraproject.org */
  {  7778,  3518,     1, 0 },  /* stg.fedoraproject.org */
  {   637,  4314,     1, 0 },  /* os.stg.fedoraproject.org */
  { 11848,     0,     0, 1 },  /* agro.pl */
  {  6527,     0,     0, 1 },  /* aid.pl */
  {   527,     0,     0, 1 },  /* art.pl */
  {  7889,     0,     0, 1 },  /* atm.pl */
  { 43962,     0,     0, 1 },  /* augustow.pl */
  {   629,     0,     0, 1 },  /* auto.pl */
  { 43971,     0,     0, 1 },  /* babia-gora.pl */
  { 43982,     0,     0, 1 },  /* bedzin.pl */
  { 43989,     0,     0, 1 },  /* beep.pl */
  { 43994,     0,     0, 1 },  /* beskidy.pl */
  { 44002,     0,     0, 1 },  /* bialowieza.pl */
  { 44013,     0,     0, 1 },  /* bialystok.pl */
  { 44023,     0,     0, 1 },  /* bielawa.pl */
  { 44031,     0,     0, 1 },  /* bieszczady.pl */
  {   986,     0,     0, 1 },  /* biz.pl */
  { 44042,     0,     0, 1 },  /* boleslawiec.pl */
  { 44054,     0,     0, 1 },  /* bydgoszcz.pl */
  { 44064,     0,     0, 1 },  /* bytom.pl */
  { 44070,     0,     0, 1 },  /* cieszyn.pl */
  {   113,     0,     0, 1 },  /* co.pl */
  {  1910,     0,     0, 1 },  /* com.pl */
  {  2587,     0,     0, 1 },  /* czeladz.pl */
  { 44078,     0,     0, 1 },  /* czest.pl */
  { 38686,     0,     0, 1 },  /* dlugoleka.pl */
  {  2622,     0,     0, 1 },  /* edu.pl */
  { 44084,     0,     0, 1 },  /* elblag.pl */
  {  4990,     0,     0, 1 },  /* elk.pl */
  { 44095,     0,     0, 1 },  /* gda.pl */
  { 44099,     0,     0, 1 },  /* gdansk.pl */
  { 44106,     0,     0, 1 },  /* gdynia.pl */
  { 44113,     0,     0, 1 },  /* gliwice.pl */
  { 44121,     0,     0, 1 },  /* glogow.pl */
  { 44128,     0,     0, 1 },  /* gmina.pl */
  { 44134,     0,     0, 1 },  /* gniezno.pl */
  { 44142,     0,     0, 1 },  /* gorlice.pl */
  {  3665,  7725,    47, 1 },  /* gov.pl */
  { 44150,     0,     0, 1 },  /* grajewo.pl */
  {  7289,     0,     0, 1 },  /* gsm.pl */
  { 44158,     0,     0, 1 },  /* ilawa.pl */
  {  3149,     0,     0, 1 },  /* info.pl */
  { 44164,     0,     0, 1 },  /* jaworzno.pl */
  { 44173,     0,     0, 1 },  /* jelenia-gora.pl */
  { 44186,     0,     0, 1 },  /* jgora.pl */
  { 44192,     0,     0, 1 },  /* kalisz.pl */
  { 44199,     0,     0, 1 },  /* karpacz.pl */
  { 44207,     0,     0, 1 },  /* kartuzy.pl */
  { 44215,     0,     0, 1 },  /* kaszuby.pl */
  { 44223,     0,     0, 1 },  /* katowice.pl */
  { 44232,     0,     0, 1 },  /* kazimierz-dolny.pl */
  { 44248,     0,     0, 1 },  /* kepno.pl */
  { 44254,     0,     0, 1 },  /* ketrzyn.pl */
  { 44262,     0,     0, 1 },  /* klodzko.pl */
  { 44270,     0,     0, 1 },  /* kobierzyce.pl */
  { 44281,     0,     0, 1 },  /* kolobrzeg.pl */
  { 44291,     0,     0, 1 },  /* konin.pl */
  { 44297,     0,     0, 1 },  /* konskowola.pl */
  { 44308,     0,     0, 1 },  /* krakow.pl */
  { 44315,     0,     0, 1 },  /* kutno.pl */
  { 44321,     0,     0, 1 },  /* lapy.pl */
  { 44326,     0,     0, 1 },  /* lebork.pl */
  { 44333,     0,     0, 1 },  /* legnica.pl */
  { 44341,     0,     0, 1 },  /* lezajsk.pl */
  { 44349,     0,     0, 1 },  /* limanowa.pl */
  { 44358,     0,     0, 1 },  /* lomza.pl */
  {  2195,     0,     0, 1 },  /* lowicz.pl */
  { 44364,     0,     0, 1 },  /* lubin.pl */
  { 44370,     0,     0, 1 },  /* lukow.pl */
  {  2649,     0,     0, 1 },  /* mail.pl */
  { 44376,     0,     0, 1 },  /* malbork.pl */
  { 44384,     0,     0, 1 },  /* malopolska.pl */
  { 44395,     0,     0, 1 },  /* mazowsze.pl */
  { 44404,     0,     0, 1 },  /* mazury.pl */
  {  1855,     0,     0, 1 },  /* med.pl */
  {  5294,     0,     0, 1 },  /* media.pl */
  { 44411,     0,     0, 1 },  /* miasta.pl */
  { 44418,     0,     0, 1 },  /* mielec.pl */
  { 44425,     0,     0, 1 },  /* mielno.pl */
  {  4157,     0,     0, 1 },  /* mil.pl */
  { 44432,     0,     0, 1 },  /* mragowo.pl */
  { 44440,     0,     0, 1 },  /* naklo.pl */
  {  5710,     0,     0, 1 },  /* net.pl */
  { 16596,     0,     0, 1 },  /* nieruchomosci.pl */
  {  5943,     0,     0, 1 },  /* nom.pl */
  { 44446,     0,     0, 1 },  /* nowaruda.pl */
  { 44455,     0,     0, 1 },  /* nysa.pl */
  { 44460,     0,     0, 1 },  /* olawa.pl */
  { 44466,     0,     0, 1 },  /* olecko.pl */
  { 44473,     0,     0, 1 },  /* olkusz.pl */
  { 44480,     0,     0, 1 },  /* olsztyn.pl */
  { 44488,     0,     0, 1 },  /* opoczno.pl */
  { 44496,     0,     0, 1 },  /* opole.pl */
  {  6026,     0,     0, 1 },  /* org.pl */
  { 44502,     0,     0, 1 },  /* ostroda.pl */
  { 44510,     0,     0, 1 },  /* ostroleka.pl */
  { 44520,     0,     0, 1 },  /* ostrowiec.pl */
  {  4622,     0,     0, 1 },  /* ostrowwlkp.pl */
  { 14130,     0,     0, 1 },  /* pc.pl */
  { 44530,     0,     0, 1 },  /* pila.pl */
  {  7631,     0,     0, 1 },  /* pisz.pl */
  { 44535,     0,     0, 1 },  /* podhale.pl */
  { 44543,     0,     0, 1 },  /* podlasie.pl */
  { 44552,     0,     0, 1 },  /* polkowice.pl */
  { 44562,     0,     0, 1 },  /* pomorskie.pl */
  { 44572,     0,     0, 1 },  /* pomorze.pl */
  { 44580,     0,     0, 1 },  /* powiat.pl */
  { 44587,     0,     0, 1 },  /* poznan.pl */
  { 11594,     0,     0, 1 },  /* priv.pl */
  { 44594,     0,     0, 1 },  /* prochowice.pl */
  { 44605,     0,     0, 1 },  /* pruszkow.pl */
  { 44614,     0,     0, 1 },  /* przeworsk.pl */
  { 44624,     0,     0, 1 },  /* pulawy.pl */
  { 44631,     0,     0, 1 },  /* radom.pl */
  { 44637,     0,     0, 1 },  /* rawa-maz.pl */
  {  2763,     0,     0, 1 },  /* realestate.pl */
  { 17018,     0,     0, 1 },  /* rel.pl */
  { 44646,     0,     0, 1 },  /* rybnik.pl */
  { 44653,     0,     0, 1 },  /* rzeszow.pl */
  { 44661,     0,     0, 1 },  /* sanok.pl */
  { 44667,     0,     0, 1 },  /* sejny.pl */
  {  7127,     0,     0, 1 },  /* sex.pl */
  {  7204,     0,     0, 1 },  /* shop.pl */
  { 44673,     0,     0, 1 },  /* sklep.pl */
  { 44679,     0,     0, 1 },  /* skoczow.pl */
  { 44687,     0,     0, 1 },  /* slask.pl */
  { 44693,     0,     0, 1 },  /* slupsk.pl */
  { 44700,     0,     0, 1 },  /* sopot.pl */
  { 39095,     0,     0, 1 },  /* sos.pl */
  { 44706,     0,     0, 1 },  /* sosnowiec.pl */
  { 44716,     0,     0, 1 },  /* stalowa-wola.pl */
  { 44729,     0,     0, 1 },  /* starachowice.pl */
  { 44742,     0,     0, 1 },  /* stargard.pl */
  { 44751,     0,     0, 1 },  /* suwalki.pl */
  { 44759,     0,     0, 1 },  /* swidnica.pl */
  { 44768,     0,     0, 1 },  /* swiebodzin.pl */
  { 44779,     0,     0, 1 },  /* swinoujscie.pl */
  { 44791,     0,     0, 1 },  /* szczecin.pl */
  { 44800,     0,     0, 1 },  /* szczytno.pl */
  { 44809,     0,     0, 1 },  /* szkola.pl */
  { 44816,     0,     0, 1 },  /* targi.pl */
  { 44822,     0,     0, 1 },  /* tarnobrzeg.pl */
  { 44833,     0,     0, 1 },  /* tgory.pl */
  {  7890,     0,     0, 1 },  /* tm.pl */
  { 44839,     0,     0, 1 },  /* tourism.pl */
  {  7998,     0,     0, 1 },  /* travel.pl */
  { 44847,     0,     0, 1 },  /* turek.pl */
  { 44853,     0,     0, 1 },  /* turystyka.pl */
  { 44863,     0,     0, 1 },  /* tychy.pl */
  { 44869,     0,     0, 1 },  /* ustka.pl */
  { 44875,     0,     0, 1 },  /* walbrzych.pl */
  { 44885,     0,     0, 1 },  /* warmia.pl */
  { 44892,     0,     0, 1 },  /* warszawa.pl */
  {   648,     0,     0, 1 },  /* waw.pl */
  { 44901,     0,     0, 1 },  /* wegrow.pl */
  { 44908,     0,     0, 1 },  /* wielun.pl */
  {  1781,     0,     0, 1 },  /* wlocl.pl */
  { 44915,     0,     0, 1 },  /* wloclawek.pl */
  { 44925,     0,     0, 1 },  /* wodzislaw.pl */
  { 44935,     0,     0, 1 },  /* wolomin.pl */
  { 44943,     0,     0, 1 },  /* wroc.pl */
  {  4801,     0,     0, 1 },  /* wroclaw.pl */
  { 44948,     0,     0, 1 },  /* zachpomor.pl */
  { 44958,     0,     0, 1 },  /* zagan.pl */
  { 44964,     0,     0, 1 },  /* zakopane.pl */
  { 44973,     0,     0, 1 },  /* zarow.pl */
  { 44979,     0,     0, 1 },  /* zgora.pl */
  { 44985,     0,     0, 1 },  /* zgorzelec.pl */
  {     0,     0,     0, 1 },  /* aaa.pro */
  {  1297,     0,     0, 1 },  /* aca.pro */
  { 18299,     0,     0, 1 },  /* acct.pro */
  {  1514,     0,     0, 1 },  /* avocat.pro */
  {   736,     0,     0, 1 },  /* bar.pro */
  { 11692,     0,     0, 1 },  /* barsy.pro */
  { 11510,     0,     0, 1 },  /* cloudns.pro */
  { 14257,     0,     0, 1 },  /* cpa.pro */
  { 45138,  7791,     1, 0 },  /* dnstrace.pro */
  { 12209,     0,     0, 1 },  /* eng.pro */
  { 45147,     0,     0, 1 },  /* jur.pro */
  {  4805,     0,     0, 1 },  /* law.pro */
  {  1855,     0,     0, 1 },  /* med.pro */
  {  4098,     0,     0, 1 },  /* recht.pro */
  {    62,     0,     0, 1 },  /* ac.ru */
  { 45171,     0,     0, 1 },  /* adygeya.ru */
  { 45179,     0,     0, 1 },  /* bashkiria.ru */
  {  4319,     0,     0, 1 },  /* bir.ru */
  { 10791,     0,     0, 1 },  /* blogspot.ru */
  {   931,     0,     0, 1 },  /* cbg.ru */
  { 45189,  7866,     1, 0 },  /* cldmail.ru */
  {  1910,     0,     0, 1 },  /* com.ru */
  { 45197,     0,     0, 1 },  /* dagestan.ru */
  {  2622,     0,     0, 1 },  /* edu.ru */
  {  3665,     0,     0, 1 },  /* gov.ru */
  { 45206,     0,     0, 1 },  /* grozny.ru */
  {  3611,     0,     0, 1 },  /* int.ru */
  { 45213,     0,     0, 1 },  /* kalmykia.ru */
  { 45222,     0,     0, 1 },  /* kustanai.ru */
  { 45231,     0,     0, 1 },  /* marine.ru */
  {  4157,     0,     0, 1 },  /* mil.ru */
  { 45238,     0,     0, 1 },  /* mordovia.ru */
  {  7270,     0,     0, 1 },  /* msk.ru */
  { 45247,  3731,     4, 1 },  /* myjino.ru */
  { 45254,     0,     0, 1 },  /* mytis.ru */
  { 45260,     0,     0, 1 },  /* nalchik.ru */
  {  5710,     0,     0, 1 },  /* net.ru */
  { 45268,     0,     0, 1 },  /* nov.ru */
  {  6026,     0,     0, 1 },  /* org.ru */
  {   469,     0,     0, 1 },  /* pp.ru */
  { 45272,     0,     0, 1 },  /* pyatigorsk.ru */
  { 45283,     0,     0, 1 },  /* ras.ru */
  { 11450,     0,     0, 1 },  /* spb.ru */
  { 45128,     0,     0, 1 },  /* test.ru */
  { 45287,     0,     0, 1 },  /* vladikavkaz.ru */
  { 45299,     0,     0, 1 },  /* vladimir.ru */
  {  4034,  4048,     1, 0 },  /* hosting.myjino.ru */
  { 45308,  4048,     1, 0 },  /* landing.myjino.ru */
  { 45316,  4048,     1, 0 },  /* spectrum.myjino.ru */
  { 45325,  4048,     1, 0 },  /* vps.myjino.ru */
  {  1910,     0,     0, 1 },  /* com.sh */
  {  3665,     0,     0, 1 },  /* gov.sh */
  { 45409,     0,     0, 1 },  /* hashbang.sh */
  {  4157,     0,     0, 1 },  /* mil.sh */
  {  5710,     0,     0, 1 },  /* net.sh */
  {  5839,     0,     0, 1 },  /* now.sh */
  {  6026,     0,     0, 1 },  /* org.sh */
  { 45418,  4048,     1, 0 },  /* platform.sh */
  { 17478,     0,     0, 1 },  /* wedeploy.sh */
  { 11692,     0,     0, 1 },  /* barsy.site */
  { 45427,     0,     0, 1 },  /* byen.site */
  { 31988,     0,     0, 1 },  /* cyon.site */
  { 45432,  4048,     1, 0 },  /* platformsh.site */
  { 17794,     0,     0, 1 },  /* av.tr */
  { 15220,     0,     0, 1 },  /* bbs.tr */
  { 45878,     0,     0, 1 },  /* bel.tr */
  {   986,     0,     0, 1 },  /* biz.tr */
  {  1910,  4032,     1, 1 },  /* com.tr */
  { 11492,     0,     0, 1 },  /* dr.tr */
  {  2622,     0,     0, 1 },  /* edu.tr */
  {  8364,     0,     0, 1 },  /* gen.tr */
  {  3665,     0,     0, 1 },  /* gov.tr */
  {  3149,     0,     0, 1 },  /* info.tr */
  { 16571,     0,     0, 1 },  /* k12.tr */
  { 45882,     0,     0, 1 },  /* kep.tr */
  {  4157,     0,     0, 1 },  /* mil.tr */
  {  5672,     0,     0, 1 },  /* name.tr */
  {  4198,  4046,     1, 1 },  /* nc.tr */
  {  5710,     0,     0, 1 },  /* net.tr */
  {  6026,     0,     0, 1 },  /* org.tr */
  { 16567,     0,     0, 1 },  /* pol.tr */
  {   279,     0,     0, 1 },  /* tel.tr */
  {  2545,     0,     0, 1 },  /* tv.tr */
  { 12075,     0,     0, 1 },  /* web.tr */
  { 10791,     0,     0, 1 },  /* blogspot.tw */
  {  1846,     0,     0, 1 },  /* club.tw */
  {  1910,  8118,     1, 1 },  /* com.tw */
  {   985,     0,     0, 1 },  /* ebiz.tw */
  {  2622,     0,     0, 1 },  /* edu.tw */
  {  3371,     0,     0, 1 },  /* game.tw */
  {  3665,     0,     0, 1 },  /* gov.tw */
  { 16852,     0,     0, 1 },  /* idv.tw */
  {  4157,     0,     0, 1 },  /* mil.tw */
  {  5710,     0,     0, 1 },  /* net.tw */
  { 12575,     0,     0, 1 },  /* nym.tw */
  {  6026,     0,     0, 1 },  /* org.tw */
  { 11655,     0,     0, 1 },  /* url.tw */
  { 45920,     0,     0, 1 },  /* xn--czrw28b.tw */
  { 16934,     0,     0, 1 },  /* xn--uc0atv.tw */
  { 45932,     0,     0, 1 },  /* xn--zf0ao64a.tw */
  {    62,     0,     0, 1 },  /* ac.uk */
  { 11692,     0,     0, 1 },  /* barsy.uk */
  {   113,  8223,     7, 1 },  /* co.uk */
  {  3665,  8230,     2, 1 },  /* gov.uk */
  {  5070,     0,     0, 1 },  /* ltd.uk */
  {  1690,     0,     0, 1 },  /* me.uk */
  {  5710,     0,     0, 1 },  /* net.uk */
  { 46317,     0,     0, 1 },  /* nhs.uk */
  {  6026,  8232,     3, 1 },  /* org.uk */
  {  4825,     0,     0, 1 },  /* plc.uk */
  { 46321,     0,     0, 1 },  /* police.uk */
  {  1140,  4048,     1, 0 },  /* sch.uk */
  {  4851,  8235,     3, 1 },  /* ak.us */
  {   290,  8235,     3, 1 },  /* al.us */
  {   494,  8235,     3, 1 },  /* ar.us */
  {   537,  8235,     3, 1 },  /* as.us */
  {   671,  8235,     3, 1 },  /* az.us */
  {   221,  8235,     3, 1 },  /* ca.us */
  { 11510,     0,     0, 1 },  /* cloudns.us */
  {   113,  8235,     3, 1 },  /* co.us */
  {  2001,  8235,     3, 1 },  /* ct.us */
  { 13660,  8235,     3, 1 },  /* dc.us */
  {  2273,  8235,     3, 1 },  /* de.us */
  {  5787,     0,     0, 1 },  /* dni.us */
  { 17299,     0,     0, 1 },  /* drud.us */
  { 11439,     0,     0, 1 },  /* fed.us */
  {   210,  8235,     3, 1 },  /* fl.us */
  { 43512,     0,     0, 1 },  /* freeddns.us */
  {  3334,  8235,     3, 1 },  /* ga.us */
  { 46357,     0,     0, 1 },  /* golffan.us */
  {  3747,  8235,     3, 1 },  /* gu.us */
  {   512,  8238,     2, 1 },  /* hi.us */
  {   547,  8235,     3, 1 },  /* ia.us */
  {   437,  8235,     3, 1 },  /* id.us */
  {  2651,  8235,     3, 1 },  /* il.us */
  {   898,  8235,     3, 1 },  /* in.us */
  { 46365,     0,     0, 1 },  /* is-by.us */
  {  8285,     0,     0, 1 },  /* isa.us */
  { 34256,     0,     0, 1 },  /* kids.us */
  {  6791,  8235,     3, 1 },  /* ks.us */
  {  4670,  8235,     3, 1 },  /* ky.us */
  {  2170,  8235,     3, 1 },  /* la.us */
  { 46371,     0,     0, 1 },  /* land-4-sale.us */
  {  5118,  3866,     3, 1 },  /* ma.us */
  {  5287,  8235,     3, 1 },  /* md.us */
  {  1690,  8235,     3, 1 },  /* me.us */
  {  5364,  8243,    11, 1 },  /* mi.us */
  {  5412,  8235,     3, 1 },  /* mn.us */
  {  3579,  8235,     3, 1 },  /* mo.us */
  {  1060,  8235,     3, 1 },  /* ms.us */
  {  5566,  8235,     3, 1 },  /* mt.us */
  {  4198,  8235,     3, 1 },  /* nc.us */
  {   727,  8238,     2, 1 },  /* nd.us */
  {  1198,  8235,     3, 1 },  /* ne.us */
  { 13820,  8235,     3, 1 },  /* nh.us */
  {  4432,  8235,     3, 1 },  /* nj.us */
  { 12825,  8235,     3, 1 },  /* nm.us */
  { 32079,     0,     0, 1 },  /* noip.us */
  { 46383,     0,     0, 1 },  /* nsn.us */
  { 13836,  8235,     3, 1 },  /* nv.us */
  {   206,  8235,     3, 1 },  /* ny.us */
  {  6743,  8235,     3, 1 },  /* oh.us */
  {  1127,  8235,     3, 1 },  /* ok.us */
  {   137,  8235,     3, 1 },  /* or.us */
  {   522,  8235,     3, 1 },  /* pa.us */
  { 46387,     0,     0, 1 },  /* pointto.us */
  {  6351,  8235,     3, 1 },  /* pr.us */
  {  2978,  8235,     3, 1 },  /* ri.us */
  {  2155,  8235,     3, 1 },  /* sc.us */
  {  5348,  8238,     2, 1 },  /* sd.us */
  { 43868,     0,     0, 1 },  /* stuff-4-sale.us */
  {  5570,  8235,     3, 1 },  /* tn.us */
  { 13900,  8235,     3, 1 },  /* tx.us */
  {  3817,  8235,     3, 1 },  /* ut.us */
  {   834,  8235,     3, 1 },  /* va.us */
  {  8231,  8235,     3, 1 },  /* vi.us */
  { 13924,  8235,     3, 1 },  /* vt.us */
  {  5916,  8235,     3, 1 },  /* wa.us */
  {  4590,  8235,     3, 1 },  /* wi.us */
  { 13948,  8254,     1, 1 },  /* wv.us */
  { 13956,  8235,     3, 1 },  /* wy.us */
  {  1573,     0,     0, 1 },  /* cc.ma.us */
  { 16571,  8240,     3, 1 },  /* k12.ma.us */
  { 16579,     0,     0, 1 },  /* lib.ma.us */
  {  1910,  4032,     1, 1 },  /* com.uy */
  {  2622,     0,     0, 1 },  /* edu.uy */
  { 46437,     0,     0, 1 },  /* gub.uy */
  {  4157,     0,     0, 1 },  /* mil.uy */
  {  5710,     0,     0, 1 },  /* net.uy */
  {  5943,     0,     0, 1 },  /* nom.uy */
  {  6026,     0,     0, 1 },  /* org.uy */
  { 14308,  4048,     1, 0 },  /* advisor.ws */
  { 46445,     0,     0, 1 },  /* cloud66.ws */
  {  1910,     0,     0, 1 },  /* com.ws */
  { 11733,     0,     0, 1 },  /* dyndns.ws */
  {  2622,     0,     0, 1 },  /* edu.ws */
  {  3665,     0,     0, 1 },  /* gov.ws */
  { 46453,     0,     0, 1 },  /* mypets.ws */
  {  5710,     0,     0, 1 },  /* net.ws */
  {  6026,     0,     0, 1 },  /* org.ws */
  {    62,     0,     0, 1 },  /* ac.za */
  { 46602,     0,     0, 1 },  /* agric.za */
  {  5066,     0,     0, 1 },  /* alt.za */
  {   113,  4032,     1, 1 },  /* co.za */
  {  2622,     0,     0, 1 },  /* edu.za */
  {  3665,     0,     0, 1 },  /* gov.za */
  { 46608,     0,     0, 1 },  /* grondar.za */
  {  4805,     0,     0, 1 },  /* law.za */
  {  4157,     0,     0, 1 },  /* mil.za */
  {  5710,     0,     0, 1 },  /* net.za */
  {   977,     0,     0, 1 },  /* ngo.za */
  {  7765,     0,     0, 1 },  /* nis.za */
  {  5943,     0,     0, 1 },  /* nom.za */
  {  6026,     0,     0, 1 },  /* org.za */
  {  7001,     0,     0, 1 },  /* school.za */
  {  7890,     0,     0, 1 },  /* tm.za */
  { 12075,     0,     0, 1 },  /* web.za */
  { 11528,     0,     0, 1 },  /* lima.zone */
  { 46616,  4048,     1, 0 },  /* triton.zone */
};

static const REGISTRY_U16 kLeafNodeTable[] = {
 1910,  /* com.ac */
 2622,  /* edu.ac */
 3665,  /* gov.ac */
 4157,  /* mil.ac */
 5710,  /* net.ac */
 6026,  /* org.ac */
10782,  /* official.academy */
 5943,  /* nom.ad */
   62,  /* ac.ae */
10791,  /* blogspot.ae */
  113,  /* co.ae */
 3665,  /* gov.ae */
 4157,  /* mil.ae */
 5710,  /* net.ae */
 5943,  /* nom.ae */
 6026,  /* org.ae */
 1140,  /* sch.ae */
10800,  /* accident-investigation.aero */
10823,  /* accident-prevention.aero */
10843,  /* aerobatic.aero */
 1842,  /* aeroclub.aero */
10853,  /* aerodrome.aero */
10863,  /* agents.aero */
10870,  /* air-surveillance.aero */
10887,  /* air-traffic-control.aero */
10907,  /* aircraft.aero */
10916,  /* airline.aero */
10924,  /* airport.aero */
10932,  /* airtraffic.aero */
10943,  /* ambulance.aero */
10953,  /* amusement.aero */
10973,  /* association.aero */
  622,  /* author.aero */
10985,  /* ballooning.aero */
 1210,  /* broker.aero */
10996,  /* caa.aero */
11000,  /* cargo.aero */
 1521,  /* catering.aero */
11006,  /* certification.aero */
11020,  /* championship.aero */
11033,  /* charter.aero */
11041,  /* civilaviation.aero */
 1846,  /* club.aero */
11055,  /* conference.aero */
11066,  /* consultant.aero */
 1985,  /* consulting.aero */
10899,  /* control.aero */
11077,  /* council.aero */
11085,  /* crew.aero */
 2370,  /* design.aero */
11090,  /* dgca.aero */
11095,  /* educator.aero */
11104,  /* emergency.aero */
11114,  /* engine.aero */
 2674,  /* engineer.aero */
11121,  /* entertainment.aero */
 2723,  /* equipment.aero */
 2835,  /* exchange.aero */
  369,  /* express.aero */
11135,  /* federation.aero */
11146,  /* flight.aero */
11153,  /* freight.aero */
11161,  /* fuel.aero */
11170,  /* gliding.aero */
11178,  /* government.aero */
11189,  /* groundhandling.aero */
 3732,  /* group.aero */
11166,  /* hanggliding.aero */
11204,  /* homebuilt.aero */
 4246,  /* insurance.aero */
11214,  /* journal.aero */
11222,  /* journalist.aero */
11233,  /* leasing.aero */
 4514,  /* logistics.aero */
11241,  /* magazine.aero */
11250,  /* maintenance.aero */
 5294,  /* media.aero */
11262,  /* microlight.aero */
11273,  /* modelling.aero */
11283,  /* navigation.aero */
11294,  /* parachuting.aero */
11306,  /* paragliding.aero */
10963,  /* passenger-association.aero */
11318,  /* pilot.aero */
  371,  /* press.aero */
11324,  /* production.aero */
11335,  /* recreation.aero */
11346,  /* repbody.aero */
 6244,  /* res.aero */
 1377,  /* research.aero */
11354,  /* rotorcraft.aero */
 6860,  /* safety.aero */
11365,  /* scientist.aero */
 7106,  /* services.aero */
 4083,  /* show.aero */
11375,  /* skydiving.aero */
 7330,  /* software.aero */
11390,  /* student.aero */
11398,  /* trader.aero */
 7981,  /* trading.aero */
11418,  /* trainer.aero */
 2115,  /* union.aero */
11426,  /* workinggroup.aero */
 8615,  /* works.aero */
 1910,  /* com.af */
 2622,  /* edu.af */
 3665,  /* gov.af */
 5710,  /* net.af */
 5943,  /* nom.af */
 6026,  /* org.af */
  113,  /* co.ag */
 1910,  /* com.ag */
 5710,  /* net.ag */
 5943,  /* nom.ag */
 6026,  /* org.ag */
 1910,  /* com.ai */
 5710,  /* net.ai */
 5943,  /* nom.ai */
 5896,  /* off.ai */
 6026,  /* org.ai */
10791,  /* blogspot.al */
 1910,  /* com.al */
 2622,  /* edu.al */
 3665,  /* gov.al */
 4157,  /* mil.al */
 5710,  /* net.al */
 5943,  /* nom.al */
 6026,  /* org.al */
10791,  /* blogspot.am */
  113,  /* co.ao */
 1856,  /* ed.ao */
11443,  /* gv.ao */
 2095,  /* it.ao */
 1037,  /* og.ao */
11451,  /* pb.ao */
11454,  /* hasura.app */
11482,  /* e164.arpa */
11487,  /* in-addr.arpa */
11495,  /* ip6.arpa */
 4329,  /* iris.arpa */
11502,  /* uri.arpa */
11506,  /* urn.arpa */
 3665,  /* gov.as */
11510,  /* cloudns.asia */
11599,  /* *.ex.futurecms.at */
 2000,  /* act.edu.au */
11618,  /* nsw.edu.au */
   97,  /* nt.edu.au */
11630,  /* qld.edu.au */
 1487,  /* sa.edu.au */
  536,  /* tas.edu.au */
11635,  /* vic.edu.au */
 5916,  /* wa.edu.au */
11630,  /* qld.gov.au */
 1487,  /* sa.gov.au */
  536,  /* tas.gov.au */
11635,  /* vic.gov.au */
 5916,  /* wa.gov.au */
 1910,  /* com.aw */
  986,  /* biz.az */
 1910,  /* com.az */
 2622,  /* edu.az */
 3665,  /* gov.az */
 3149,  /* info.az */
 3611,  /* int.az */
 4157,  /* mil.az */
 5672,  /* name.az */
 5710,  /* net.az */
 6026,  /* org.az */
  469,  /* pp.az */
 6376,  /* pro.az */
10791,  /* blogspot.ba */
 1910,  /* com.ba */
 2622,  /* edu.ba */
 3665,  /* gov.ba */
 4157,  /* mil.ba */
 5710,  /* net.ba */
 6026,  /* org.ba */
  986,  /* biz.bb */
  113,  /* co.bb */
 1910,  /* com.bb */
 2622,  /* edu.bb */
 3665,  /* gov.bb */
 3149,  /* info.bb */
 5710,  /* net.bb */
 6026,  /* org.bb */
 7493,  /* store.bb */
 2545,  /* tv.bb */
11662,  /* 0.bg */
11667,  /* 1.bg */
11670,  /* 2.bg */
11673,  /* 3.bg */
11485,  /* 4.bg */
11678,  /* 5.bg */
11497,  /* 6.bg */
11683,  /* 7.bg */
11688,  /* 8.bg */
11690,  /* 9.bg */
    2,  /* a.bg */
   18,  /* b.bg */
11692,  /* barsy.bg */
10791,  /* blogspot.bg */
   36,  /* c.bg */
  142,  /* d.bg */
   32,  /* e.bg */
  192,  /* f.bg */
  162,  /* g.bg */
   14,  /* h.bg */
   58,  /* i.bg */
  991,  /* j.bg */
  734,  /* k.bg */
  211,  /* l.bg */
  354,  /* m.bg */
  235,  /* n.bg */
   49,  /* o.bg */
    7,  /* p.bg */
  481,  /* q.bg */
  138,  /* r.bg */
  110,  /* s.bg */
   25,  /* t.bg */
  585,  /* u.bg */
 1285,  /* v.bg */
  650,  /* w.bg */
  398,  /* x.bg */
   71,  /* y.bg */
  326,  /* z.bg */
 1910,  /* com.bh */
 2622,  /* edu.bh */
 3665,  /* gov.bh */
 5710,  /* net.bh */
 6026,  /* org.bh */
  113,  /* co.bi */
 1910,  /* com.bi */
 2622,  /* edu.bi */
  137,  /* or.bi */
 6026,  /* org.bi */
11510,  /* cloudns.biz */
11725,  /* dscloud.biz */
11733,  /* dyndns.biz */
11740,  /* for-better.biz */
11756,  /* for-more.biz */
11765,  /* for-some.biz */
11774,  /* for-the.biz */
11782,  /* mmafan.biz */
11789,  /* myftp.biz */
11795,  /* no-ip.biz */
11801,  /* selfip.biz */
11808,  /* webhop.biz */
11821,  /* asso.bj */
11826,  /* barreau.bj */
10791,  /* blogspot.bj */
11834,  /* gouv.bj */
11839,  /* academia.bo */
11848,  /* agro.bo */
  531,  /* arte.bo */
 1035,  /* blog.bo */
11853,  /* bolivia.bo */
11861,  /* ciencia.bo */
 1910,  /* com.bo */
11869,  /* cooperativa.bo */
11881,  /* democracia.bo */
11892,  /* deporte.bo */
11900,  /* ecologia.bo */
11909,  /* economia.bo */
 2622,  /* edu.bo */
11918,  /* empresa.bo */
11461,  /* gob.bo */
11926,  /* indigena.bo */
11935,  /* industria.bo */
 3149,  /* info.bo */
 3611,  /* int.bo */
11945,  /* medicina.bo */
 4157,  /* mil.bo */
11954,  /* movimiento.bo */
11465,  /* musica.bo */
11965,  /* natural.bo */
 5710,  /* net.bo */
11973,  /* nombre.bo */
11980,  /* noticias.bo */
 6026,  /* org.bo */
11989,  /* patria.bo */
11996,  /* plurinacional.bo */
12010,  /* politica.bo */
12019,  /* profesional.bo */
12031,  /* pueblo.bo */
 8300,  /* revista.bo */
12038,  /* salud.bo */
12044,  /* tecnologia.bo */
12055,  /* tksat.bo */
12061,  /* transporte.bo */
 2545,  /* tv.bo */
12075,  /* web.bo */
 8550,  /* wiki.bo */
   62,  /* ac.gov.br */
  290,  /* al.gov.br */
  358,  /* am.gov.br */
 1665,  /* ap.gov.br */
  308,  /* ba.gov.br */
  273,  /* ce.gov.br */
12288,  /* df.gov.br */
  558,  /* es.gov.br */
  257,  /* go.gov.br */
 5118,  /* ma.gov.br */
 4635,  /* mg.gov.br */
 1060,  /* ms.gov.br */
 5566,  /* mt.gov.br */
  522,  /* pa.gov.br */
11451,  /* pb.gov.br */
 3718,  /* pe.gov.br */
12566,  /* pi.gov.br */
 6351,  /* pr.gov.br */
12572,  /* rj.gov.br */
  821,  /* rn.gov.br */
  166,  /* ro.gov.br */
11716,  /* rr.gov.br */
 1267,  /* rs.gov.br */
 2155,  /* sc.gov.br */
 1492,  /* se.gov.br */
12214,  /* sp.gov.br */
  631,  /* to.gov.br */
 1910,  /* com.bs */
 2622,  /* edu.bs */
 3665,  /* gov.bs */
 5710,  /* net.bs */
 6026,  /* org.bs */
 6832,  /* we.bs */
  113,  /* co.bw */
 6026,  /* org.bw */
 1910,  /* com.bz */
 2622,  /* edu.bz */
 3665,  /* gov.bz */
 5710,  /* net.bz */
12575,  /* nym.bz */
 6026,  /* org.bz */
 6272,  /* za.bz */
11510,  /* cloudns.cc */
12596,  /* fantasyleague.cc */
12610,  /* ftpaccess.cc */
12620,  /* game-server.cc */
 6199,  /* myphotos.cc */
12632,  /* scrapping.cc */
12642,  /* twmail.cc */
11518,  /* 12hp.ch */
11523,  /* 2ix.ch */
11527,  /* 4lima.ch */
10791,  /* blogspot.ch */
12650,  /* dnsking.ch */
12658,  /* gotdns.ch */
11571,  /* lima-city.ch */
12665,  /* linkyard-cloud.ch */
12680,  /* square7.ch */
   62,  /* ac.ci */
11821,  /* asso.ci */
  113,  /* co.ci */
 1910,  /* com.ci */
 1856,  /* ed.ci */
 2622,  /* edu.ci */
  257,  /* go.ci */
11834,  /* gouv.ci */
 3611,  /* int.ci */
 5287,  /* md.ci */
 5710,  /* net.ci */
  137,  /* or.ci */
 6026,  /* org.ci */
12688,  /* presse.ci */
12695,  /* xn--aroport-bya.ci */
12711,  /* !www.ck */
11599,  /* *.ck */
10791,  /* blogspot.cl */
  113,  /* co.cl */
11461,  /* gob.cl */
 3665,  /* gov.cl */
 4157,  /* mil.cl */
 5943,  /* nom.cl */
11692,  /* barsy.club */
11510,  /* cloudns.club */
  113,  /* co.cm */
 1910,  /* com.cm */
 3665,  /* gov.cm */
 5710,  /* net.cm */
11672,  /* s3.cn-north-1.amazonaws.com.cn */
12859,  /* cn-north-1.eb.amazonaws.com.cn */
15940,  /* alpha.bounty-full.com */
15946,  /* beta.bounty-full.com */
15478,  /* ap-northeast-1.elasticbeanstalk.com */
15496,  /* ap-northeast-2.elasticbeanstalk.com */
15951,  /* ap-northeast-3.elasticbeanstalk.com */
15514,  /* ap-south-1.elasticbeanstalk.com */
15528,  /* ap-southeast-1.elasticbeanstalk.com */
15546,  /* ap-southeast-2.elasticbeanstalk.com */
15564,  /* ca-central-1.elasticbeanstalk.com */
15590,  /* eu-central-1.elasticbeanstalk.com */
15606,  /* eu-west-1.elasticbeanstalk.com */
15619,  /* eu-west-2.elasticbeanstalk.com */
15632,  /* eu-west-3.elasticbeanstalk.com */
15681,  /* sa-east-1.elasticbeanstalk.com */
15878,  /* us-east-1.elasticbeanstalk.com */
15694,  /* us-east-2.elasticbeanstalk.com */
15664,  /* us-gov-west-1.elasticbeanstalk.com */
15724,  /* us-west-1.elasticbeanstalk.com */
15737,  /* us-west-2.elasticbeanstalk.com */
11664,  /* eu-1.evennode.com */
15966,  /* eu-2.evennode.com */
15971,  /* eu-3.evennode.com */
15976,  /* eu-4.evennode.com */
15981,  /* us-1.evennode.com */
15986,  /* us-2.evennode.com */
15991,  /* us-3.evennode.com */
15996,  /* us-4.evennode.com */
16007,  /* apps.fbsbx.com */
  468,  /* app.lmpm.com */
 2796,  /* eu.meteorapp.com */
16016,  /* xen.prgmr.com */
11669,  /* u2.xnbay.com */
16020,  /* u2-local.xnbay.com */
14892,  /* ravendb.community */
 2273,  /* de.cool */
   62,  /* ac.cr */
  113,  /* co.cr */
 1856,  /* ed.cr */
 2993,  /* fi.cr */
  257,  /* go.cr */
  137,  /* or.cr */
 1487,  /* sa.cr */
 1910,  /* com.cu */
 2622,  /* edu.cu */
 3665,  /* gov.cu */
 5769,  /* inf.cu */
 5710,  /* net.cu */
 6026,  /* org.cu */
 1910,  /* com.cw */
 2622,  /* edu.cw */
 5710,  /* net.cw */
 6026,  /* org.cw */
 7782,  /* ath.cx */
 3665,  /* gov.cx */
 3149,  /* info.cx */
 1836,  /* cloud.metacentrum.cz */
16071,  /* custom.metacentrum.cz */
16078,  /* flt.cloud.muni.cz */
 7415,  /* usr.cloud.muni.cz */
16532,  /* dyn.cosidns.de */
16532,  /* dyn.ddnss.de */
11733,  /* dyndns.ddnss.de */
16536,  /* customer.speedpartner.de */
16545,  /* fastpanel.direct */
  986,  /* biz.dk */
10791,  /* blogspot.dk */
  113,  /* co.dk */
12882,  /* firm.dk */
16555,  /* reg.dk */
 7493,  /* store.dk */
  527,  /* art.do */
 1910,  /* com.do */
 2622,  /* edu.do */
11461,  /* gob.do */
 3665,  /* gov.do */
 4157,  /* mil.do */
 5710,  /* net.do */
 6026,  /* org.do */
16559,  /* sld.do */
12075,  /* web.do */
  527,  /* art.dz */
11821,  /* asso.dz */
 1910,  /* com.dz */
 2622,  /* edu.dz */
 3665,  /* gov.dz */
 5710,  /* net.dz */
 6026,  /* org.dz */
16567,  /* pol.dz */
 1910,  /* com.ec */
 2622,  /* edu.ec */
 4193,  /* fin.ec */
11461,  /* gob.ec */
 3665,  /* gov.ec */
 3149,  /* info.ec */
16571,  /* k12.ec */
 1855,  /* med.ec */
 4157,  /* mil.ec */
 5710,  /* net.ec */
 6026,  /* org.ec */
 6376,  /* pro.ec */
  986,  /* biz.et */
 1910,  /* com.et */
 2622,  /* edu.et */
 3665,  /* gov.et */
 3149,  /* info.et */
 5672,  /* name.et */
 5710,  /* net.et */
 6026,  /* org.et */
16513,  /* user.party.eus */
16624,  /* ybo.faith */
12569,  /* storj.farm */
16632,  /* aland.fi */
10791,  /* blogspot.fi */
 3597,  /* dy.fi */
 8551,  /* iki.fi */
 6306,  /* ptplus.fit */
16648,  /* aeroport.fr */
16657,  /* assedic.fr */
11821,  /* asso.fr */
 1514,  /* avocat.fr */
16665,  /* avoues.fr */
10791,  /* blogspot.fr */
 3761,  /* cci.fr */
16672,  /* chambagri.fr */
16682,  /* chirurgiens-dentistes.fr */
16704,  /* chirurgiens-dentistes-en-france.fr */
 1910,  /* com.fr */
16736,  /* experts-comptables.fr */
16755,  /* fbx-os.fr */
16762,  /* fbxos.fr */
13594,  /* freebox-os.fr */
13605,  /* freeboxos.fr */
 2844,  /* geometre-expert.fr */
11834,  /* gouv.fr */
16768,  /* greta.fr */
16774,  /* huissier-justice.fr */
16791,  /* medecin.fr */
 5943,  /* nom.fr */
16799,  /* notaires.fr */
12072,  /* on-web.fr */
16808,  /* pharmacien.fr */
 6662,  /* port.fr */
16819,  /* prd.fr */
12688,  /* presse.fr */
 7890,  /* tm.fr */
16823,  /* veterinaire.fr */
16835,  /* cnpy.gdn */
 1910,  /* com.ge */
 2622,  /* edu.ge */
 3665,  /* gov.ge */
 4157,  /* mil.ge */
 5710,  /* net.ge */
 5943,  /* nom.ge */
 6026,  /* org.ge */
16840,  /* pvt.ge */
  113,  /* co.gg */
16844,  /* cya.gg */
 5710,  /* net.gg */
 6026,  /* org.gg */
 1910,  /* com.gh */
 2622,  /* edu.gh */
 3665,  /* gov.gh */
 4157,  /* mil.gh */
 6026,  /* org.gh */
 1910,  /* com.gi */
 2622,  /* edu.gi */
 3665,  /* gov.gi */
 5070,  /* ltd.gi */
16848,  /* mod.gi */
 6026,  /* org.gi */
  113,  /* co.gl */
 1910,  /* com.gl */
 2622,  /* edu.gl */
 5710,  /* net.gl */
 5943,  /* nom.gl */
 6026,  /* org.gl */
   62,  /* ac.gn */
 1910,  /* com.gn */
 2622,  /* edu.gn */
 3665,  /* gov.gn */
 5710,  /* net.gn */
 6026,  /* org.gn */
 1836,  /* cloud.goog */
11821,  /* asso.gp */
 1910,  /* com.gp */
 2622,  /* edu.gp */
 5415,  /* mobi.gp */
 5710,  /* net.gp */
 6026,  /* org.gp */
10791,  /* blogspot.gr */
 1910,  /* com.gr */
 2622,  /* edu.gr */
 3665,  /* gov.gr */
 5710,  /* net.gr */
12575,  /* nym.gr */
 6026,  /* org.gr */
 1910,  /* com.gt */
 2622,  /* edu.gt */
11461,  /* gob.gt */
12273,  /* ind.gt */
 4157,  /* mil.gt */
 5710,  /* net.gt */
 5943,  /* nom.gt */
 6026,  /* org.gt */
 1910,  /* com.gu */
 2622,  /* edu.gu */
 3665,  /* gov.gu */
  356,  /* guam.gu */
 3149,  /* info.gu */
 5710,  /* net.gu */
 6026,  /* org.gu */
12075,  /* web.gu */
  113,  /* co.gy */
 1910,  /* com.gy */
 2622,  /* edu.gy */
 3665,  /* gov.gy */
 5710,  /* net.gy */
12575,  /* nym.gy */
 6026,  /* org.gy */
10791,  /* blogspot.hk */
 1910,  /* com.hk */
 2622,  /* edu.hk */
 3665,  /* gov.hk */
16852,  /* idv.hk */
 4197,  /* inc.hk */
 5070,  /* ltd.hk */
 5710,  /* net.hk */
 6026,  /* org.hk */
 8877,  /* xn--55qx5d.hk */
16856,  /* xn--ciqpn.hk */
16866,  /* xn--gmq050i.hk */
16878,  /* xn--gmqw5a.hk */
 9523,  /* xn--io0a7i.hk */
16889,  /* xn--lcvr32d.hk */
16901,  /* xn--mk0axi.hk */
10100,  /* xn--mxtq1m.hk */
12836,  /* xn--od0alg.hk */
16912,  /* xn--od0aq3b.hk */
16924,  /* xn--tn0ag.hk */
16934,  /* xn--uc0atv.hk */
16945,  /* xn--uc0ay4a.hk */
16957,  /* xn--wcvs22d.hk */
16969,  /* xn--zf0avx.hk */
 1910,  /* com.hn */
 2622,  /* edu.hn */
11461,  /* gob.hn */
 4157,  /* mil.hn */
 5710,  /* net.hn */
 5943,  /* nom.hn */
 6026,  /* org.hn */
16980,  /* cloudaccess.host */
 7258,  /* freesite.host */
16992,  /* half.host */
12948,  /* pcloud.host */
16997,  /* opencraft.hosting */
10791,  /* blogspot.hr */
 1910,  /* com.hr */
17007,  /* from.hr */
  987,  /* iz.hr */
 5672,  /* name.hr */
  148,  /* adult.ht */
  527,  /* art.ht */
11821,  /* asso.ht */
 1910,  /* com.ht */
 2044,  /* coop.ht */
 2622,  /* edu.ht */
12882,  /* firm.ht */
11834,  /* gouv.ht */
 3149,  /* info.ht */
 1855,  /* med.ht */
 5710,  /* net.ht */
 6026,  /* org.ht */
17012,  /* perso.ht */
16567,  /* pol.ht */
 6376,  /* pro.ht */
17018,  /* rel.ht */
 7204,  /* shop.ht */
11659,  /* 2000.hu */
17022,  /* agrar.hu */
10791,  /* blogspot.hu */
17028,  /* bolt.hu */
 1507,  /* casino.hu */
 1762,  /* city.hu */
  113,  /* co.hu */
17033,  /* erotica.hu */
17041,  /* erotika.hu */
 3015,  /* film.hu */
 3205,  /* forum.hu */
 3384,  /* games.hu */
 7728,  /* hotel.hu */
 3149,  /* info.hu */
17049,  /* ingatlan.hu */
17058,  /* jogasz.hu */
17065,  /* konyvelo.hu */
17074,  /* lakas.hu */
 5294,  /* media.hu */
 5753,  /* news.hu */
 6026,  /* org.hu */
11594,  /* priv.hu */
17080,  /* reklam.hu */
 7127,  /* sex.hu */
 7204,  /* shop.hu */
 7387,  /* sport.hu */
 4870,  /* suli.hu */
11601,  /* szex.hu */
 7890,  /* tm.hu */
17087,  /* tozsde.hu */
17094,  /* utazas.hu */
 8241,  /* video.hu */
10791,  /* blogspot.ie */
 3665,  /* gov.ie */
12575,  /* nym.ie */
 5070,  /* ltd.co.im */
 4825,  /* plc.co.im */
   62,  /* ac.in */
11692,  /* barsy.in */
10791,  /* blogspot.in */
11510,  /* cloudns.in */
  113,  /* co.in */
 2622,  /* edu.in */
12882,  /* firm.in */
 8364,  /* gen.in */
 3665,  /* gov.in */
12273,  /* ind.in */
 4157,  /* mil.in */
 5710,  /* net.in */
 1812,  /* nic.in */
 6026,  /* org.in */
 6244,  /* res.in */
17118,  /* barrel-of-knowledge.info */
17138,  /* barrell-of-knowledge.info */
11692,  /* barsy.info */
11510,  /* cloudns.info */
17159,  /* dvrcam.info */
17166,  /* dynamic-dns.info */
11733,  /* dyndns.info */
17178,  /* for-our.info */
 5630,  /* forumz.info */
17186,  /* groks-the.info */
17196,  /* groks-this.info */
11751,  /* here-for-more.info */
 1886,  /* ilovecollege.info */
17207,  /* knowsitall.info */
17218,  /* mayfirst.info */
11795,  /* no-ip.info */
17227,  /* nsupdate.info */
11801,  /* selfip.info */
 3147,  /* v-info.info */
11808,  /* webhop.info */
17487,  /* stage.nodeart.io */
17493,  /* devices.resinstaging.io */
17509,  /* cust.dev.thingdust.io */
   62,  /* ac.ir */
  113,  /* co.ir */
 3665,  /* gov.ir */
  437,  /* id.ir */
 5710,  /* net.ir */
 6026,  /* org.ir */
 1140,  /* sch.ir */
 9690,  /* xn--mgba3a4f16a.ir */
 9706,  /* xn--mgba3a4fra.ir */
10791,  /* blogspot.is */
 1910,  /* com.is */
17514,  /* cupcake.is */
 2622,  /* edu.is */
 3665,  /* gov.is */
 3611,  /* int.is */
 5710,  /* net.is */
 6026,  /* org.is */
17522,  /* 16-b.it */
17527,  /* 32-b.it */
17532,  /* 64-b.it */
 1176,  /* abr.it */
17537,  /* abruzzo.it */
  226,  /* ag.it */
17545,  /* agrigento.it */
  290,  /* al.it */
17555,  /* alessandria.it */
17575,  /* alto-adige.it */
17594,  /* altoadige.it */
  234,  /* an.it */
17609,  /* ancona.it */
17616,  /* andria-barletta-trani.it */
17638,  /* andria-trani-barletta.it */
17660,  /* andriabarlettatrani.it */
17680,  /* andriatranibarletta.it */
  448,  /* ao.it */
17704,  /* aosta.it */
17710,  /* aosta-valley.it */
17723,  /* aostavalley.it */
17741,  /* aoste.it */
 1665,  /* ap.it */
  480,  /* aq.it */
17748,  /* aquila.it */
  494,  /* ar.it */
17755,  /* arezzo.it */
17762,  /* ascoli-piceno.it */
17776,  /* ascolipiceno.it */
17789,  /* asti.it */
  562,  /* at.it */
17794,  /* av.it */
17797,  /* avellino.it */
  308,  /* ba.it */
17806,  /* balsan.it */
17813,  /* balsan-sudtirol.it */
17829,  /* balsan-suedtirol.it */
17848,  /* bari.it */
17853,  /* barletta-trani-andria.it */
17875,  /* barlettatraniandria.it */
 1082,  /* bas.it */
17895,  /* basilicata.it */
17906,  /* belluno.it */
17914,  /* benevento.it */
17924,  /* bergamo.it */
  932,  /* bg.it */
   57,  /* bi.it */
17932,  /* biella.it */
17941,  /* bl.it */
10791,  /* blogspot.it */
 1068,  /* bn.it */
 1087,  /* bo.it */
17944,  /* bologna.it */
17952,  /* bolzano.it */
17960,  /* bolzano-altoadige.it */
17978,  /* bozen.it */
17984,  /* bozen-sudtirol.it */
17999,  /* bozen-suedtirol.it */
 1177,  /* br.it */
18015,  /* brescia.it */
18023,  /* brindisi.it */
 1235,  /* bs.it */
  829,  /* bt.it */
18032,  /* bulsan.it */
18039,  /* bulsan-sudtirol.it */
18055,  /* bulsan-suedtirol.it */
 1290,  /* bz.it */
  221,  /* ca.it */
18072,  /* cagliari.it */
 1314,  /* cal.it */
18087,  /* calabria.it */
18096,  /* caltanissetta.it */
 1337,  /* cam.it */
18110,  /* campania.it */
18119,  /* campidano-medio.it */
18135,  /* campidanomedio.it */
11815,  /* campobasso.it */
18150,  /* carbonia-iglesias.it */
18168,  /* carboniaiglesias.it */
18185,  /* carrara-massa.it */
18199,  /* carraramassa.it */
18212,  /* caserta.it */
18220,  /* catania.it */
18228,  /* catanzaro.it */
 4380,  /* cb.it */
  273,  /* ce.it */
18238,  /* cesena-forli.it */
18251,  /* cesenaforli.it */
 1141,  /* ch.it */
18263,  /* chieti.it */
 1710,  /* ci.it */
 1784,  /* cl.it */
  842,  /* cn.it */
  113,  /* co.it */
18270,  /* como.it */
18275,  /* cosenza.it */
 2088,  /* cr.it */
18283,  /* cremona.it */
18291,  /* crotone.it */
  429,  /* cs.it */
 2001,  /* ct.it */
18304,  /* cuneo.it */
 2199,  /* cz.it */
18310,  /* dell-ogliastra.it */
18325,  /* dellogliastra.it */
 2622,  /* edu.it */
18339,  /* emilia-romagna.it */
18354,  /* emiliaromagna.it */
 5557,  /* emr.it */
 3400,  /* en.it */
18371,  /* enna.it */
 3826,  /* fc.it */
 1307,  /* fe.it */
18376,  /* fermo.it */
18382,  /* ferrara.it */
18390,  /* fg.it */
 2993,  /* fi.it */
18393,  /* firenze.it */
18401,  /* florence.it */
 3144,  /* fm.it */
18410,  /* foggia.it */
18417,  /* forli-cesena.it */
18430,  /* forlicesena.it */
 3227,  /* fr.it */
18442,  /* friuli-v-giulia.it */
18458,  /* friuli-ve-giulia.it */
18475,  /* friuli-vegiulia.it */
18491,  /* friuli-venezia-giulia.it */
18513,  /* friuli-veneziagiulia.it */
18534,  /* friuli-vgiulia.it */
18549,  /* friuliv-giulia.it */
18564,  /* friulive-giulia.it */
18580,  /* friulivegiulia.it */
18595,  /* friulivenezia-giulia.it */
18616,  /* friuliveneziagiulia.it */
18636,  /* friulivgiulia.it */
18650,  /* frosinone.it */
 8227,  /* fvg.it */
 1896,  /* ge.it */
18660,  /* genoa.it */
18666,  /* genova.it */
  257,  /* go.it */
18673,  /* gorizia.it */
 3665,  /* gov.it */
 3676,  /* gr.it */
18681,  /* grosseto.it */
18690,  /* iglesias-carbonia.it */
18708,  /* iglesiascarbonia.it */
 4162,  /* im.it */
18725,  /* imperia.it */
 3701,  /* is.it */
18733,  /* isernia.it */
 3107,  /* kr.it */
18741,  /* la-spezia.it */
17747,  /* laquila.it */
18751,  /* laspezia.it */
18760,  /* latina.it */
  670,  /* laz.it */
18767,  /* lazio.it */
 4417,  /* lc.it */
   40,  /* le.it */
12553,  /* lecce.it */
18778,  /* lecco.it */
 4347,  /* li.it */
18784,  /* lig.it */
18788,  /* liguria.it */
18796,  /* livorno.it */
 3357,  /* lo.it */
18808,  /* lodi.it */
18813,  /* lom.it */
18817,  /* lombardia.it */
18827,  /* lombardy.it */
  151,  /* lt.it */
 5079,  /* lu.it */
18836,  /* lucania.it */
18844,  /* lucca.it */
18850,  /* macerata.it */
18859,  /* mantova.it */
18869,  /* mar.it */
12809,  /* marche.it */
18873,  /* massa-carrara.it */
18887,  /* massacarrara.it */
18900,  /* matera.it */
12270,  /* mb.it */
 5274,  /* mc.it */
 1690,  /* me.it */
18907,  /* medio-campidano.it */
18923,  /* mediocampidano.it */
 7242,  /* messina.it */
 5364,  /* mi.it */
18944,  /* milan.it */
18950,  /* milano.it */
 5412,  /* mn.it */
 3579,  /* mo.it */
18957,  /* modena.it */
18964,  /* mol.it */
18968,  /* molise.it */
18975,  /* monza.it */
18981,  /* monza-brianza.it */
18995,  /* monza-e-della-brianza.it */
19017,  /* monzabrianza.it */
19030,  /* monzaebrianza.it */
19044,  /* monzaedellabrianza.it */
 1060,  /* ms.it */
 5566,  /* mt.it */
  172,  /* na.it */
19063,  /* naples.it */
19070,  /* napoli.it */
 1511,  /* no.it */
19077,  /* novara.it */
 5339,  /* nu.it */
19084,  /* nuoro.it */
 1037,  /* og.it */
18315,  /* ogliastra.it */
19090,  /* olbia-tempio.it */
19103,  /* olbiatempio.it */
  137,  /* or.it */
19115,  /* oristano.it */
  777,  /* ot.it */
  522,  /* pa.it */
19124,  /* padova.it */
 8087,  /* padua.it */
19131,  /* palermo.it */
19139,  /* parma.it */
19145,  /* pavia.it */
14130,  /* pc.it */
19151,  /* pd.it */
 3718,  /* pe.it */
19154,  /* perugia.it */
19162,  /* pesaro-urbino.it */
19176,  /* pesarourbino.it */
19189,  /* pescara.it */
 6154,  /* pg.it */
12566,  /* pi.it */
19197,  /* piacenza.it */
19206,  /* piedmont.it */
19215,  /* piemonte.it */
19224,  /* pisa.it */
19229,  /* pistoia.it */
 5411,  /* pmn.it */
 4639,  /* pn.it */
 6927,  /* po.it */
19242,  /* pordenone.it */
19252,  /* potenza.it */
 6351,  /* pr.it */
19260,  /* prato.it */
 6459,  /* pt.it */
19269,  /* pu.it */
 8106,  /* pug.it */
19272,  /* puglia.it */
19279,  /* pv.it */
19282,  /* pz.it */
 1355,  /* ra.it */
19290,  /* ragusa.it */
18368,  /* ravenna.it */
 4844,  /* rc.it */
   80,  /* re.it */
19297,  /* reggio-calabria.it */
19313,  /* reggio-emilia.it */
18081,  /* reggiocalabria.it */
19327,  /* reggioemilia.it */
 1047,  /* rg.it */
 2978,  /* ri.it */
12217,  /* rieti.it */
 5377,  /* rimini.it */
 2934,  /* rm.it */
  821,  /* rn.it */
  166,  /* ro.it */
19349,  /* roma.it */
 1688,  /* rome.it */
19354,  /* rovigo.it */
 1487,  /* sa.it */
19361,  /* salerno.it */
19369,  /* sar.it */
19373,  /* sardegna.it */
19382,  /* sardinia.it */
19391,  /* sassari.it */
19399,  /* savona.it */
 2361,  /* si.it */
19408,  /* sic.it */
19412,  /* sicilia.it */
19420,  /* sicily.it */
19427,  /* siena.it */
19433,  /* siracusa.it */
 7304,  /* so.it */
 6762,  /* sondrio.it */
12214,  /* sp.it */
 7416,  /* sr.it */
  374,  /* ss.it */
17836,  /* suedtirol.it */
 7574,  /* sv.it */
  570,  /* ta.it */
19455,  /* taa.it */
19459,  /* taranto.it */
  334,  /* te.it */
19467,  /* tempio-olbia.it */
19480,  /* tempioolbia.it */
19492,  /* teramo.it */
 2747,  /* terni.it */
 5570,  /* tn.it */
  631,  /* to.it */
19499,  /* torino.it */
  636,  /* tos.it */
19506,  /* toscana.it */
11792,  /* tp.it */
 3281,  /* tr.it */
19514,  /* trani-andria-barletta.it */
19536,  /* trani-barletta-andria.it */
19558,  /* traniandriabarletta.it */
19578,  /* tranibarlettaandria.it */
19598,  /* trapani.it */
19606,  /* trentin-sud-tirol.it */
19624,  /* trentin-sudtirol.it */
19641,  /* trentin-sued-tirol.it */
19660,  /* trentin-suedtirol.it */
19678,  /* trentino.it */
19687,  /* trentino-a-adige.it */
19704,  /* trentino-aadige.it */
19720,  /* trentino-alto-adige.it */
19740,  /* trentino-altoadige.it */
19759,  /* trentino-s-tirol.it */
19776,  /* trentino-stirol.it */
19792,  /* trentino-sud-tirol.it */
19811,  /* trentino-sudtirol.it */
19829,  /* trentino-sued-tirol.it */
19849,  /* trentino-suedtirol.it */
19868,  /* trentinoa-adige.it */
19884,  /* trentinoaadige.it */
17567,  /* trentinoalto-adige.it */
17586,  /* trentinoaltoadige.it */
19899,  /* trentinos-tirol.it */
 7845,  /* trentinostirol.it */
19915,  /* trentinosud-tirol.it */
19933,  /* trentinosudtirol.it */
19950,  /* trentinosued-tirol.it */
19969,  /* trentinosuedtirol.it */
19987,  /* trentinsud-tirol.it */
20004,  /* trentinsudtirol.it */
20020,  /* trentinsued-tirol.it */
20038,  /* trentinsuedtirol.it */
20055,  /* trento.it */
20062,  /* treviso.it */
20070,  /* trieste.it */
  109,  /* ts.it */
20082,  /* turin.it */
20088,  /* tuscany.it */
 2545,  /* tv.it */
 1839,  /* ud.it */
20096,  /* udine.it */
20102,  /* umb.it */
20106,  /* umbria.it */
20113,  /* urbino-pesaro.it */
20127,  /* urbinopesaro.it */
  834,  /* va.it */
20140,  /* val-d-aosta.it */
20152,  /* val-daosta.it */
20163,  /* vald-aosta.it */
17700,  /* valdaosta.it */
20174,  /* valle-aosta.it */
20186,  /* valle-d-aosta.it */
20200,  /* valle-daosta.it */
20213,  /* valleaosta.it */
20224,  /* valled-aosta.it */
20237,  /* valledaosta.it */
20249,  /* vallee-aoste.it */
20262,  /* vallee-d-aoste.it */
17735,  /* valleeaoste.it */
20277,  /* valleedaoste.it */
  447,  /* vao.it */
20290,  /* varese.it */
20318,  /* vb.it */
 6510,  /* vc.it */
20321,  /* vda.it */
  125,  /* ve.it */
 7117,  /* ven.it */
20325,  /* veneto.it */
20332,  /* venezia.it */
 4135,  /* venice.it */
20340,  /* verbania.it */
20349,  /* vercelli.it */
20358,  /* verona.it */
 8231,  /* vi.it */
20365,  /* vibo-valentia.it */
20379,  /* vibovalentia.it */
20392,  /* vicenza.it */
20400,  /* viterbo.it */
 2584,  /* vr.it */
 8073,  /* vs.it */
13924,  /* vt.it */
20408,  /* vv.it */
20411,  /* xn--balsan-sdtirol-nsb.it */
20434,  /* xn--bozen-sdtirol-2ob.it */
20456,  /* xn--bulsan-sdtirol-nsb.it */
20479,  /* xn--cesena-forl-mcb.it */
20499,  /* xn--cesenaforl-i8a.it */
20518,  /* xn--forl-cesena-fcb.it */
20538,  /* xn--forlcesena-c8a.it */
20557,  /* xn--sdtirol-n2a.it */
20573,  /* xn--trentin-sd-tirol-rzb.it */
20297,  /* xn--trentin-sdtirol-7vb.it */
20598,  /* xn--trentino-sd-tirol-c3b.it */
20624,  /* xn--trentino-sdtirol-szb.it */
20649,  /* xn--trentinosd-tirol-rzb.it */
20674,  /* xn--trentinosdtirol-7vb.it */
20698,  /* xn--trentinsd-tirol-6vb.it */
20722,  /* xn--trentinsdtirol-nsb.it */
20745,  /* xn--valle-aoste-ebb.it */
12787,  /* xn--valle-d-aoste-ehb.it */
20765,  /* xn--valleaoste-e7a.it */
20784,  /* xn--valledaoste-ebb.it */
  113,  /* co.je */
 5710,  /* net.je */
 6026,  /* org.je */
 1910,  /* com.jo */
 2622,  /* edu.jo */
 3665,  /* gov.jo */
 4157,  /* mil.jo */
 5672,  /* name.jo */
 5710,  /* net.jo */
 6026,  /* org.jo */
 1140,  /* sch.jo */
  244,  /* aisai.aichi.jp */
10725,  /* ama.aichi.jp */
21737,  /* anjo.aichi.jp */
21742,  /* asuke.aichi.jp */
21748,  /* chiryu.aichi.jp */
21755,  /* chita.aichi.jp */
21761,  /* fuso.aichi.jp */
21766,  /* gamagori.aichi.jp */
21775,  /* handa.aichi.jp */
21781,  /* hazu.aichi.jp */
21786,  /* hekinan.aichi.jp */
21794,  /* higashiura.aichi.jp */
21805,  /* ichinomiya.aichi.jp */
21816,  /* inazawa.aichi.jp */
21824,  /* inuyama.aichi.jp */
21832,  /* isshiki.aichi.jp */
21840,  /* iwakura.aichi.jp */
21848,  /* kanie.aichi.jp */
21854,  /* kariya.aichi.jp */
21861,  /* kasugai.aichi.jp */
21869,  /* kira.aichi.jp */
21874,  /* kiyosu.aichi.jp */
21881,  /* komaki.aichi.jp */
21888,  /* konan.aichi.jp */
19447,  /* kota.aichi.jp */
21894,  /* mihama.aichi.jp */
21910,  /* miyoshi.aichi.jp */
21918,  /* nishio.aichi.jp */
21925,  /* nisshin.aichi.jp */
21936,  /* obu.aichi.jp */
21940,  /* oguchi.aichi.jp */
21947,  /* oharu.aichi.jp */
21953,  /* okazaki.aichi.jp */
21961,  /* owariasahi.aichi.jp */
18685,  /* seto.aichi.jp */
21978,  /* shikatsu.aichi.jp */
21987,  /* shinshiro.aichi.jp */
21997,  /* shitara.aichi.jp */
22005,  /* tahara.aichi.jp */
22012,  /* takahama.aichi.jp */
22021,  /* tobishima.aichi.jp */
22031,  /* toei.aichi.jp */
12559,  /* togo.aichi.jp */
22036,  /* tokai.aichi.jp */
 5668,  /* tokoname.aichi.jp */
22042,  /* toyoake.aichi.jp */
22050,  /* toyohashi.aichi.jp */
22060,  /* toyokawa.aichi.jp */
22069,  /* toyone.aichi.jp */
 7959,  /* toyota.aichi.jp */
22080,  /* tsushima.aichi.jp */
22089,  /* yatomi.aichi.jp */
20817,  /* akita.akita.jp */
22096,  /* daisen.akita.jp */
22103,  /* fujisato.akita.jp */
22112,  /* gojome.akita.jp */
22119,  /* hachirogata.akita.jp */
22131,  /* happou.akita.jp */
22138,  /* higashinaruse.akita.jp */
22156,  /* honjo.akita.jp */
22162,  /* honjyo.akita.jp */
20927,  /* ikawa.akita.jp */
22176,  /* kamikoani.akita.jp */
22186,  /* kamioka.akita.jp */
22194,  /* katagami.akita.jp */
 8136,  /* kazuno.akita.jp */
22203,  /* kitaakita.akita.jp */
 6053,  /* kosaka.akita.jp */
22213,  /* kyowa.akita.jp */
22221,  /* misato.akita.jp */
22232,  /* mitane.akita.jp */
22239,  /* moriyoshi.akita.jp */
22249,  /* nikaho.akita.jp */
22256,  /* noshiro.akita.jp */
 2236,  /* odate.akita.jp */
10716,  /* oga.akita.jp */
22125,  /* ogata.akita.jp */
22276,  /* semboku.akita.jp */
22284,  /* yokote.akita.jp */
22152,  /* yurihonjo.akita.jp */
20823,  /* aomori.aomori.jp */
22291,  /* gonohe.aomori.jp */
22298,  /* hachinohe.aomori.jp */
22308,  /* hashikami.aomori.jp */
22318,  /* hiranai.aomori.jp */
22326,  /* hirosaki.aomori.jp */
22335,  /* itayanagi.aomori.jp */
22345,  /* kuroishi.aomori.jp */
22354,  /* misawa.aomori.jp */
22361,  /* mutsu.aomori.jp */
22367,  /* nakadomari.aomori.jp */
22378,  /* noheji.aomori.jp */
22385,  /* oirase.aomori.jp */
22392,  /* owani.aomori.jp */
22398,  /* rokunohe.aomori.jp */
22407,  /* sannohe.aomori.jp */
22415,  /* shichinohe.aomori.jp */
22426,  /* shingo.aomori.jp */
22433,  /* takko.aomori.jp */
22439,  /* towada.aomori.jp */
22446,  /* tsugaru.aomori.jp */
22454,  /* tsuruta.aomori.jp */
22462,  /* abiko.chiba.jp */
21966,  /* asahi.chiba.jp */
22468,  /* chonan.chiba.jp */
22475,  /* chosei.chiba.jp */
22482,  /* choshi.chiba.jp */
22493,  /* chuo.chiba.jp */
22498,  /* funabashi.chiba.jp */
22508,  /* futtsu.chiba.jp */
22515,  /* hanamigawa.chiba.jp */
22526,  /* ichihara.chiba.jp */
22535,  /* ichikawa.chiba.jp */
21805,  /* ichinomiya.chiba.jp */
22544,  /* inzai.chiba.jp */
18938,  /* isumi.chiba.jp */
22550,  /* kamagaya.chiba.jp */
22559,  /* kamogawa.chiba.jp */
22568,  /* kashiwa.chiba.jp */
22578,  /* katori.chiba.jp */
22590,  /* katsuura.chiba.jp */
22599,  /* kimitsu.chiba.jp */
22607,  /* kisarazu.chiba.jp */
22616,  /* kozaki.chiba.jp */
22623,  /* kujukuri.chiba.jp */
22632,  /* kyonan.chiba.jp */
22639,  /* matsudo.chiba.jp */
22647,  /* midori.chiba.jp */
21894,  /* mihama.chiba.jp */
22654,  /* minamiboso.chiba.jp */
22665,  /* mobara.chiba.jp */
22672,  /* mutsuzawa.chiba.jp */
22682,  /* nagara.chiba.jp */
22689,  /* nagareyama.chiba.jp */
22700,  /* narashino.chiba.jp */
22710,  /* narita.chiba.jp */
22717,  /* noda.chiba.jp */
22722,  /* oamishirasato.chiba.jp */
22736,  /* omigawa.chiba.jp */
22744,  /* onjuku.chiba.jp */
22754,  /* otaki.chiba.jp */
  154,  /* sakae.chiba.jp */
 6867,  /* sakura.chiba.jp */
22760,  /* shimofusa.chiba.jp */
22770,  /* shirako.chiba.jp */
22778,  /* shiroi.chiba.jp */
22785,  /* shisui.chiba.jp */
22792,  /* sodegaura.chiba.jp */
22802,  /* sosa.chiba.jp */
22808,  /* tako.chiba.jp */
22813,  /* tateyama.chiba.jp */
22822,  /* togane.chiba.jp */
22829,  /* tohnosho.chiba.jp */
22219,  /* tomisato.chiba.jp */
22838,  /* urayasu.chiba.jp */
22846,  /* yachimata.chiba.jp */
22856,  /* yachiyo.chiba.jp */
20830,  /* yokaichiba.chiba.jp */
22864,  /* yokoshibahikari.chiba.jp */
22880,  /* yotsukaido.chiba.jp */
22892,  /* ainan.ehime.jp */
22899,  /* honai.ehime.jp */
22908,  /* ikata.ehime.jp */
22914,  /* imabari.ehime.jp */
22860,  /* iyo.ehime.jp */
22933,  /* kamijima.ehime.jp */
22942,  /* kihoku.ehime.jp */
22949,  /* kumakogen.ehime.jp */
22959,  /* masaki.ehime.jp */
22966,  /* matsuno.ehime.jp */
22981,  /* matsuyama.ehime.jp */
22905,  /* namikata.ehime.jp */
22991,  /* niihama.ehime.jp */
23000,  /* ozu.ehime.jp */
23004,  /* saijo.ehime.jp */
22922,  /* seiyo.ehime.jp */
23010,  /* shikokuchuo.ehime.jp */
23023,  /* tobe.ehime.jp */
12591,  /* toon.ehime.jp */
23037,  /* uchiko.ehime.jp */
23044,  /* uwajima.ehime.jp */
23052,  /* yawatahama.ehime.jp */
23069,  /* echizen.fukui.jp */
23077,  /* eiheiji.fukui.jp */
20847,  /* fukui.fukui.jp */
23085,  /* ikeda.fukui.jp */
23091,  /* katsuyama.fukui.jp */
21894,  /* mihama.fukui.jp */
23063,  /* minamiechizen.fukui.jp */
23101,  /* obama.fukui.jp */
12816,  /* ohi.fukui.jp */
23108,  /* ono.fukui.jp */
23112,  /* sabae.fukui.jp */
23118,  /* sakai.fukui.jp */
22012,  /* takahama.fukui.jp */
23124,  /* tsuruga.fukui.jp */
23132,  /* wakasa.fukui.jp */
23139,  /* ashiya.fukuoka.jp */
23146,  /* buzen.fukuoka.jp */
23152,  /* chikugo.fukuoka.jp */
23160,  /* chikuho.fukuoka.jp */
23168,  /* chikujo.fukuoka.jp */
23176,  /* chikushino.fukuoka.jp */
23187,  /* chikuzen.fukuoka.jp */
22493,  /* chuo.fukuoka.jp */
23196,  /* dazaifu.fukuoka.jp */
23204,  /* fukuchi.fukuoka.jp */
23212,  /* hakata.fukuoka.jp */
23219,  /* higashi.fukuoka.jp */
23227,  /* hirokawa.fukuoka.jp */
23236,  /* hisayama.fukuoka.jp */
23245,  /* iizuka.fukuoka.jp */
23252,  /* inatsuki.fukuoka.jp */
22251,  /* kaho.fukuoka.jp */
23261,  /* kasuga.fukuoka.jp */
23268,  /* kasuya.fukuoka.jp */
23275,  /* kawara.fukuoka.jp */
23282,  /* keisen.fukuoka.jp */
22264,  /* koga.fukuoka.jp */
23289,  /* kurate.fukuoka.jp */
23296,  /* kurogi.fukuoka.jp */
23310,  /* kurume.fukuoka.jp */
23320,  /* minami.fukuoka.jp */
23327,  /* miyako.fukuoka.jp */
23336,  /* miyama.fukuoka.jp */
23343,  /* miyawaka.fukuoka.jp */
23352,  /* mizumaki.fukuoka.jp */
23361,  /* munakata.fukuoka.jp */
20939,  /* nakagawa.fukuoka.jp */
23370,  /* nakama.fukuoka.jp */
23381,  /* nishi.fukuoka.jp */
22269,  /* nogata.fukuoka.jp */
23387,  /* ogori.fukuoka.jp */
23393,  /* okagaki.fukuoka.jp */
22063,  /* okawa.fukuoka.jp */
23402,  /* oki.fukuoka.jp */
23406,  /* omuta.fukuoka.jp */
23412,  /* onga.fukuoka.jp */
23422,  /* onojo.fukuoka.jp */
 4675,  /* oto.fukuoka.jp */
23433,  /* saigawa.fukuoka.jp */
23441,  /* sasaguri.fukuoka.jp */
23450,  /* shingu.fukuoka.jp */
23457,  /* shinyoshitomi.fukuoka.jp */
22898,  /* shonai.fukuoka.jp */
23471,  /* soeda.fukuoka.jp */
23480,  /* sue.fukuoka.jp */
23484,  /* tachiarai.fukuoka.jp */
23496,  /* tagawa.fukuoka.jp */
23505,  /* takata.fukuoka.jp */
23512,  /* toho.fukuoka.jp */
23517,  /* toyotsu.fukuoka.jp */
23525,  /* tsuiki.fukuoka.jp */
23532,  /* ukiha.fukuoka.jp */
18940,  /* umi.fukuoka.jp */
23539,  /* usui.fukuoka.jp */
23544,  /* yamada.fukuoka.jp */
23551,  /* yame.fukuoka.jp */
23556,  /* yanagawa.fukuoka.jp */
23565,  /* yukuhashi.fukuoka.jp */
23575,  /* aizubange.fukushima.jp */
23585,  /* aizumisato.fukushima.jp */
23596,  /* aizuwakamatsu.fukushima.jp */
23610,  /* asakawa.fukushima.jp */
23618,  /* bandai.fukushima.jp */
 2237,  /* date.fukushima.jp */
20865,  /* fukushima.fukushima.jp */
23625,  /* furudono.fukushima.jp */
23634,  /* futaba.fukushima.jp */
23641,  /* hanawa.fukushima.jp */
23219,  /* higashi.fukushima.jp */
23648,  /* hirata.fukushima.jp */
23655,  /* hirono.fukushima.jp */
23662,  /* iitate.fukushima.jp */
23669,  /* inawashiro.fukushima.jp */
20924,  /* ishikawa.fukushima.jp */
23684,  /* iwaki.fukushima.jp */
23690,  /* izumizaki.fukushima.jp */
23700,  /* kagamiishi.fukushima.jp */
23711,  /* kaneyama.fukushima.jp */
23720,  /* kawamata.fukushima.jp */
23503,  /* kitakata.fukushima.jp */
23729,  /* kitashiobara.fukushima.jp */
23742,  /* koori.fukushima.jp */
23754,  /* koriyama.fukushima.jp */
23763,  /* kunimi.fukushima.jp */
23770,  /* miharu.fukushima.jp */
23777,  /* mishima.fukushima.jp */
20993,  /* namie.fukushima.jp */
 5781,  /* nango.fukushima.jp */
23785,  /* nishiaizu.fukushima.jp */
23795,  /* nishigo.fukushima.jp */
23803,  /* okuma.fukushima.jp */
23809,  /* omotego.fukushima.jp */
23108,  /* ono.fukushima.jp */
23817,  /* otama.fukushima.jp */
23823,  /* samegawa.fukushima.jp */
23832,  /* shimogo.fukushima.jp */
23847,  /* shirakawa.fukushima.jp */
23857,  /* showa.fukushima.jp */
23863,  /* soma.fukushima.jp */
23868,  /* sukagawa.fukushima.jp */
23877,  /* taishin.fukushima.jp */
23885,  /* tamakawa.fukushima.jp */
23894,  /* tanagura.fukushima.jp */
23903,  /* tenei.fukushima.jp */
23909,  /* yabuki.fukushima.jp */
23923,  /* yamato.fukushima.jp */
23930,  /* yamatsuri.fukushima.jp */
23940,  /* yanaizu.fukushima.jp */
23948,  /* yugawa.fukushima.jp */
23955,  /* anpachi.gifu.jp */
11931,  /* ena.gifu.jp */
20875,  /* gifu.gifu.jp */
23963,  /* ginan.gifu.jp */
 2480,  /* godo.gifu.jp */
 4435,  /* gujo.gifu.jp */
23969,  /* hashima.gifu.jp */
23977,  /* hichiso.gifu.jp */
23988,  /* hida.gifu.jp */
23840,  /* higashishirakawa.gifu.jp */
23993,  /* ibigawa.gifu.jp */
23085,  /* ikeda.gifu.jp */
24001,  /* kakamigahara.gifu.jp */
24014,  /* kani.gifu.jp */
24019,  /* kasahara.gifu.jp */
24028,  /* kasamatsu.gifu.jp */
24038,  /* kawaue.gifu.jp */
24045,  /* kitagata.gifu.jp */
24056,  /* mino.gifu.jp */
24061,  /* minokamo.gifu.jp */
24070,  /* mitake.gifu.jp */
24077,  /* mizunami.gifu.jp */
24086,  /* motosu.gifu.jp */
24093,  /* nakatsugawa.gifu.jp */
24106,  /* ogaki.gifu.jp */
24112,  /* sakahogi.gifu.jp */
24127,  /* seki.gifu.jp */
24132,  /* sekigahara.gifu.jp */
23847,  /* shirakawa.gifu.jp */
24143,  /* tajimi.gifu.jp */
24150,  /* takayama.gifu.jp */
24159,  /* tarui.gifu.jp */
23401,  /* toki.gifu.jp */
24165,  /* tomika.gifu.jp */
24172,  /* wanouchi.gifu.jp */
21702,  /* yamagata.gifu.jp */
24181,  /* yaotsu.gifu.jp */
24190,  /* yoro.gifu.jp */
24195,  /* annaka.gunma.jp */
24202,  /* chiyoda.gunma.jp */
24210,  /* fujioka.gunma.jp */
24218,  /* higashiagatsuma.gunma.jp */
24234,  /* isesaki.gunma.jp */
24242,  /* itakura.gunma.jp */
24250,  /* kanna.gunma.jp */
 5860,  /* kanra.gunma.jp */
24256,  /* katashina.gunma.jp */
24266,  /* kawaba.gunma.jp */
24273,  /* kiryu.gunma.jp */
24279,  /* kusatsu.gunma.jp */
24287,  /* maebashi.gunma.jp */
24296,  /* meiwa.gunma.jp */
22647,  /* midori.gunma.jp */
24302,  /* minakami.gunma.jp */
24311,  /* naganohara.gunma.jp */
24322,  /* nakanojo.gunma.jp */
24331,  /* nanmoku.gunma.jp */
24339,  /* numata.gunma.jp */
24346,  /* oizumi.gunma.jp */
24355,  /* ora.gunma.jp */
 7962,  /* ota.gunma.jp */
24359,  /* shibukawa.gunma.jp */
24369,  /* shimonita.gunma.jp */
24379,  /* shinto.gunma.jp */
23857,  /* showa.gunma.jp */
24386,  /* takasaki.gunma.jp */
24150,  /* takayama.gunma.jp */
24395,  /* tamamura.gunma.jp */
24404,  /* tatebayashi.gunma.jp */
24416,  /* tomioka.gunma.jp */
24424,  /* tsukiyono.gunma.jp */
24434,  /* tsumagoi.gunma.jp */
 5827,  /* ueno.gunma.jp */
24443,  /* yoshioka.gunma.jp */
23317,  /* asaminami.hiroshima.jp */
24452,  /* daiwa.hiroshima.jp */
24458,  /* etajima.hiroshima.jp */
24466,  /* fuchu.hiroshima.jp */
24472,  /* fukuyama.hiroshima.jp */
24481,  /* hatsukaichi.hiroshima.jp */
24493,  /* higashihiroshima.hiroshima.jp */
24510,  /* hongo.hiroshima.jp */
24516,  /* jinsekikogen.hiroshima.jp */
24529,  /* kaita.hiroshima.jp */
20849,  /* kui.hiroshima.jp */
24535,  /* kumano.hiroshima.jp */
 6531,  /* kure.hiroshima.jp */
24546,  /* mihara.hiroshima.jp */
21910,  /* miyoshi.hiroshima.jp */
24197,  /* naka.hiroshima.jp */
24553,  /* onomichi.hiroshima.jp */
22928,  /* osakikamijima.hiroshima.jp */
24562,  /* otake.hiroshima.jp */
 6055,  /* saka.hiroshima.jp */
24568,  /* sera.hiroshima.jp */
23377,  /* seranishi.hiroshima.jp */
24573,  /* shinichi.hiroshima.jp */
24582,  /* shobara.hiroshima.jp */
24590,  /* takehara.hiroshima.jp */
24599,  /* abashiri.hokkaido.jp */
24610,  /* abira.hokkaido.jp */
24616,  /* aibetsu.hokkaido.jp */
24608,  /* akabira.hokkaido.jp */
24624,  /* akkeshi.hokkaido.jp */
24632,  /* asahikawa.hokkaido.jp */
24642,  /* ashibetsu.hokkaido.jp */
24652,  /* ashoro.hokkaido.jp */
24659,  /* assabu.hokkaido.jp */
24227,  /* atsuma.hokkaido.jp */
24666,  /* bibai.hokkaido.jp */
24672,  /* biei.hokkaido.jp */
24677,  /* bifuka.hokkaido.jp */
24684,  /* bihoro.hokkaido.jp */
24691,  /* biratori.hokkaido.jp */
24700,  /* chippubetsu.hokkaido.jp */
24712,  /* chitose.hokkaido.jp */
 2237,  /* date.hokkaido.jp */
24720,  /* ebetsu.hokkaido.jp */
24727,  /* embetsu.hokkaido.jp */
24735,  /* eniwa.hokkaido.jp */
24741,  /* erimo.hokkaido.jp */
17604,  /* esan.hokkaido.jp */
24747,  /* esashi.hokkaido.jp */
24754,  /* fukagawa.hokkaido.jp */
20865,  /* fukushima.hokkaido.jp */
24767,  /* furano.hokkaido.jp */
24774,  /* furubira.hokkaido.jp */
24783,  /* haboro.hokkaido.jp */
 2233,  /* hakodate.hokkaido.jp */
24790,  /* hamatonbetsu.hokkaido.jp */
24803,  /* hidaka.hokkaido.jp */
24810,  /* higashikagura.hokkaido.jp */
24824,  /* higashikawa.hokkaido.jp */
24836,  /* hiroo.hokkaido.jp */
24842,  /* hokuryu.hokkaido.jp */
24850,  /* hokuto.hokkaido.jp */
24857,  /* honbetsu.hokkaido.jp */
24866,  /* horokanai.hokkaido.jp */
24876,  /* horonobe.hokkaido.jp */
23085,  /* ikeda.hokkaido.jp */
24885,  /* imakane.hokkaido.jp */
24893,  /* ishikari.hokkaido.jp */
24902,  /* iwamizawa.hokkaido.jp */
24912,  /* iwanai.hokkaido.jp */
24763,  /* kamifurano.hokkaido.jp */
24919,  /* kamikawa.hokkaido.jp */
24928,  /* kamishihoro.hokkaido.jp */
24940,  /* kamisunagawa.hokkaido.jp */
24953,  /* kamoenai.hokkaido.jp */
24962,  /* kayabe.hokkaido.jp */
24969,  /* kembuchi.hokkaido.jp */
24978,  /* kikonai.hokkaido.jp */
24986,  /* kimobetsu.hokkaido.jp */
20886,  /* kitahiroshima.hokkaido.jp */
24996,  /* kitami.hokkaido.jp */
25003,  /* kiyosato.hokkaido.jp */
25012,  /* koshimizu.hokkaido.jp */
25022,  /* kunneppu.hokkaido.jp */
25031,  /* kuriyama.hokkaido.jp */
25040,  /* kuromatsunai.hokkaido.jp */
25053,  /* kushiro.hokkaido.jp */
25061,  /* kutchan.hokkaido.jp */
22213,  /* kyowa.hokkaido.jp */
25069,  /* mashike.hokkaido.jp */
25077,  /* matsumae.hokkaido.jp */
25086,  /* mikasa.hokkaido.jp */
25093,  /* minamifurano.hokkaido.jp */
25106,  /* mombetsu.hokkaido.jp */
25115,  /* moseushi.hokkaido.jp */
25126,  /* mukawa.hokkaido.jp */
25133,  /* muroran.hokkaido.jp */
25141,  /* naie.hokkaido.jp */
20939,  /* nakagawa.hokkaido.jp */
25146,  /* nakasatsunai.hokkaido.jp */
25159,  /* nakatombetsu.hokkaido.jp */
25172,  /* nanae.hokkaido.jp */
25178,  /* nanporo.hokkaido.jp */
24188,  /* nayoro.hokkaido.jp */
25186,  /* nemuro.hokkaido.jp */
25193,  /* niikappu.hokkaido.jp */
16643,  /* niki.hokkaido.jp */
25202,  /* nishiokoppe.hokkaido.jp */
25214,  /* noboribetsu.hokkaido.jp */
24339,  /* numata.hokkaido.jp */
25226,  /* obihiro.hokkaido.jp */
25234,  /* obira.hokkaido.jp */
25240,  /* oketo.hokkaido.jp */
25207,  /* okoppe.hokkaido.jp */
25246,  /* otaru.hokkaido.jp */
23022,  /* otobe.hokkaido.jp */
25252,  /* otofuke.hokkaido.jp */
25260,  /* otoineppu.hokkaido.jp */
 5577,  /* oumu.hokkaido.jp */
24353,  /* ozora.hokkaido.jp */
19266,  /* pippu.hokkaido.jp */
25270,  /* rankoshi.hokkaido.jp */
25279,  /* rebun.hokkaido.jp */
25285,  /* rikubetsu.hokkaido.jp */
25295,  /* rishiri.hokkaido.jp */
25303,  /* rishirifuji.hokkaido.jp */
19347,  /* saroma.hokkaido.jp */
25315,  /* sarufutsu.hokkaido.jp */
25325,  /* shakotan.hokkaido.jp */
25334,  /* shari.hokkaido.jp */
25340,  /* shibecha.hokkaido.jp */
24643,  /* shibetsu.hokkaido.jp */
25349,  /* shikabe.hokkaido.jp */
25357,  /* shikaoi.hokkaido.jp */
25365,  /* shimamaki.hokkaido.jp */
25014,  /* shimizu.hokkaido.jp */
25375,  /* shimokawa.hokkaido.jp */
25385,  /* shinshinotsu.hokkaido.jp */
25398,  /* shintoku.hokkaido.jp */
25407,  /* shiranuka.hokkaido.jp */
25417,  /* shiraoi.hokkaido.jp */
25425,  /* shiriuchi.hokkaido.jp */
25435,  /* sobetsu.hokkaido.jp */
24944,  /* sunagawa.hokkaido.jp */
25443,  /* taiki.hokkaido.jp */
25449,  /* takasu.hokkaido.jp */
25456,  /* takikawa.hokkaido.jp */
25465,  /* takinoue.hokkaido.jp */
25474,  /* teshikaga.hokkaido.jp */
25484,  /* tobetsu.hokkaido.jp */
25492,  /* tohma.hokkaido.jp */
25498,  /* tomakomai.hokkaido.jp */
25508,  /* tomari.hokkaido.jp */
25515,  /* toya.hokkaido.jp */
25520,  /* toyako.hokkaido.jp */
25527,  /* toyotomi.hokkaido.jp */
25536,  /* toyoura.hokkaido.jp */
25544,  /* tsubetsu.hokkaido.jp */
25553,  /* tsukigata.hokkaido.jp */
25563,  /* urakawa.hokkaido.jp */
25571,  /* urausu.hokkaido.jp */
24845,  /* uryu.hokkaido.jp */
25578,  /* utashinai.hokkaido.jp */
25588,  /* wakkanai.hokkaido.jp */
25597,  /* wassamu.hokkaido.jp */
25605,  /* yakumo.hokkaido.jp */
25612,  /* yoichi.hokkaido.jp */
25619,  /* aioi.hyogo.jp */
25624,  /* akashi.hyogo.jp */
22774,  /* ako.hyogo.jp */
25631,  /* amagasaki.hyogo.jp */
24105,  /* aogaki.hyogo.jp */
25644,  /* asago.hyogo.jp */
23139,  /* ashiya.hyogo.jp */
25656,  /* awaji.hyogo.jp */
25662,  /* fukusaki.hyogo.jp */
25671,  /* goshiki.hyogo.jp */
25679,  /* harima.hyogo.jp */
25686,  /* himeji.hyogo.jp */
22535,  /* ichikawa.hyogo.jp */
25695,  /* inagawa.hyogo.jp */
24997,  /* itami.hyogo.jp */
25703,  /* kakogawa.hyogo.jp */
25712,  /* kamigori.hyogo.jp */
24919,  /* kamikawa.hyogo.jp */
25721,  /* kasai.hyogo.jp */
23261,  /* kasuga.hyogo.jp */
25727,  /* kawanishi.hyogo.jp */
25737,  /* miki.hyogo.jp */
25650,  /* minamiawaji.hyogo.jp */
25742,  /* nishinomiya.hyogo.jp */
23680,  /* nishiwaki.hyogo.jp */
23108,  /* ono.hyogo.jp */
25754,  /* sanda.hyogo.jp */
25760,  /* sannan.hyogo.jp */
25767,  /* sasayama.hyogo.jp */
25776,  /* sayo.hyogo.jp */
23450,  /* shingu.hyogo.jp */
25781,  /* shinonsen.hyogo.jp */
25791,  /* shiso.hyogo.jp */
25800,  /* sumoto.hyogo.jp */
25807,  /* taishi.hyogo.jp */
25816,  /* taka.hyogo.jp */
25821,  /* takarazuka.hyogo.jp */
25641,  /* takasago.hyogo.jp */
25832,  /* takino.hyogo.jp */
25842,  /* tamba.hyogo.jp */
25848,  /* tatsuno.hyogo.jp */
25856,  /* toyooka.hyogo.jp */
25864,  /* yabu.hyogo.jp */
25871,  /* yashiro.hyogo.jp */
25879,  /* yoka.hyogo.jp */
22062,  /* yokawa.hyogo.jp */
 5363,  /* ami.ibaraki.jp */
21966,  /* asahi.ibaraki.jp */
25890,  /* bando.ibaraki.jp */
25896,  /* chikusei.ibaraki.jp */
  254,  /* daigo.ibaraki.jp */
25905,  /* fujishiro.ibaraki.jp */
 3897,  /* hitachi.ibaraki.jp */
25915,  /* hitachinaka.ibaraki.jp */
25927,  /* hitachiomiya.ibaraki.jp */
25940,  /* hitachiota.ibaraki.jp */
20915,  /* ibaraki.ibaraki.jp */
 7246,  /* ina.ibaraki.jp */
25957,  /* inashiki.ibaraki.jp */
22807,  /* itako.ibaraki.jp */
25966,  /* iwama.ibaraki.jp */
25972,  /* joso.ibaraki.jp */
25977,  /* kamisu.ibaraki.jp */
25984,  /* kasama.ibaraki.jp */
25993,  /* kashima.ibaraki.jp */
26001,  /* kasumigaura.ibaraki.jp */
22264,  /* koga.ibaraki.jp */
26013,  /* miho.ibaraki.jp */
 7899,  /* mito.ibaraki.jp */
26018,  /* moriya.ibaraki.jp */
24197,  /* naka.ibaraki.jp */
26025,  /* namegata.ibaraki.jp */
26034,  /* oarai.ibaraki.jp */
22562,  /* ogawa.ibaraki.jp */
26048,  /* omitama.ibaraki.jp */
26056,  /* ryugasaki.ibaraki.jp */
23118,  /* sakai.ibaraki.jp */
26066,  /* sakuragawa.ibaraki.jp */
26077,  /* shimodate.ibaraki.jp */
26087,  /* shimotsuma.ibaraki.jp */
26098,  /* shirosato.ibaraki.jp */
11639,  /* sowa.ibaraki.jp */
26108,  /* suifu.ibaraki.jp */
26114,  /* takahagi.ibaraki.jp */
26123,  /* tamatsukuri.ibaraki.jp */
22036,  /* tokai.ibaraki.jp */
26135,  /* tomobe.ibaraki.jp */
 1196,  /* tone.ibaraki.jp */
26142,  /* toride.ibaraki.jp */
26149,  /* tsuchiura.ibaraki.jp */
26159,  /* tsukuba.ibaraki.jp */
26167,  /* uchihara.ibaraki.jp */
26176,  /* ushiku.ibaraki.jp */
22856,  /* yachiyo.ibaraki.jp */
21702,  /* yamagata.ibaraki.jp */
26183,  /* yawara.ibaraki.jp */
26190,  /* yuki.ibaraki.jp */
26195,  /* anamizu.ishikawa.jp */
26203,  /* hakui.ishikawa.jp */
26209,  /* hakusan.ishikawa.jp */
25479,  /* kaga.ishikawa.jp */
26226,  /* kahoku.ishikawa.jp */
26233,  /* kanazawa.ishikawa.jp */
20814,  /* kawakita.ishikawa.jp */
 4607,  /* komatsu.ishikawa.jp */
26242,  /* nakanoto.ishikawa.jp */
26251,  /* nanao.ishikawa.jp */
26261,  /* nomi.ishikawa.jp */
26266,  /* nonoichi.ishikawa.jp */
26246,  /* noto.ishikawa.jp */
26277,  /* shika.ishikawa.jp */
26283,  /* suzu.ishikawa.jp */
26288,  /* tsubata.ishikawa.jp */
26296,  /* tsurugi.ishikawa.jp */
26304,  /* uchinada.ishikawa.jp */
23045,  /* wajima.ishikawa.jp */
26313,  /* fudai.iwate.jp */
26319,  /* fujisawa.iwate.jp */
26328,  /* hanamaki.iwate.jp */
26337,  /* hiraizumi.iwate.jp */
23655,  /* hirono.iwate.jp */
22417,  /* ichinohe.iwate.jp */
24121,  /* ichinoseki.iwate.jp */
26347,  /* iwaizumi.iwate.jp */
20933,  /* iwate.iwate.jp */
26356,  /* joboji.iwate.jp */
26363,  /* kamaishi.iwate.jp */
26372,  /* kanegasaki.iwate.jp */
26383,  /* karumai.iwate.jp */
26391,  /* kawai.iwate.jp */
26397,  /* kitakami.iwate.jp */
26406,  /* kuji.iwate.jp */
22400,  /* kunohe.iwate.jp */
26411,  /* kuzumaki.iwate.jp */
23327,  /* miyako.iwate.jp */
26420,  /* mizusawa.iwate.jp */
26429,  /* morioka.iwate.jp */
26437,  /* ninohe.iwate.jp */
22717,  /* noda.iwate.jp */
26444,  /* ofunato.iwate.jp */
26453,  /* oshu.iwate.jp */
26458,  /* otsuchi.iwate.jp */
26466,  /* rikuzentakata.iwate.jp */
22570,  /* shiwa.iwate.jp */
26480,  /* shizukuishi.iwate.jp */
26492,  /* sumita.iwate.jp */
26499,  /* tanohata.iwate.jp */
23107,  /* tono.iwate.jp */
26508,  /* yahaba.iwate.jp */
23544,  /* yamada.iwate.jp */
26515,  /* ayagawa.kagawa.jp */
26523,  /* higashikagawa.kagawa.jp */
26537,  /* kanonji.kagawa.jp */
26545,  /* kotohira.kagawa.jp */
26554,  /* manno.kagawa.jp */
 3367,  /* marugame.kagawa.jp */
26560,  /* mitoyo.kagawa.jp */
26567,  /* naoshima.kagawa.jp */
26576,  /* sanuki.kagawa.jp */
26583,  /* tadotsu.kagawa.jp */
26591,  /* takamatsu.kagawa.jp */
26601,  /* tonosho.kagawa.jp */
26257,  /* uchinomi.kagawa.jp */
26609,  /* utazu.kagawa.jp */
26615,  /* zentsuji.kagawa.jp */
26624,  /* akune.kagoshima.jp */
26631,  /* amami.kagoshima.jp */
26637,  /* hioki.kagoshima.jp */
 8285,  /* isa.kagoshima.jp */
 6606,  /* isen.kagoshima.jp */
24347,  /* izumi.kagoshima.jp */
20948,  /* kagoshima.kagoshima.jp */
26643,  /* kanoya.kagoshima.jp */
26650,  /* kawanabe.kagoshima.jp */
26659,  /* kinko.kagoshima.jp */
26665,  /* kouyama.kagoshima.jp */
26673,  /* makurazaki.kagoshima.jp */
25797,  /* matsumoto.kagoshima.jp */
22228,  /* minamitane.kagoshima.jp */
26684,  /* nakatane.kagoshima.jp */
26693,  /* nishinoomote.kagoshima.jp */
21076,  /* satsumasendai.kagoshima.jp */
26706,  /* soo.kagoshima.jp */
26710,  /* tarumizu.kagoshima.jp */
23538,  /* yusui.kagoshima.jp */
22169,  /* aikawa.kanagawa.jp */
26719,  /* atsugi.kanagawa.jp */
26726,  /* ayase.kanagawa.jp */
26732,  /* chigasaki.kanagawa.jp */
25951,  /* ebina.kanagawa.jp */
26319,  /* fujisawa.kanagawa.jp */
26742,  /* hadano.kanagawa.jp */
26749,  /* hakone.kanagawa.jp */
26756,  /* hiratsuka.kanagawa.jp */
26766,  /* isehara.kanagawa.jp */
26774,  /* kaisei.kanagawa.jp */
26781,  /* kamakura.kanagawa.jp */
26790,  /* kiyokawa.kanagawa.jp */
26799,  /* matsuda.kanagawa.jp */
26807,  /* minamiashigara.kanagawa.jp */
26822,  /* miura.kanagawa.jp */
26828,  /* nakai.kanagawa.jp */
26834,  /* ninomiya.kanagawa.jp */
26843,  /* odawara.kanagawa.jp */
 5453,  /* oi.kanagawa.jp */
26854,  /* oiso.kanagawa.jp */
24542,  /* sagamihara.kanagawa.jp */
25124,  /* samukawa.kanagawa.jp */
26859,  /* tsukui.kanagawa.jp */
26866,  /* yamakita.kanagawa.jp */
23923,  /* yamato.kanagawa.jp */
26875,  /* yokosuka.kanagawa.jp */
26884,  /* yugawara.kanagawa.jp */
21731,  /* zama.kanagawa.jp */
26893,  /* zushi.kanagawa.jp */
 1761,  /* !city.kawasaki.jp */
11599,  /* *.kawasaki.jp */
20919,  /* aki.kochi.jp */
26899,  /* geisei.kochi.jp */
24803,  /* hidaka.kochi.jp */
26906,  /* higashitsuno.kochi.jp */
 1510,  /* ino.kochi.jp */
26925,  /* kagami.kochi.jp */
22313,  /* kami.kochi.jp */
23494,  /* kitagawa.kochi.jp */
20987,  /* kochi.kochi.jp */
24546,  /* mihara.kochi.jp */
21139,  /* motoyama.kochi.jp */
26940,  /* muroto.kochi.jp */
26947,  /* nahari.kochi.jp */
26954,  /* nakamura.kochi.jp */
26963,  /* nankoku.kochi.jp */
26971,  /* nishitosa.kochi.jp */
26981,  /* niyodogawa.kochi.jp */
20988,  /* ochi.kochi.jp */
22063,  /* okawa.kochi.jp */
26992,  /* otoyo.kochi.jp */
26998,  /* otsuki.kochi.jp */
23611,  /* sakawa.kochi.jp */
27005,  /* sukumo.kochi.jp */
27012,  /* susaki.kochi.jp */
26976,  /* tosa.kochi.jp */
27019,  /* tosashimizu.kochi.jp */
26562,  /* toyo.kochi.jp */
22968,  /* tsuno.kochi.jp */
27031,  /* umaji.kochi.jp */
27037,  /* yasuda.kochi.jp */
27044,  /* yusuhara.kochi.jp */
27057,  /* amakusa.kumamoto.jp */
27065,  /* arao.kumamoto.jp */
 7303,  /* aso.kumamoto.jp */
27070,  /* choyo.kumamoto.jp */
27076,  /* gyokuto.kumamoto.jp */
27053,  /* kamiamakusa.kumamoto.jp */
27084,  /* kikuchi.kumamoto.jp */
 5510,  /* kumamoto.kumamoto.jp */
27092,  /* mashiki.kumamoto.jp */
27100,  /* mifune.kumamoto.jp */
27107,  /* minamata.kumamoto.jp */
27116,  /* minamioguni.kumamoto.jp */
27128,  /* nagasu.kumamoto.jp */
27135,  /* nishihara.kumamoto.jp */
27122,  /* oguni.kumamoto.jp */
23000,  /* ozu.kumamoto.jp */
25800,  /* sumoto.kumamoto.jp */
27145,  /* takamori.kumamoto.jp */
 7570,  /* uki.kumamoto.jp */
  630,  /* uto.kumamoto.jp */
27154,  /* yamaga.kumamoto.jp */
23923,  /* yamato.kumamoto.jp */
27161,  /* yatsushiro.kumamoto.jp */
24963,  /* ayabe.kyoto.jp */
27172,  /* fukuchiyama.kyoto.jp */
27184,  /* higashiyama.kyoto.jp */
 2272,  /* ide.kyoto.jp */
 5982,  /* ine.kyoto.jp */
27196,  /* joyo.kyoto.jp */
27201,  /* kameoka.kyoto.jp */
24065,  /* kamo.kyoto.jp */
20818,  /* kita.kyoto.jp */
27209,  /* kizu.kyoto.jp */
23334,  /* kumiyama.kyoto.jp */
25839,  /* kyotamba.kyoto.jp */
27214,  /* kyotanabe.kyoto.jp */
27224,  /* kyotango.kyoto.jp */
27233,  /* maizuru.kyoto.jp */
23320,  /* minami.kyoto.jp */
27241,  /* minamiyamashiro.kyoto.jp */
27257,  /* miyazu.kyoto.jp */
27264,  /* muko.kyoto.jp */
27269,  /* nagaokakyo.kyoto.jp */
27280,  /* nakagyo.kyoto.jp */
27288,  /* nantan.kyoto.jp */
27295,  /* oyamazaki.kyoto.jp */
27305,  /* sakyo.kyoto.jp */
27311,  /* seika.kyoto.jp */
27217,  /* tanabe.kyoto.jp */
 7212,  /* uji.kyoto.jp */
27317,  /* ujitawara.kyoto.jp */
27327,  /* wazuka.kyoto.jp */
27334,  /* yamashina.kyoto.jp */
27344,  /* yawata.kyoto.jp */
21966,  /* asahi.mie.jp */
27351,  /* inabe.mie.jp */
 2142,  /* ise.mie.jp */
27357,  /* kameyama.mie.jp */
27366,  /* kawagoe.mie.jp */
27374,  /* kiho.mie.jp */
27379,  /* kisosaki.mie.jp */
27388,  /* kiwa.mie.jp */
27393,  /* komono.mie.jp */
24535,  /* kumano.mie.jp */
27400,  /* kuwana.mie.jp */
27407,  /* matsusaka.mie.jp */
24296,  /* meiwa.mie.jp */
21894,  /* mihama.mie.jp */
27417,  /* minamiise.mie.jp */
27427,  /* misugi.mie.jp */
23336,  /* miyama.mie.jp */
17846,  /* nabari.mie.jp */
20869,  /* shima.mie.jp */
27434,  /* suzuka.mie.jp */
27441,  /* tado.mie.jp */
25443,  /* taiki.mie.jp */
22755,  /* taki.mie.jp */
27446,  /* tamaki.mie.jp */
27453,  /* toba.mie.jp */
 3288,  /* tsu.mie.jp */
23628,  /* udono.mie.jp */
27458,  /* ureshino.mie.jp */
27467,  /* watarai.mie.jp */
20804,  /* yokkaichi.mie.jp */
27475,  /* furukawa.miyagi.jp */
27484,  /* higashimatsushima.miyagi.jp */
27502,  /* ishinomaki.miyagi.jp */
27513,  /* iwanuma.miyagi.jp */
27521,  /* kakuda.miyagi.jp */
22313,  /* kami.miyagi.jp */
20967,  /* kawasaki.miyagi.jp */
27528,  /* marumori.miyagi.jp */
22078,  /* matsushima.miyagi.jp */
27537,  /* minamisanriku.miyagi.jp */
22221,  /* misato.miyagi.jp */
27551,  /* murata.miyagi.jp */
27558,  /* natori.miyagi.jp */
27565,  /* ogawara.miyagi.jp */
26548,  /* ohira.miyagi.jp */
27573,  /* onagawa.miyagi.jp */
22329,  /* osaki.miyagi.jp */
27581,  /* rifu.miyagi.jp */
27586,  /* semine.miyagi.jp */
27593,  /* shibata.miyagi.jp */
27601,  /* shichikashuku.miyagi.jp */
27615,  /* shikama.miyagi.jp */
27623,  /* shiogama.miyagi.jp */
27632,  /* shiroishi.miyagi.jp */
27642,  /* tagajo.miyagi.jp */
27649,  /* taiwa.miyagi.jp */
27658,  /* tome.miyagi.jp */
27663,  /* tomiya.miyagi.jp */
27670,  /* wakuya.miyagi.jp */
27677,  /* watari.miyagi.jp */
27684,  /* yamamoto.miyagi.jp */
27693,  /* zao.miyagi.jp */
22555,  /* aya.miyazaki.jp */
26919,  /* ebino.miyazaki.jp */
27703,  /* gokase.miyazaki.jp */
27710,  /* hyuga.miyazaki.jp */
27716,  /* kadogawa.miyazaki.jp */
27725,  /* kawaminami.miyazaki.jp */
27736,  /* kijo.miyazaki.jp */
23494,  /* kitagawa.miyazaki.jp */
23503,  /* kitakata.miyazaki.jp */
27741,  /* kitaura.miyazaki.jp */
27749,  /* kobayashi.miyazaki.jp */
27759,  /* kunitomi.miyazaki.jp */
20867,  /* kushima.miyazaki.jp */
27768,  /* mimata.miyazaki.jp */
23417,  /* miyakonojo.miyazaki.jp */
21006,  /* miyazaki.miyazaki.jp */
 6060,  /* morotsuka.miyazaki.jp */
27775,  /* nichinan.miyazaki.jp */
27784,  /* nishimera.miyazaki.jp */
27794,  /* nobeoka.miyazaki.jp */
27802,  /* saito.miyazaki.jp */
27808,  /* shiiba.miyazaki.jp */
27815,  /* shintomi.miyazaki.jp */
27824,  /* takaharu.miyazaki.jp */
27833,  /* takanabe.miyazaki.jp */
27842,  /* takazaki.miyazaki.jp */
22968,  /* tsuno.miyazaki.jp */
 3900,  /* achi.nagano.jp */
27858,  /* agematsu.nagano.jp */
27868,  /* anan.nagano.jp */
27873,  /* aoki.nagano.jp */
21966,  /* asahi.nagano.jp */
27878,  /* azumino.nagano.jp */
27886,  /* chikuhoku.nagano.jp */
27896,  /* chikuma.nagano.jp */
27904,  /* chino.nagano.jp */
27910,  /* fujimi.nagano.jp */
27917,  /* hakuba.nagano.jp */
22007,  /* hara.nagano.jp */
27924,  /* hiraya.nagano.jp */
27937,  /* iida.nagano.jp */
27942,  /* iijima.nagano.jp */
27949,  /* iiyama.nagano.jp */
27956,  /* iizuna.nagano.jp */
23085,  /* ikeda.nagano.jp */
27963,  /* ikusaka.nagano.jp */
 7246,  /* ina.nagano.jp */
27971,  /* karuizawa.nagano.jp */
27981,  /* kawakami.nagano.jp */
27990,  /* kiso.nagano.jp */
20861,  /* kisofukushima.nagano.jp */
27995,  /* kitaaiki.nagano.jp */
28004,  /* komagane.nagano.jp */
28013,  /* komoro.nagano.jp */
28020,  /* matsukawa.nagano.jp */
25797,  /* matsumoto.nagano.jp */
28030,  /* miasa.nagano.jp */
28036,  /* minamiaiki.nagano.jp */
28047,  /* minamimaki.nagano.jp */
28058,  /* minamiminowa.nagano.jp */
28064,  /* minowa.nagano.jp */
28071,  /* miyada.nagano.jp */
28078,  /* miyota.nagano.jp */
28085,  /* mochizuki.nagano.jp */
21022,  /* nagano.nagano.jp */
20960,  /* nagawa.nagano.jp */
28095,  /* nagiso.nagano.jp */
20939,  /* nakagawa.nagano.jp */
28102,  /* nakano.nagano.jp */
28109,  /* nozawaonsen.nagano.jp */
28121,  /* obuse.nagano.jp */
22562,  /* ogawa.nagano.jp */
27697,  /* okaya.nagano.jp */
28133,  /* omachi.nagano.jp */
22092,  /* omi.nagano.jp */
28140,  /* ookuwa.nagano.jp */
26275,  /* ooshika.nagano.jp */
22754,  /* otaki.nagano.jp */
28147,  /* otari.nagano.jp */
  154,  /* sakae.nagano.jp */
28153,  /* sakaki.nagano.jp */
28160,  /* saku.nagano.jp */
28165,  /* sakuho.nagano.jp */
28172,  /* shimosuwa.nagano.jp */
28127,  /* shinanomachi.nagano.jp */
28182,  /* shiojiri.nagano.jp */
28177,  /* suwa.nagano.jp */
28191,  /* suzaka.nagano.jp */
28198,  /* takagi.nagano.jp */
27145,  /* takamori.nagano.jp */
24150,  /* takayama.nagano.jp */
28205,  /* tateshina.nagano.jp */
25848,  /* tatsuno.nagano.jp */
28215,  /* togakushi.nagano.jp */
28225,  /* togura.nagano.jp */
22091,  /* tomi.nagano.jp */
28232,  /* ueda.nagano.jp */
22441,  /* wada.nagano.jp */
21702,  /* yamagata.nagano.jp */
28237,  /* yamanouchi.nagano.jp */
28248,  /* yasaka.nagano.jp */
28255,  /* yasuoka.nagano.jp */
28263,  /* chijiwa.nagasaki.jp */
25319,  /* futsu.nagasaki.jp */
28279,  /* goto.nagasaki.jp */
28284,  /* hasami.nagasaki.jp */
28291,  /* hirado.nagasaki.jp */
 8551,  /* iki.nagasaki.jp */
28298,  /* isahaya.nagasaki.jp */
28306,  /* kawatana.nagasaki.jp */
28315,  /* kuchinotsu.nagasaki.jp */
28326,  /* matsuura.nagasaki.jp */
21029,  /* nagasaki.nagasaki.jp */
23101,  /* obama.nagasaki.jp */
28335,  /* omura.nagasaki.jp */
21972,  /* oseto.nagasaki.jp */
28341,  /* saikai.nagasaki.jp */
28348,  /* sasebo.nagasaki.jp */
28355,  /* seihi.nagasaki.jp */
28361,  /* shimabara.nagasaki.jp */
28271,  /* shinkamigoto.nagasaki.jp */
28371,  /* togitsu.nagasaki.jp */
22080,  /* tsushima.nagasaki.jp */
28379,  /* unzen.nagasaki.jp */
25891,  /* ando.nara.jp */
28386,  /* gose.nara.jp */
11499,  /* heguri.nara.jp */
28391,  /* higashiyoshino.nara.jp */
28406,  /* ikaruga.nara.jp */
28414,  /* ikoma.nara.jp */
28420,  /* kamikitayama.nara.jp */
28433,  /* kanmaki.nara.jp */
28441,  /* kashiba.nara.jp */
28449,  /* kashihara.nara.jp */
28459,  /* katsuragi.nara.jp */
26391,  /* kawai.nara.jp */
27981,  /* kawakami.nara.jp */
25727,  /* kawanishi.nara.jp */
28469,  /* koryo.nara.jp */
22751,  /* kurotaki.nara.jp */
28477,  /* mitsue.nara.jp */
28484,  /* miyake.nara.jp */
19285,  /* nara.nara.jp */
28491,  /* nosegawa.nara.jp */
26359,  /* oji.nara.jp */
28500,  /* ouda.nara.jp */
28505,  /* oyodo.nara.jp */
28511,  /* sakurai.nara.jp */
28519,  /* sango.nara.jp */
28525,  /* shimoichi.nara.jp */
28535,  /* shimokitayama.nara.jp */
28549,  /* shinjo.nara.jp */
28556,  /* soni.nara.jp */
22576,  /* takatori.nara.jp */
28561,  /* tawaramoto.nara.jp */
28572,  /* tenkawa.nara.jp */
28580,  /* tenri.nara.jp */
26803,  /* uda.nara.jp */
23748,  /* yamatokoriyama.nara.jp */
28586,  /* yamatotakada.nara.jp */
28599,  /* yamazoe.nara.jp */
28398,  /* yoshino.nara.jp */
 3333,  /* aga.niigata.jp */
21023,  /* agano.niigata.jp */
28607,  /* gosen.niigata.jp */
28613,  /* itoigawa.niigata.jp */
28622,  /* izumozaki.niigata.jp */
28632,  /* joetsu.niigata.jp */
24065,  /* kamo.niigata.jp */
28639,  /* kariwa.niigata.jp */
28646,  /* kashiwazaki.niigata.jp */
28658,  /* minamiuonuma.niigata.jp */
28671,  /* mitsuke.niigata.jp */
28679,  /* muika.niigata.jp */
28685,  /* murakami.niigata.jp */
28694,  /* myoko.niigata.jp */
28700,  /* nagaoka.niigata.jp */
21038,  /* niigata.niigata.jp */
28708,  /* ojiya.niigata.jp */
22092,  /* omi.niigata.jp */
28714,  /* sado.niigata.jp */
21736,  /* sanjo.niigata.jp */
28719,  /* seiro.niigata.jp */
28725,  /* seirou.niigata.jp */
28732,  /* sekikawa.niigata.jp */
27593,  /* shibata.niigata.jp */
22196,  /* tagami.niigata.jp */
28741,  /* tainai.niigata.jp */
28748,  /* tochio.niigata.jp */
28755,  /* tokamachi.niigata.jp */
28765,  /* tsubame.niigata.jp */
28773,  /* tsunan.niigata.jp */
28664,  /* uonuma.niigata.jp */
28780,  /* yahiko.niigata.jp */
21046,  /* yoita.niigata.jp */
28787,  /* yuzawa.niigata.jp */
28794,  /* beppu.oita.jp */
28800,  /* bungoono.oita.jp */
28809,  /* bungotakada.oita.jp */
28821,  /* hasama.oita.jp */
28828,  /* hiji.oita.jp */
28833,  /* himeshima.oita.jp */
21756,  /* hita.oita.jp */
28475,  /* kamitsue.oita.jp */
28843,  /* kokonoe.oita.jp */
28851,  /* kuju.oita.jp */
28856,  /* kunisaki.oita.jp */
 7519,  /* kusu.oita.jp */
21047,  /* oita.oita.jp */
28865,  /* saiki.oita.jp */
28871,  /* taketa.oita.jp */
28878,  /* tsukumi.oita.jp */
19293,  /* usa.oita.jp */
28886,  /* usuki.oita.jp */
28892,  /* yufu.oita.jp */
28897,  /* akaiwa.okayama.jp */
28904,  /* asakuchi.okayama.jp */
28913,  /* bizen.okayama.jp */
28919,  /* hayashima.okayama.jp */
28931,  /* ibara.okayama.jp */
28937,  /* kagamino.okayama.jp */
28946,  /* kasaoka.okayama.jp */
22489,  /* kibichuo.okayama.jp */
28954,  /* kumenan.okayama.jp */
28962,  /* kurashiki.okayama.jp */
28972,  /* maniwa.okayama.jp */
28979,  /* misaki.okayama.jp */
22340,  /* nagi.okayama.jp */
28992,  /* niimi.okayama.jp */
28998,  /* nishiawakura.okayama.jp */
21052,  /* okayama.okayama.jp */
29011,  /* satosho.okayama.jp */
29019,  /* setouchi.okayama.jp */
28549,  /* shinjo.okayama.jp */
29028,  /* shoo.okayama.jp */
29033,  /* soja.okayama.jp */
29038,  /* takahashi.okayama.jp */
29048,  /* tamano.okayama.jp */
22983,  /* tsuyama.okayama.jp */
 4504,  /* wake.okayama.jp */
29055,  /* yakage.okayama.jp */
29065,  /* aguni.okinawa.jp */
29071,  /* ginowan.okinawa.jp */
29079,  /* ginoza.okinawa.jp */
29086,  /* gushikami.okinawa.jp */
29096,  /* haebaru.okinawa.jp */
23219,  /* higashi.okinawa.jp */
29104,  /* hirara.okinawa.jp */
29111,  /* iheya.okinawa.jp */
29117,  /* ishigaki.okinawa.jp */
20924,  /* ishikawa.okinawa.jp */
 5162,  /* itoman.okinawa.jp */
29126,  /* izena.okinawa.jp */
29132,  /* kadena.okinawa.jp */
 7275,  /* kin.okinawa.jp */
29139,  /* kitadaito.okinawa.jp */
29149,  /* kitanakagusuku.okinawa.jp */
29164,  /* kumejima.okinawa.jp */
29173,  /* kunigami.okinawa.jp */
29182,  /* minamidaito.okinawa.jp */
21933,  /* motobu.okinawa.jp */
29196,  /* nago.okinawa.jp */
12782,  /* naha.okinawa.jp */
29153,  /* nakagusuku.okinawa.jp */
29201,  /* nakijin.okinawa.jp */
29209,  /* nanjo.okinawa.jp */
27135,  /* nishihara.okinawa.jp */
29215,  /* ogimi.okinawa.jp */
 5911,  /* okinawa.okinawa.jp */
29222,  /* onna.okinawa.jp */
29227,  /* shimoji.okinawa.jp */
29235,  /* taketomi.okinawa.jp */
29244,  /* tarama.okinawa.jp */
29251,  /* tokashiki.okinawa.jp */
29261,  /* tomigusuku.okinawa.jp */
29272,  /* tonaki.okinawa.jp */
29279,  /* urasoe.okinawa.jp */
29286,  /* uruma.okinawa.jp */
29292,  /* yaese.okinawa.jp */
29298,  /* yomitan.okinawa.jp */
29306,  /* yonabaru.okinawa.jp */
29062,  /* yonaguni.okinawa.jp */
26630,  /* zamami.okinawa.jp */
29315,  /* abeno.osaka.jp */
29321,  /* chihayaakasaka.osaka.jp */
22493,  /* chuo.osaka.jp */
29143,  /* daito.osaka.jp */
29336,  /* fujiidera.osaka.jp */
29346,  /* habikino.osaka.jp */
29355,  /* hannan.osaka.jp */
29362,  /* higashiosaka.osaka.jp */
21901,  /* higashisumiyoshi.osaka.jp */
29375,  /* higashiyodogawa.osaka.jp */
29391,  /* hirakata.osaka.jp */
20915,  /* ibaraki.osaka.jp */
23085,  /* ikeda.osaka.jp */
24347,  /* izumi.osaka.jp */
29400,  /* izumiotsu.osaka.jp */
29410,  /* izumisano.osaka.jp */
29420,  /* kadoma.osaka.jp */
29427,  /* kaizuka.osaka.jp */
27867,  /* kanan.osaka.jp */
29435,  /* kashiwara.osaka.jp */
29445,  /* katano.osaka.jp */
21015,  /* kawachinagano.osaka.jp */
29452,  /* kishiwada.osaka.jp */
20818,  /* kita.osaka.jp */
29462,  /* kumatori.osaka.jp */
29471,  /* matsubara.osaka.jp */
29486,  /* minato.osaka.jp */
29493,  /* minoh.osaka.jp */
28979,  /* misaki.osaka.jp */
29499,  /* moriguchi.osaka.jp */
29509,  /* neyagawa.osaka.jp */
23381,  /* nishi.osaka.jp */
 7068,  /* nose.osaka.jp */
29518,  /* osakasayama.osaka.jp */
23118,  /* sakai.osaka.jp */
23238,  /* sayama.osaka.jp */
29530,  /* sennan.osaka.jp */
29537,  /* settsu.osaka.jp */
29544,  /* shijonawate.osaka.jp */
29556,  /* shimamoto.osaka.jp */
29566,  /* suita.osaka.jp */
29572,  /* tadaoka.osaka.jp */
25807,  /* taishi.osaka.jp */
29580,  /* tajiri.osaka.jp */
29587,  /* takaishi.osaka.jp */
29596,  /* takatsuki.osaka.jp */
29606,  /* tondabayashi.osaka.jp */
29619,  /* toyonaka.osaka.jp */
29628,  /* toyono.osaka.jp */
29635,  /* yao.osaka.jp */
29639,  /* ariake.saga.jp */
22711,  /* arita.saga.jp */
29646,  /* fukudomi.saga.jp */
29655,  /* genkai.saga.jp */
29662,  /* hamatama.saga.jp */
23071,  /* hizen.saga.jp */
29671,  /* imari.saga.jp */
29677,  /* kamimine.saga.jp */
29686,  /* kanzaki.saga.jp */
29694,  /* karatsu.saga.jp */
25993,  /* kashima.saga.jp */
24045,  /* kitagata.saga.jp */
29702,  /* kitahata.saga.jp */
29711,  /* kiyama.saga.jp */
29718,  /* kouhoku.saga.jp */
29726,  /* kyuragi.saga.jp */
29734,  /* nishiarita.saga.jp */
 3488,  /* ogi.saga.jp */
28133,  /* omachi.saga.jp */
24175,  /* ouchi.saga.jp */
 3332,  /* saga.saga.jp */
27632,  /* shiroishi.saga.jp */
29745,  /* taku.saga.jp */
22000,  /* tara.saga.jp */
24088,  /* tosu.saga.jp */
29750,  /* yoshinogari.saga.jp */
29762,  /* arakawa.saitama.jp */
28249,  /* asaka.saitama.jp */
29777,  /* chichibu.saitama.jp */
27910,  /* fujimi.saitama.jp */
29786,  /* fujimino.saitama.jp */
29795,  /* fukaya.saitama.jp */
29802,  /* hanno.saitama.jp */
29808,  /* hanyu.saitama.jp */
29814,  /* hasuda.saitama.jp */
29821,  /* hatogaya.saitama.jp */
29830,  /* hatoyama.saitama.jp */
24803,  /* hidaka.saitama.jp */
29770,  /* higashichichibu.saitama.jp */
22974,  /* higashimatsuyama.saitama.jp */
22156,  /* honjo.saitama.jp */
 7246,  /* ina.saitama.jp */
29839,  /* iruma.saitama.jp */
29845,  /* iwatsuki.saitama.jp */
29854,  /* kamiizumi.saitama.jp */
24919,  /* kamikawa.saitama.jp */
29864,  /* kamisato.saitama.jp */
29873,  /* kasukabe.saitama.jp */
27366,  /* kawagoe.saitama.jp */
29882,  /* kawaguchi.saitama.jp */
29892,  /* kawajima.saitama.jp */
29901,  /* kazo.saitama.jp */
29906,  /* kitamoto.saitama.jp */
29915,  /* koshigaya.saitama.jp */
29925,  /* kounosu.saitama.jp */
29933,  /* kuki.saitama.jp */
29938,  /* kumagaya.saitama.jp */
29947,  /* matsubushi.saitama.jp */
29958,  /* minano.saitama.jp */
22221,  /* misato.saitama.jp */
25869,  /* miyashiro.saitama.jp */
21910,  /* miyoshi.saitama.jp */
29965,  /* moroyama.saitama.jp */
29974,  /* nagatoro.saitama.jp */
29983,  /* namegawa.saitama.jp */
29992,  /* niiza.saitama.jp */
29998,  /* ogano.saitama.jp */
22562,  /* ogawa.saitama.jp */
28385,  /* ogose.saitama.jp */
30004,  /* okegawa.saitama.jp */
21810,  /* omiya.saitama.jp */
22754,  /* otaki.saitama.jp */
30012,  /* ranzan.saitama.jp */
26932,  /* ryokami.saitama.jp */
21060,  /* saitama.saitama.jp */
30019,  /* sakado.saitama.jp */
30026,  /* satte.saitama.jp */
23238,  /* sayama.saitama.jp */
21834,  /* shiki.saitama.jp */
30032,  /* shiraoka.saitama.jp */
30041,  /* soka.saitama.jp */
30046,  /* sugito.saitama.jp */
30053,  /* toda.saitama.jp */
30058,  /* tokigawa.saitama.jp */
30067,  /* tokorozawa.saitama.jp */
30078,  /* tsurugashima.saitama.jp */
30091,  /* urawa.saitama.jp */
30097,  /* warabi.saitama.jp */
30104,  /* yashio.saitama.jp */
30111,  /* yokoze.saitama.jp */
24429,  /* yono.saitama.jp */
30118,  /* yorii.saitama.jp */
30128,  /* yoshida.saitama.jp */
30136,  /* yoshikawa.saitama.jp */
30146,  /* yoshimi.saitama.jp */
30154,  /* aisho.shiga.jp */
17927,  /* gamo.shiga.jp */
30160,  /* higashiomi.shiga.jp */
30171,  /* hikone.shiga.jp */
30178,  /* koka.shiga.jp */
21888,  /* konan.shiga.jp */
30183,  /* kosei.shiga.jp */
23428,  /* koto.shiga.jp */
24279,  /* kusatsu.shiga.jp */
28929,  /* maibara.shiga.jp */
30189,  /* moriyama.shiga.jp */
30198,  /* nagahama.shiga.jp */
30207,  /* nishiazai.shiga.jp */
30217,  /* notogawa.shiga.jp */
30226,  /* omihachiman.shiga.jp */
23520,  /* otsu.shiga.jp */
30244,  /* ritto.shiga.jp */
30250,  /* ryuoh.shiga.jp */
25991,  /* takashima.shiga.jp */
29596,  /* takatsuki.shiga.jp */
30256,  /* torahime.shiga.jp */
30265,  /* toyosato.shiga.jp */
22841,  /* yasu.shiga.jp */
28199,  /* akagi.shimane.jp */
10725,  /* ama.shimane.jp */
30238,  /* gotsu.shimane.jp */
30274,  /* hamada.shimane.jp */
30281,  /* higashiizumo.shimane.jp */
20926,  /* hikawa.shimane.jp */
30294,  /* hikimi.shimane.jp */
30288,  /* izumo.shimane.jp */
30310,  /* kakinoki.shimane.jp */
30319,  /* masuda.shimane.jp */
23477,  /* matsue.shimane.jp */
22221,  /* misato.shimane.jp */
30326,  /* nishinoshima.shimane.jp */
30339,  /* ohda.shimane.jp */
30344,  /* okinoshima.shimane.jp */
30301,  /* okuizumo.shimane.jp */
21096,  /* shimane.shimane.jp */
30355,  /* tamayu.shimane.jp */
30362,  /* tsuwano.shimane.jp */
30370,  /* unnan.shimane.jp */
25605,  /* yakumo.shimane.jp */
30376,  /* yasugi.shimane.jp */
30383,  /* yatsuka.shimane.jp */
23489,  /* arai.shizuoka.jp */
25884,  /* atami.shizuoka.jp */
25310,  /* fuji.shizuoka.jp */
30391,  /* fujieda.shizuoka.jp */
30399,  /* fujikawa.shizuoka.jp */
30408,  /* fujinomiya.shizuoka.jp */
30419,  /* fukuroi.shizuoka.jp */
 5256,  /* gotemba.shizuoka.jp */
30427,  /* haibara.shizuoka.jp */
30435,  /* hamamatsu.shizuoka.jp */
30445,  /* higashiizu.shizuoka.jp */
 7900,  /* ito.shizuoka.jp */
30456,  /* iwata.shizuoka.jp */
23791,  /* izu.shizuoka.jp */
30462,  /* izunokuni.shizuoka.jp */
30472,  /* kakegawa.shizuoka.jp */
30481,  /* kannami.shizuoka.jp */
30489,  /* kawanehon.shizuoka.jp */
30499,  /* kawazu.shizuoka.jp */
30506,  /* kikugawa.shizuoka.jp */
30515,  /* kosai.shizuoka.jp */
30521,  /* makinohara.shizuoka.jp */
30532,  /* matsuzaki.shizuoka.jp */
30542,  /* minamiizu.shizuoka.jp */
23777,  /* mishima.shizuoka.jp */
30552,  /* morimachi.shizuoka.jp */
30562,  /* nishiizu.shizuoka.jp */
30571,  /* numazu.shizuoka.jp */
30578,  /* omaezaki.shizuoka.jp */
30587,  /* shimada.shizuoka.jp */
25014,  /* shimizu.shizuoka.jp */
 5440,  /* shimoda.shizuoka.jp */
21104,  /* shizuoka.shizuoka.jp */
30595,  /* susono.shizuoka.jp */
30602,  /* yaizu.shizuoka.jp */
30128,  /* yoshida.shizuoka.jp */
26217,  /* ashikaga.tochigi.jp */
12114,  /* bato.tochigi.jp */
30608,  /* haga.tochigi.jp */
30613,  /* ichikai.tochigi.jp */
30621,  /* iwafune.tochigi.jp */
30629,  /* kaminokawa.tochigi.jp */
30640,  /* kanuma.tochigi.jp */
30647,  /* karasuyama.tochigi.jp */
26851,  /* kuroiso.tochigi.jp */
30658,  /* mashiko.tochigi.jp */
30666,  /* mibu.tochigi.jp */
30671,  /* moka.tochigi.jp */
30676,  /* motegi.tochigi.jp */
30683,  /* nasu.tochigi.jp */
30688,  /* nasushiobara.tochigi.jp */
30701,  /* nikko.tochigi.jp */
30707,  /* nishikata.tochigi.jp */
 3487,  /* nogi.tochigi.jp */
26548,  /* ohira.tochigi.jp */
30717,  /* ohtawara.tochigi.jp */
21142,  /* oyama.tochigi.jp */
 6867,  /* sakura.tochigi.jp */
29415,  /* sano.tochigi.jp */
30726,  /* shimotsuke.tochigi.jp */
30737,  /* shioya.tochigi.jp */
30744,  /* takanezawa.tochigi.jp */
21113,  /* tochigi.tochigi.jp */
30755,  /* tsuga.tochigi.jp */
30761,  /* ujiie.tochigi.jp */
30767,  /* utsunomiya.tochigi.jp */
30778,  /* yaita.tochigi.jp */
26340,  /* aizumi.tokushima.jp */
27868,  /* anan.tokushima.jp */
20834,  /* ichiba.tokushima.jp */
30784,  /* itano.tokushima.jp */
22891,  /* kainan.tokushima.jp */
22076,  /* komatsushima.tokushima.jp */
30790,  /* matsushige.tokushima.jp */
30801,  /* mima.tokushima.jp */
23320,  /* minami.tokushima.jp */
21910,  /* miyoshi.tokushima.jp */
30806,  /* mugi.tokushima.jp */
20939,  /* nakagawa.tokushima.jp */
30811,  /* naruto.tokushima.jp */
30818,  /* sanagochi.tokushima.jp */
30828,  /* shishikui.tokushima.jp */
21121,  /* tokushima.tokushima.jp */
30838,  /* wajiki.tokushima.jp */
27851,  /* adachi.tokyo.jp */
30845,  /* akiruno.tokyo.jp */
30853,  /* akishima.tokyo.jp */
30862,  /* aogashima.tokyo.jp */
29762,  /* arakawa.tokyo.jp */
30872,  /* bunkyo.tokyo.jp */
24202,  /* chiyoda.tokyo.jp */
30879,  /* chofu.tokyo.jp */
22493,  /* chuo.tokyo.jp */
26040,  /* edogawa.tokyo.jp */
24466,  /* fuchu.tokyo.jp */
30885,  /* fussa.tokyo.jp */
30891,  /* hachijo.tokyo.jp */
30899,  /* hachioji.tokyo.jp */
30908,  /* hamura.tokyo.jp */
23303,  /* higashikurume.tokyo.jp */
30915,  /* higashimurayama.tokyo.jp */
23916,  /* higashiyamato.tokyo.jp */
22705,  /* hino.tokyo.jp */
30931,  /* hinode.tokyo.jp */
30938,  /* hinohara.tokyo.jp */
28986,  /* inagi.tokyo.jp */
30947,  /* itabashi.tokyo.jp */
30956,  /* katsushika.tokyo.jp */
20818,  /* kita.tokyo.jp */
30967,  /* kiyose.tokyo.jp */
30974,  /* kodaira.tokyo.jp */
30982,  /* koganei.tokyo.jp */
30990,  /* kokubunji.tokyo.jp */
31000,  /* komae.tokyo.jp */
23428,  /* koto.tokyo.jp */
31006,  /* kouzushima.tokyo.jp */
31017,  /* kunitachi.tokyo.jp */
23985,  /* machida.tokyo.jp */
31027,  /* meguro.tokyo.jp */
29486,  /* minato.tokyo.jp */
25814,  /* mitaka.tokyo.jp */
31034,  /* mizuho.tokyo.jp */
31041,  /* musashimurayama.tokyo.jp */
31057,  /* musashino.tokyo.jp */
28102,  /* nakano.tokyo.jp */
31067,  /* nerima.tokyo.jp */
31074,  /* ogasawara.tokyo.jp */
31084,  /* okutama.tokyo.jp */
 1689,  /* ome.tokyo.jp */
20893,  /* oshima.tokyo.jp */
 7962,  /* ota.tokyo.jp */
31105,  /* setagaya.tokyo.jp */
31114,  /* shibuya.tokyo.jp */
25693,  /* shinagawa.tokyo.jp */
31122,  /* shinjuku.tokyo.jp */
31131,  /* suginami.tokyo.jp */
31140,  /* sumida.tokyo.jp */
31147,  /* tachikawa.tokyo.jp */
31157,  /* taito.tokyo.jp */
21063,  /* tama.tokyo.jp */
31097,  /* toshima.tokyo.jp */
31163,  /* chizu.tottori.jp */
22705,  /* hino.tottori.jp */
31169,  /* kawahara.tottori.jp */
 3435,  /* koge.tottori.jp */
31178,  /* kotoura.tottori.jp */
31186,  /* misasa.tottori.jp */
31193,  /* nanbu.tottori.jp */
27775,  /* nichinan.tottori.jp */
29481,  /* sakaiminato.tottori.jp */
21131,  /* tottori.tottori.jp */
23132,  /* wakasa.tottori.jp */
27259,  /* yazu.tottori.jp */
29194,  /* yonago.tottori.jp */
21966,  /* asahi.toyama.jp */
24466,  /* fuchu.toyama.jp */
31199,  /* fukumitsu.toyama.jp */
31209,  /* funahashi.toyama.jp */
30149,  /* himi.toyama.jp */
25016,  /* imizu.toyama.jp */
23321,  /* inami.toyama.jp */
31219,  /* johana.toyama.jp */
31226,  /* kamiichi.toyama.jp */
31235,  /* kurobe.toyama.jp */
31242,  /* nakaniikawa.toyama.jp */
31254,  /* namerikawa.toyama.jp */
31265,  /* nanto.toyama.jp */
31271,  /* nyuzen.toyama.jp */
31278,  /* oyabe.toyama.jp */
31284,  /* taira.toyama.jp */
31290,  /* takaoka.toyama.jp */
22813,  /* tateyama.toyama.jp */
31298,  /* toga.toyama.jp */
31303,  /* tonami.toyama.jp */
21141,  /* toyama.toyama.jp */
31310,  /* unazuki.toyama.jp */
22999,  /* uozu.toyama.jp */
23544,  /* yamada.toyama.jp */
31318,  /* arida.wakayama.jp */
31324,  /* aridagawa.wakayama.jp */
31334,  /* gobo.wakayama.jp */
31339,  /* hashimoto.wakayama.jp */
24803,  /* hidaka.wakayama.jp */
31349,  /* hirogawa.wakayama.jp */
23321,  /* inami.wakayama.jp */
31358,  /* iwade.wakayama.jp */
22891,  /* kainan.wakayama.jp */
31364,  /* kamitonda.wakayama.jp */
28459,  /* katsuragi.wakayama.jp */
24054,  /* kimino.wakayama.jp */
31374,  /* kinokawa.wakayama.jp */
28424,  /* kitayama.wakayama.jp */
31383,  /* koya.wakayama.jp */
10736,  /* koza.wakayama.jp */
31388,  /* kozagawa.wakayama.jp */
31397,  /* kudoyama.wakayama.jp */
31406,  /* kushimoto.wakayama.jp */
21894,  /* mihama.wakayama.jp */
22221,  /* misato.wakayama.jp */
22585,  /* nachikatsuura.wakayama.jp */
23450,  /* shingu.wakayama.jp */
31416,  /* shirahama.wakayama.jp */
31426,  /* taiji.wakayama.jp */
27217,  /* tanabe.wakayama.jp */
21148,  /* wakayama.wakayama.jp */
31432,  /* yuasa.wakayama.jp */
31438,  /* yura.wakayama.jp */
21966,  /* asahi.yamagata.jp */
31443,  /* funagata.yamagata.jp */
31452,  /* higashine.yamagata.jp */
 2271,  /* iide.yamagata.jp */
26226,  /* kahoku.yamagata.jp */
31462,  /* kaminoyama.yamagata.jp */
23711,  /* kaneyama.yamagata.jp */
25727,  /* kawanishi.yamagata.jp */
31473,  /* mamurogawa.yamagata.jp */
24921,  /* mikawa.yamagata.jp */
30922,  /* murayama.yamagata.jp */
31484,  /* nagai.yamagata.jp */
31490,  /* nakayama.yamagata.jp */
31499,  /* nanyo.yamagata.jp */
20923,  /* nishikawa.yamagata.jp */
31505,  /* obanazawa.yamagata.jp */
 5449,  /* oe.yamagata.jp */
27122,  /* oguni.yamagata.jp */
31515,  /* ohkura.yamagata.jp */
31522,  /* oishida.yamagata.jp */
31530,  /* sagae.yamagata.jp */
31536,  /* sakata.yamagata.jp */
31543,  /* sakegawa.yamagata.jp */
28549,  /* shinjo.yamagata.jp */
31552,  /* shirataka.yamagata.jp */
22898,  /* shonai.yamagata.jp */
31562,  /* takahata.yamagata.jp */
31571,  /* tendo.yamagata.jp */
31577,  /* tozawa.yamagata.jp */
31584,  /* tsuruoka.yamagata.jp */
21702,  /* yamagata.yamagata.jp */
31593,  /* yamanobe.yamagata.jp */
31602,  /* yonezawa.yamagata.jp */
31611,  /* yuza.yamagata.jp */
24662,  /* abu.yamaguchi.jp */
26118,  /* hagi.yamaguchi.jp */
22873,  /* hikari.yamaguchi.jp */
30880,  /* hofu.yamaguchi.jp */
31616,  /* iwakuni.yamaguchi.jp */
31624,  /* kudamatsu.yamaguchi.jp */
31634,  /* mitou.yamaguchi.jp */
31640,  /* nagato.yamaguchi.jp */
20893,  /* oshima.yamaguchi.jp */
31647,  /* shimonoseki.yamaguchi.jp */
31659,  /* shunan.yamaguchi.jp */
31666,  /* tabuse.yamaguchi.jp */
31673,  /* tokuyama.yamaguchi.jp */
 7959,  /* toyota.yamaguchi.jp */
 8052,  /* ube.yamaguchi.jp */
31682,  /* yuu.yamaguchi.jp */
22493,  /* chuo.yamanashi.jp */
31686,  /* doshi.yamanashi.jp */
31692,  /* fuefuki.yamanashi.jp */
30399,  /* fujikawa.yamanashi.jp */
23028,  /* fujikawaguchiko.yamanashi.jp */
30124,  /* fujiyoshida.yamanashi.jp */
31700,  /* hayakawa.yamanashi.jp */
24850,  /* hokuto.yamanashi.jp */
31709,  /* ichikawamisato.yamanashi.jp */
22038,  /* kai.yamanashi.jp */
31724,  /* kofu.yamanashi.jp */
26452,  /* koshu.yamanashi.jp */
31729,  /* kosuge.yamanashi.jp */
31736,  /* minami-alps.yamanashi.jp */
31748,  /* minobu.yamanashi.jp */
31755,  /* nakamichi.yamanashi.jp */
31193,  /* nanbu.yamanashi.jp */
31765,  /* narusawa.yamanashi.jp */
31774,  /* nirasaki.yamanashi.jp */
31783,  /* nishikatsura.yamanashi.jp */
28399,  /* oshino.yamanashi.jp */
26998,  /* otsuki.yamanashi.jp */
23857,  /* showa.yamanashi.jp */
31796,  /* tabayama.yamanashi.jp */
31805,  /* tsuru.yamanashi.jp */
31811,  /* uenohara.yamanashi.jp */
31820,  /* yamanakako.yamanashi.jp */
21721,  /* yamanashi.yamanashi.jp */
  986,  /* biz.ki */
 1910,  /* com.ki */
 2622,  /* edu.ki */
 3665,  /* gov.ki */
 3149,  /* info.ki */
 5710,  /* net.ki */
 6026,  /* org.ki */
 3527,  /* ass.km */
11821,  /* asso.km */
 1910,  /* com.km */
 2044,  /* coop.km */
 2622,  /* edu.km */
11834,  /* gouv.km */
 3665,  /* gov.km */
16791,  /* medecin.km */
 4157,  /* mil.km */
 5943,  /* nom.km */
16799,  /* notaires.km */
 6026,  /* org.km */
31831,  /* pharmaciens.km */
16819,  /* prd.km */
12688,  /* presse.km */
 7890,  /* tm.km */
16823,  /* veterinaire.km */
 2622,  /* edu.kn */
 3665,  /* gov.kn */
 5710,  /* net.kn */
 6026,  /* org.kn */
 1910,  /* com.kp */
 2622,  /* edu.kp */
 3665,  /* gov.kp */
 6026,  /* org.kp */
31843,  /* rep.kp */
18321,  /* tra.kp */
   62,  /* ac.kr */
10791,  /* blogspot.kr */
31853,  /* busan.kr */
31859,  /* chungbuk.kr */
31868,  /* chungnam.kr */
  113,  /* co.kr */
31877,  /* daegu.kr */
31883,  /* daejeon.kr */
  558,  /* es.kr */
31891,  /* gangwon.kr */
  257,  /* go.kr */
31899,  /* gwangju.kr */
31907,  /* gyeongbuk.kr */
31917,  /* gyeonggi.kr */
31926,  /* gyeongnam.kr */
 9305,  /* hs.kr */
31940,  /* incheon.kr */
31948,  /* jeju.kr */
 8110,  /* jeonbuk.kr */
31953,  /* jeonnam.kr */
 4544,  /* kg.kr */
 4157,  /* mil.kr */
 1060,  /* ms.kr */
 1198,  /* ne.kr */
  137,  /* or.kr */
 3718,  /* pe.kr */
   80,  /* re.kr */
 2155,  /* sc.kr */
31961,  /* seoul.kr */
18033,  /* ulsan.kr */
  113,  /* co.krd */
 2622,  /* edu.krd */
 1910,  /* com.kz */
 2622,  /* edu.kz */
 3665,  /* gov.kz */
 4157,  /* mil.kz */
 5710,  /* net.kz */
12575,  /* nym.kz */
 6026,  /* org.kz */
 5856,  /* bnr.la */
   36,  /* c.la */
 1910,  /* com.la */
 2622,  /* edu.la */
 3665,  /* gov.la */
 3149,  /* info.la */
 3611,  /* int.la */
 5710,  /* net.la */
12575,  /* nym.la */
 6026,  /* org.la */
 4488,  /* per.la */
 2379,  /* dev.static.land */
31982,  /* sites.static.land */
  113,  /* co.lc */
 1910,  /* com.lc */
 2622,  /* edu.lc */
 3665,  /* gov.lc */
 5710,  /* net.lc */
12575,  /* nym.lc */
 6026,  /* org.lc */
 4457,  /* oy.lc */
10791,  /* blogspot.li */
 5943,  /* nom.li */
12575,  /* nym.li */
31988,  /* cyon.link */
31993,  /* mypep.link */
   62,  /* ac.lk */
31999,  /* assn.lk */
 1910,  /* com.lk */
 2622,  /* edu.lk */
 3665,  /* gov.lk */
32004,  /* grp.lk */
 7728,  /* hotel.lk */
 3611,  /* int.lk */
 5070,  /* ltd.lk */
 5710,  /* net.lk */
  977,  /* ngo.lk */
 6026,  /* org.lk */
 1140,  /* sch.lk */
32008,  /* soc.lk */
12075,  /* web.lk */
10791,  /* blogspot.lu */
12575,  /* nym.lu */
 7299,  /* asn.lv */
 1910,  /* com.lv */
11613,  /* conf.lv */
 2622,  /* edu.lv */
 3665,  /* gov.lv */
  437,  /* id.lv */
 4157,  /* mil.lv */
 5710,  /* net.lv */
 6026,  /* org.lv */
 1910,  /* com.ly */
 2622,  /* edu.ly */
 3665,  /* gov.ly */
  437,  /* id.ly */
 1855,  /* med.ly */
 5710,  /* net.ly */
 6026,  /* org.ly */
 4825,  /* plc.ly */
 1140,  /* sch.ly */
   62,  /* ac.ma */
  113,  /* co.ma */
 3665,  /* gov.ma */
 5710,  /* net.ma */
 6026,  /* org.ma */
  371,  /* press.ma */
16352,  /* router.management */
11821,  /* asso.mc */
 7890,  /* tm.mc */
32114,  /* localhost.daplie.me */
11692,  /* barsy.menu */
  113,  /* co.mg */
 1910,  /* com.mg */
 2622,  /* edu.mg */
 3665,  /* gov.mg */
 4157,  /* mil.mg */
 5943,  /* nom.mg */
 6026,  /* org.mg */
16819,  /* prd.mg */
 7890,  /* tm.mg */
10791,  /* blogspot.mk */
 1910,  /* com.mk */
 2622,  /* edu.mk */
 3665,  /* gov.mk */
 5769,  /* inf.mk */
 5672,  /* name.mk */
 5710,  /* net.mk */
 5943,  /* nom.mk */
 6026,  /* org.mk */
 1910,  /* com.ml */
 2622,  /* edu.ml */
11834,  /* gouv.ml */
 3665,  /* gov.ml */
 5710,  /* net.ml */
 6026,  /* org.ml */
12688,  /* presse.ml */
 2622,  /* edu.mn */
 3665,  /* gov.mn */
 5878,  /* nyc.mn */
12575,  /* nym.mn */
 6026,  /* org.mn */
11692,  /* barsy.mobi */
11725,  /* dscloud.mobi */
10791,  /* blogspot.mr */
 3665,  /* gov.mr */
   62,  /* ac.mu */
  113,  /* co.mu */
 1910,  /* com.mu */
 3665,  /* gov.mu */
 5710,  /* net.mu */
  137,  /* or.mu */
 6026,  /* org.mu */
   65,  /* academy.museum */
32124,  /* agriculture.museum */
 3800,  /* air.museum */
32136,  /* airguard.museum */
32145,  /* alabama.museum */
32153,  /* alaska.museum */
32160,  /* amber.museum */
10943,  /* ambulance.museum */
32172,  /* american.museum */
32181,  /* americana.museum */
32191,  /* americanantiques.museum */
32208,  /* americanart.museum */
  412,  /* amsterdam.museum */
  726,  /* and.museum */
32226,  /* annefrank.museum */
32236,  /* anthro.museum */
32243,  /* anthropology.museum */
32199,  /* antiques.museum */
32267,  /* aquarium.museum */
32276,  /* arboretum.museum */
32286,  /* archaeological.museum */
32301,  /* archaeology.museum */
32313,  /* architecture.museum */
  527,  /* art.museum */
 2364,  /* artanddesign.museum */
 1585,  /* artcenter.museum */
32326,  /* artdeco.museum */
 2626,  /* arteducation.museum */
 3343,  /* artgallery.museum */
 6118,  /* arts.museum */
32334,  /* artsandcrafts.museum */
32348,  /* asmatart.museum */
32357,  /* assassination.museum */
32371,  /* assisi.museum */
10973,  /* association.museum */
32378,  /* astronomy.museum */
32388,  /* atlanta.museum */
32396,  /* austin.museum */
32403,  /* australia.museum */
32413,  /* automotive.museum */
11046,  /* aviation.museum */
32424,  /* axis.museum */
32429,  /* badajoz.museum */
 2208,  /* baghdad.museum */
32442,  /* bahn.museum */
18773,  /* bale.museum */
32447,  /* baltimore.museum */
  740,  /* barcelona.museum */
  789,  /* baseball.museum */
32457,  /* basel.museum */
32463,  /* baths.museum */
32469,  /* bauern.museum */
32476,  /* beauxarts.museum */
32486,  /* beeldengeluid.museum */
32500,  /* bellevue.museum */
32509,  /* bergbau.museum */
32517,  /* berkeley.museum */
  894,  /* berlin.museum */
32526,  /* bern.museum */
  951,  /* bible.museum */
32531,  /* bilbao.museum */
32538,  /* bill.museum */
32543,  /* birdart.museum */
 6278,  /* birthplace.museum */
32551,  /* bonn.museum */
 1151,  /* boston.museum */
32556,  /* botanical.museum */
32566,  /* botanicalgarden.museum */
32582,  /* botanicgarden.museum */
32596,  /* botany.museum */
32603,  /* brandywinevalley.museum */
32620,  /* brasil.museum */
32627,  /* bristol.museum */
32635,  /* british.museum */
32643,  /* britishcolumbia.museum */
32659,  /* broadcast.museum */
32669,  /* brunel.museum */
32676,  /* brussel.museum */
 1225,  /* brussels.museum */
32684,  /* bruxelles.museum */
32694,  /* building.museum */
32703,  /* burghof.museum */
  263,  /* bus.museum */
32711,  /* bushey.museum */
32718,  /* cadaques.museum */
32727,  /* california.museum */
32738,  /* cambridge.museum */
 6679,  /* can.museum */
32748,  /* canada.museum */
32755,  /* capebreton.museum */
32766,  /* carrier.museum */
32774,  /* cartoonart.museum */
32785,  /* casadelamoneda.museum */
32800,  /* castle.museum */
32807,  /* castres.museum */
32815,  /* celtic.museum */
 1588,  /* center.museum */
32822,  /* chattanooga.museum */
32834,  /* cheltenham.museum */
32845,  /* chesapeakebay.museum */
32859,  /* chicago.museum */
32867,  /* children.museum */
32876,  /* childrens.museum */
32886,  /* childrensgarden.museum */
32902,  /* chiropractic.museum */
32915,  /* chocolate.museum */
32925,  /* christiansburg.museum */
32940,  /* cincinnati.museum */
32951,  /* cinema.museum */
32958,  /* circus.museum */
32965,  /* civilisation.museum */
32978,  /* civilization.museum */
32991,  /* civilwar.museum */
33000,  /* clinton.museum */
33016,  /* clock.museum */
  288,  /* coal.museum */
33022,  /* coastaldefence.museum */
16638,  /* cody.museum */
33037,  /* coldwar.museum */
33045,  /* collection.museum */
33056,  /* colonialwilliamsburg.museum */
33077,  /* coloradoplateau.museum */
32650,  /* columbia.museum */
33093,  /* columbus.museum */
33102,  /* communication.museum */
33130,  /* communications.museum */
 1931,  /* community.museum */
 1949,  /* computer.museum */
33145,  /* computerhistory.museum */
33161,  /* contemporary.museum */
33174,  /* contemporaryart.museum */
33190,  /* convent.museum */
33198,  /* copenhagen.museum */
33209,  /* corporation.museum */
33221,  /* corvette.museum */
33230,  /* costume.museum */
33240,  /* countryestate.museum */
33254,  /* county.museum */
32341,  /* crafts.museum */
33261,  /* cranbrook.museum */
11337,  /* creation.museum */
33271,  /* cultural.museum */
33280,  /* culturalcenter.museum */
32128,  /* culture.museum */
33305,  /* cyber.museum */
 2184,  /* cymru.museum */
33319,  /* dali.museum */
33324,  /* dallas.museum */
33331,  /* database.museum */
11491,  /* ddr.museum */
33342,  /* decorativearts.museum */
33364,  /* delaware.museum */
33373,  /* delmenhorst.museum */
33385,  /* denmark.museum */
 3961,  /* depot.museum */
 2370,  /* design.museum */
33393,  /* detroit.museum */
33401,  /* dinosaur.museum */
33410,  /* discovery.museum */
33420,  /* dolls.museum */
33426,  /* donostia.museum */
33435,  /* durham.museum */
  213,  /* eastafrica.museum */
33442,  /* eastcoast.museum */
 2629,  /* education.museum */
33452,  /* educational.museum */
33464,  /* egyptian.museum */
32437,  /* eisenbahn.museum */
19340,  /* elburg.museum */
33473,  /* elvendrell.museum */
33484,  /* embroidery.museum */
33495,  /* encyclopedic.museum */
33508,  /* england.museum */
33516,  /* entomology.museum */
33527,  /* environment.museum */
33539,  /* environmentalconservation.museum */
33565,  /* epilepsy.museum */
 7125,  /* essex.museum */
 2767,  /* estate.museum */
33574,  /* ethnology.museum */
33584,  /* exeter.museum */
33591,  /* exhibition.museum */
  385,  /* family.museum */
 2932,  /* farm.museum */
 2719,  /* farmequipment.museum */
 2937,  /* farmers.museum */
33602,  /* farmstead.museum */
33612,  /* field.museum */
33618,  /* figueres.museum */
33627,  /* filatelia.museum */
 3015,  /* film.museum */
33637,  /* fineart.museum */
33645,  /* finearts.museum */
33654,  /* finland.museum */
33662,  /* flanders.museum */
33671,  /* florida.museum */
  270,  /* force.museum */
33679,  /* fortmissoula.museum */
33692,  /* fortworth.museum */
 3211,  /* foundation.museum */
33702,  /* francaise.museum */
33712,  /* frankfurt.museum */
33722,  /* franziskaner.museum */
33735,  /* freemasonry.museum */
33747,  /* freiburg.museum */
33756,  /* fribourg.museum */
33765,  /* frog.museum */
33770,  /* fundacio.museum */
 3311,  /* furniture.museum */
 3346,  /* gallery.museum */
 3396,  /* garden.museum */
13577,  /* gateway.museum */
33779,  /* geelvinck.museum */
33789,  /* gemological.museum */
33801,  /* geology.museum */
33809,  /* georgia.museum */
33817,  /* giessen.museum */
33825,  /* glas.museum */
 3525,  /* glass.museum */
33830,  /* gorge.museum */
33836,  /* grandrapids.museum */
33848,  /* graz.museum */
33853,  /* guernsey.museum */
33862,  /* halloffame.museum */
 3804,  /* hamburg.museum */
33873,  /* handson.museum */
33881,  /* harvestcelebration.museum */
33900,  /* hawaii.museum */
 3838,  /* health.museum */
33907,  /* heimatunduhren.museum */
33922,  /* hellas.museum */
 3850,  /* helsinki.museum */
33929,  /* hembygdsforbund.museum */
33953,  /* heritage.museum */
33962,  /* histoire.museum */
33971,  /* historical.museum */
33982,  /* historicalsociety.museum */
34000,  /* historichouses.museum */
34015,  /* historisch.museum */
34031,  /* historisches.museum */
33153,  /* history.museum */
 7023,  /* historyofscience.museum */
34054,  /* horology.museum */
 4077,  /* house.museum */
34063,  /* humanities.museum */
34074,  /* illustration.museum */
34087,  /* imageandsound.museum */
34101,  /* indian.museum */
34108,  /* indiana.museum */
34116,  /* indianapolis.museum */
 5190,  /* indianmarket.museum */
34129,  /* intelligence.museum */
  116,  /* interactive.museum */
  478,  /* iraq.museum */
34142,  /* iron.museum */
34147,  /* isleofman.museum */
34157,  /* jamison.museum */
34165,  /* jefferson.museum */
34175,  /* jerusalem.museum */
 4404,  /* jewelry.museum */
34185,  /* jewish.museum */
34192,  /* jewishart.museum */
 3099,  /* jfk.museum */
34202,  /* journalism.museum */
34213,  /* judaica.museum */
34221,  /* judygarland.museum */
34233,  /* juedisches.museum */
34244,  /* juif.museum */
34249,  /* karate.museum */
11472,  /* karikatur.museum */
34256,  /* kids.museum */
 8340,  /* koebenhavn.museum */
 4601,  /* koeln.museum */
34261,  /* kunst.museum */
34267,  /* kunstsammlung.museum */
34281,  /* kunstunddesign.museum */
34296,  /* labor.museum */
34302,  /* labour.museum */
34309,  /* lajolla.museum */
34317,  /* lancashire.museum */
34328,  /* landes.museum */
34335,  /* lans.museum */
34340,  /* larsson.museum */
34348,  /* lewismiller.museum */
 4939,  /* lincoln.museum */
 5882,  /* linz.museum */
 4977,  /* living.museum */
34362,  /* livinghistory.museum */
34376,  /* localhistory.museum */
 5031,  /* london.museum */
34389,  /* losangeles.museum */
34400,  /* louvre.museum */
34407,  /* loyalist.museum */
34416,  /* lucerne.museum */
34424,  /* luxembourg.museum */
34435,  /* luzern.museum */
  140,  /* mad.museum */
 5127,  /* madrid.museum */
34442,  /* mallorca.museum */
34451,  /* manchester.museum */
34462,  /* mansion.museum */
34470,  /* mansions.museum */
12828,  /* manx.museum */
34479,  /* marburg.museum */
34487,  /* maritime.museum */
34496,  /* maritimo.museum */
34505,  /* maryland.museum */
34514,  /* marylhurst.museum */
 5294,  /* media.museum */
 1310,  /* medical.museum */
34525,  /* medizinhistorisches.museum */
34545,  /* meeres.museum */
 5320,  /* memorial.museum */
34552,  /* mesaverde.museum */
34562,  /* michigan.museum */
34571,  /* midatlantic.museum */
34583,  /* military.museum */
34596,  /* mill.museum */
34601,  /* miners.museum */
34608,  /* mining.museum */
34615,  /* minnesota.museum */
34625,  /* missile.museum */
33683,  /* missoula.museum */
34633,  /* modern.museum */
34640,  /* moma.museum */
 5467,  /* money.museum */
34645,  /* monmouth.museum */
34654,  /* monticello.museum */
34665,  /* montreal.museum */
 5503,  /* moscow.museum */
34674,  /* motorcycle.museum */
34685,  /* muenchen.museum */
34694,  /* muenster.museum */
 4074,  /* mulhouse.museum */
34703,  /* muncie.museum */
34710,  /* museet.museum */
34717,  /* museumcenter.museum */
34730,  /* museumvereniging.museum */
19406,  /* music.museum */
 4279,  /* national.museum */
34747,  /* nationalfirearms.museum */
33945,  /* nationalheritage.museum */
32166,  /* nativeamerican.museum */
34764,  /* naturalhistory.museum */
 5582,  /* naturalhistorymuseum.museum */
34779,  /* naturalsciences.museum */
34795,  /* nature.museum */
34026,  /* naturhistorisches.museum */
34802,  /* natuurwetenschappen.museum */
34822,  /* naumburg.museum */
34831,  /* naval.museum */
34837,  /* nebraska.museum */
 2753,  /* neues.museum */
34846,  /* newhampshire.museum */
34859,  /* newjersey.museum */
34869,  /* newmexico.museum */
34879,  /* newport.museum */
34887,  /* newspaper.museum */
34897,  /* newyork.museum */
34905,  /* niepce.museum */
34912,  /* norfolk.museum */
34920,  /* north.museum */
 5866,  /* nrw.museum */
34926,  /* nuernberg.museum */
34936,  /* nuremberg.museum */
 5878,  /* nyc.museum */
34946,  /* nyny.museum */
34951,  /* oceanographic.museum */
34965,  /* oceanographique.museum */
34981,  /* omaha.museum */
 5979,  /* online.museum */
34987,  /* ontario.museum */
34995,  /* openair.museum */
35003,  /* oregon.museum */
35010,  /* oregontrail.museum */
35022,  /* otago.museum */
 3184,  /* oxford.museum */
35028,  /* pacific.museum */
35036,  /* paderborn.museum */
35046,  /* palace.museum */
35053,  /* paleo.museum */
35059,  /* palmsprings.museum */
35071,  /* panama.museum */
 6097,  /* paris.museum */
35078,  /* pasadena.museum */
 6160,  /* pharmacy.museum */
35087,  /* philadelphia.museum */
35100,  /* philadelphiaarea.museum */
35117,  /* philately.museum */
35127,  /* phoenix.museum */
 6187,  /* photography.museum */
35135,  /* pilots.museum */
 3476,  /* pittsburgh.museum */
35142,  /* planetarium.museum */
35154,  /* plantation.museum */
35165,  /* plants.museum */
35172,  /* plaza.museum */
35178,  /* portal.museum */
35185,  /* portland.museum */
35194,  /* portlligat.museum */
33116,  /* posts-and-telecommunications.museum */
35205,  /* preservation.museum */
35218,  /* presidio.museum */
  371,  /* press.museum */
35233,  /* project.museum */
  711,  /* public.museum */
35241,  /* pubol.museum */
 6496,  /* quebec.museum */
35247,  /* railroad.museum */
35256,  /* railway.museum */
 1377,  /* research.museum */
35264,  /* resistance.museum */
35275,  /* riodejaneiro.museum */
35288,  /* rochester.museum */
35298,  /* rockart.museum */
19349,  /* roma.museum */
35306,  /* russia.museum */
35313,  /* saintlouis.museum */
34179,  /* salem.museum */
33311,  /* salvadordali.museum */
35324,  /* salzburg.museum */
35333,  /* sandiego.museum */
 1729,  /* sanfrancisco.museum */
35342,  /* santabarbara.museum */
35355,  /* santacruz.museum */
35365,  /* santafe.museum */
35373,  /* saskatchewan.museum */
35386,  /* satx.museum */
35391,  /* savannahga.museum */
35402,  /* schlesisches.museum */
35415,  /* schoenbrunn.museum */
35427,  /* schokoladen.museum */
 7001,  /* school.museum */
35439,  /* schweiz.museum */
 7032,  /* science.museum */
35447,  /* science-fiction.museum */
35463,  /* scienceandhistory.museum */
35481,  /* scienceandindustry.museum */
35500,  /* sciencecenter.museum */
35514,  /* sciencecenters.museum */
35529,  /* sciencehistory.museum */
34786,  /* sciences.museum */
35544,  /* sciencesnaturelles.museum */
35563,  /* scotland.museum */
35572,  /* seaport.museum */
35580,  /* settlement.museum */
35591,  /* settlers.museum */
 7175,  /* shell.museum */
35600,  /* sherbrooke.museum */
35611,  /* sibenik.museum */
 7237,  /* silk.museum */
 4550,  /* ski.museum */
35619,  /* skole.museum */
33992,  /* society.museum */
35625,  /* sologne.museum */
35633,  /* soundandvision.museum */
35648,  /* southcarolina.museum */
35662,  /* southwest.museum */
 2873,  /* space.museum */
 6473,  /* spy.museum */
35672,  /* square.museum */
35679,  /* stadt.museum */
35685,  /* stalbans.museum */
35694,  /* starnberg.museum */
  331,  /* state.museum */
33357,  /* stateofdelaware.museum */
 6298,  /* station.museum */
 7711,  /* steam.museum */
35704,  /* steiermark.museum */
 3926,  /* stjohn.museum */
 7475,  /* stockholm.museum */
35715,  /* stpetersburg.museum */
35728,  /* stuttgart.museum */
35738,  /* suisse.museum */
35745,  /* surgeonshall.museum */
35758,  /* surrey.museum */
35765,  /* svizzera.museum */
35774,  /* sweden.museum */
 7607,  /* sydney.museum */
35781,  /* tank.museum */
 1859,  /* tcm.museum */
 7717,  /* technology.museum */
35786,  /* telekommunikation.museum */
 8289,  /* television.museum */
35804,  /* texas.museum */
35810,  /* textile.museum */
 7790,  /* theater.museum */
 7220,  /* time.museum */
35818,  /* timekeeping.museum */
35830,  /* topology.museum */
19499,  /* torino.museum */
35839,  /* touch.museum */
 1396,  /* town.museum */
 7383,  /* transport.museum */
 2639,  /* tree.museum */
35845,  /* trolley.museum */
 8034,  /* trust.museum */
35853,  /* trustee.museum */
33916,  /* uhren.museum */
35861,  /* ulm.museum */
35865,  /* undersea.museum */
 8125,  /* university.museum */
19293,  /* usa.museum */
32256,  /* usantiques.museum */
35874,  /* usarts.museum */
33238,  /* uscountryestate.museum */
33295,  /* usculture.museum */
33340,  /* usdecorativearts.museum */
 3394,  /* usgarden.museum */
34044,  /* ushistory.museum */
35881,  /* ushuaia.museum */
34360,  /* uslivinghistory.museum */
12774,  /* utah.museum */
11634,  /* uvic.museum */
17716,  /* valley.museum */
19452,  /* vantaa.museum */
35889,  /* versailles.museum */
 8251,  /* viking.museum */
35900,  /* village.museum */
35908,  /* virginia.museum */
35917,  /* virtual.museum */
35925,  /* virtuel.museum */
 8329,  /* vlaanderen.museum */
35933,  /* volkenkunde.museum */
 8408,  /* wales.museum */
35945,  /* wallonie.museum */
32996,  /* war.museum */
35954,  /* washingtondc.museum */
35967,  /* watch-and-clock.museum */
33008,  /* watchandclock.museum */
35983,  /* western.museum */
35991,  /* westfalen.museum */
36001,  /* whaling.museum */
36009,  /* wildlife.museum */
33064,  /* williamsburg.museum */
34592,  /* windmill.museum */
 7200,  /* workshop.museum */
36018,  /* xn--9dbhblg6di.museum */
36033,  /* xn--comunicaes-v6a2o.museum */
36054,  /* xn--correios-e-telecomunicaes-ghc29a.museum */
36091,  /* xn--h1aegh.museum */
36102,  /* xn--lns-qla.museum */
34900,  /* york.museum */
36114,  /* yorkshire.museum */
36124,  /* yosemite.museum */
36133,  /* youth.museum */
36139,  /* zoological.museum */
36150,  /* zoology.museum */
  164,  /* aero.mv */
  986,  /* biz.mv */
 1910,  /* com.mv */
 2044,  /* coop.mv */
 2622,  /* edu.mv */
 3665,  /* gov.mv */
 3149,  /* info.mv */
 3611,  /* int.mv */
 4157,  /* mil.mv */
 5596,  /* museum.mv */
 5672,  /* name.mv */
 5710,  /* net.mv */
 6026,  /* org.mv */
 6376,  /* pro.mv */
   62,  /* ac.mw */
  986,  /* biz.mw */
  113,  /* co.mw */
 1910,  /* com.mw */
 2044,  /* coop.mw */
 2622,  /* edu.mw */
 3665,  /* gov.mw */
 3611,  /* int.mw */
 5596,  /* museum.mw */
 5710,  /* net.mw */
 6026,  /* org.mw */
10791,  /* blogspot.mx */
 1910,  /* com.mx */
 2622,  /* edu.mx */
11461,  /* gob.mx */
 5710,  /* net.mx */
12575,  /* nym.mx */
 6026,  /* org.mx */
10791,  /* blogspot.my */
 1910,  /* com.my */
 2622,  /* edu.my */
 3665,  /* gov.my */
 4157,  /* mil.my */
 5672,  /* name.my */
 5710,  /* net.my */
 6026,  /* org.my */
   62,  /* ac.mz */
12086,  /* adv.mz */
  113,  /* co.mz */
 2622,  /* edu.mz */
 3665,  /* gov.mz */
 4157,  /* mil.mz */
 5710,  /* net.mz */
 6026,  /* org.mz */
  221,  /* ca.na */
 1573,  /* cc.na */
  113,  /* co.na */
 1910,  /* com.na */
11492,  /* dr.na */
  898,  /* in.na */
 3149,  /* info.na */
 5415,  /* mobi.na */
 3583,  /* mx.na */
 5672,  /* name.na */
  137,  /* or.na */
 6026,  /* org.na */
 6376,  /* pro.na */
 7001,  /* school.na */
 2545,  /* tv.na */
  264,  /* us.na */
  659,  /* ws.na */
 3652,  /* forgot.her.name */
11821,  /* asso.nc */
 5943,  /* nom.nc */
  138,  /* r.cdn77.net */
    2,  /* a.prod.fastly.net */
 3542,  /* global.prod.fastly.net */
    2,  /* a.ssl.fastly.net */
   18,  /* b.ssl.fastly.net */
 3542,  /* global.ssl.fastly.net */
 5186,  /* map.fastlylb.net */
 6118,  /* arts.nf */
 1910,  /* com.nf */
12882,  /* firm.nf */
 3149,  /* info.nf */
 5710,  /* net.nf */
 1219,  /* other.nf */
 4488,  /* per.nf */
12406,  /* rec.nf */
 7493,  /* store.nf */
12075,  /* web.nf */
   62,  /* ac.ni */
  986,  /* biz.ni */
  113,  /* co.ni */
 1910,  /* com.ni */
 2622,  /* edu.ni */
11461,  /* gob.ni */
  898,  /* in.ni */
 3149,  /* info.ni */
 3611,  /* int.ni */
 4157,  /* mil.ni */
 5710,  /* net.ni */
 5943,  /* nom.ni */
 6026,  /* org.ni */
12075,  /* web.ni */
 3739,  /* gs.aa.no */
 8062,  /* nes.akershus.no */
  637,  /* os.hedmark.no */
38245,  /* valer.hedmark.no */
43245,  /* xn--vler-qoa.hedmark.no */
  637,  /* os.hordaland.no */
43258,  /* heroy.more-og-romsdal.no */
43264,  /* sande.more-og-romsdal.no */
 1087,  /* bo.nordland.no */
43258,  /* heroy.nordland.no */
43270,  /* xn--b-5ga.nordland.no */
43280,  /* xn--hery-ira.nordland.no */
38245,  /* valer.ostfold.no */
 1087,  /* bo.telemark.no */
43270,  /* xn--b-5ga.telemark.no */
43264,  /* sande.vestfold.no */
43264,  /* sande.xn--mre-og-romsdal-qqb.no */
43280,  /* xn--hery-ira.xn--mre-og-romsdal-qqb.no */
43245,  /* xn--vler-qoa.xn--stfold-9xa.no */
43293,  /* merseine.nu */
27588,  /* mine.nu */
 5943,  /* nom.nu */
43302,  /* shacknet.nu */
  113,  /* co.om */
 1910,  /* com.om */
 2622,  /* edu.om */
 3665,  /* gov.om */
 1855,  /* med.om */
 5596,  /* museum.om */
 5710,  /* net.om */
 6026,  /* org.om */
 6376,  /* pro.om */
 4953,  /* homelink.one */
43938,  /* tele.amune.org */
   36,  /* c.cdn77.org */
43943,  /* rsc.cdn77.org */
14077,  /* ssl.origin.cdn77-secure.org */
  257,  /* go.dyndns.org */
 6753,  /* home.dyndns.org */
  290,  /* al.eu.org */
11821,  /* asso.eu.org */
  562,  /* at.eu.org */
  584,  /* au.eu.org */
  860,  /* be.eu.org */
  932,  /* bg.eu.org */
  221,  /* ca.eu.org */
 1578,  /* cd.eu.org */
 1141,  /* ch.eu.org */
  842,  /* cn.eu.org */
  241,  /* cy.eu.org */
 2199,  /* cz.eu.org */
 2273,  /* de.eu.org */
 2469,  /* dk.eu.org */
 2622,  /* edu.eu.org */
 1883,  /* ee.eu.org */
  558,  /* es.eu.org */
 2993,  /* fi.eu.org */
 3227,  /* fr.eu.org */
 3676,  /* gr.eu.org */
 4090,  /* hr.eu.org */
 4106,  /* hu.eu.org */
   31,  /* ie.eu.org */
 2651,  /* il.eu.org */
  898,  /* in.eu.org */
 3611,  /* int.eu.org */
 3701,  /* is.eu.org */
 2095,  /* it.eu.org */
 4460,  /* jp.eu.org */
 3107,  /* kr.eu.org */
  151,  /* lt.eu.org */
 5079,  /* lu.eu.org */
 5114,  /* lv.eu.org */
 5274,  /* mc.eu.org */
 1690,  /* me.eu.org */
 5400,  /* mk.eu.org */
 5566,  /* mt.eu.org */
   70,  /* my.eu.org */
 5710,  /* net.eu.org */
  972,  /* ng.eu.org */
 1072,  /* nl.eu.org */
 1511,  /* no.eu.org */
  325,  /* nz.eu.org */
 6097,  /* paris.eu.org */
 5056,  /* pl.eu.org */
 6459,  /* pt.eu.org */
43954,  /* q-a.eu.org */
  166,  /* ro.eu.org */
 2187,  /* ru.eu.org */
 1492,  /* se.eu.org */
 2361,  /* si.eu.org */
 7271,  /* sk.eu.org */
 3281,  /* tr.eu.org */
 8115,  /* uk.eu.org */
  264,  /* us.eu.org */
16563,  /* nerdpol.ovh */
 1086,  /* abo.pa */
   62,  /* ac.pa */
 1910,  /* com.pa */
 2622,  /* edu.pa */
11461,  /* gob.pa */
  971,  /* ing.pa */
 1855,  /* med.pa */
 5710,  /* net.pa */
 5943,  /* nom.pa */
 6026,  /* org.pa */
16559,  /* sld.pa */
10791,  /* blogspot.pe */
 1910,  /* com.pe */
 2622,  /* edu.pe */
11461,  /* gob.pe */
 4157,  /* mil.pe */
 5710,  /* net.pe */
 5943,  /* nom.pe */
12575,  /* nym.pe */
 6026,  /* org.pe */
 1910,  /* com.pf */
 2622,  /* edu.pf */
 6026,  /* org.pf */
 1910,  /* com.ph */
 2622,  /* edu.ph */
 3665,  /* gov.ph */
   58,  /* i.ph */
 4157,  /* mil.ph */
 5710,  /* net.ph */
  977,  /* ngo.ph */
 6026,  /* org.ph */
11680,  /* 1337.pictures */
  986,  /* biz.pk */
 1910,  /* com.pk */
 2622,  /* edu.pk */
  402,  /* fam.pk */
11461,  /* gob.pk */
43958,  /* gok.pk */
35006,  /* gon.pk */
 3648,  /* gop.pk */
 4480,  /* gos.pk */
 3665,  /* gov.pk */
 3149,  /* info.pk */
 5710,  /* net.pk */
 6026,  /* org.pk */
12075,  /* web.pk */
 1665,  /* ap.gov.pl */
44995,  /* griw.gov.pl */
  715,  /* ic.gov.pl */
 3701,  /* is.gov.pl */
45000,  /* kmpsp.gov.pl */
45006,  /* konsulat.gov.pl */
45015,  /* kppsp.gov.pl */
45021,  /* kwp.gov.pl */
45025,  /* kwpsp.gov.pl */
45031,  /* mup.gov.pl */
 1064,  /* mw.gov.pl */
45035,  /* oirm.gov.pl */
45040,  /* oum.gov.pl */
  522,  /* pa.gov.pl */
45044,  /* pinb.gov.pl */
45049,  /* piw.gov.pl */
 6927,  /* po.gov.pl */
45002,  /* psp.gov.pl */
45053,  /* psse.gov.pl */
45058,  /* pup.gov.pl */
 3794,  /* rzgw.gov.pl */
 1487,  /* sa.gov.pl */
45062,  /* sdn.gov.pl */
37744,  /* sko.gov.pl */
 7304,  /* so.gov.pl */
 7416,  /* sr.gov.pl */
45066,  /* starostwo.gov.pl */
 8107,  /* ug.gov.pl */
45076,  /* ugim.gov.pl */
 3208,  /* um.gov.pl */
45081,  /* umig.gov.pl */
45086,  /* upow.gov.pl */
19237,  /* uppo.gov.pl */
  264,  /* us.gov.pl */
45095,  /* uw.gov.pl */
45098,  /* uzs.gov.pl */
45102,  /* wif.gov.pl */
45106,  /* wiih.gov.pl */
12582,  /* winb.gov.pl */
43240,  /* wios.gov.pl */
45111,  /* witd.gov.pl */
45116,  /* wiw.gov.pl */
 6842,  /* wsa.gov.pl */
 4642,  /* wskr.gov.pl */
45120,  /* wuoz.gov.pl */
45091,  /* wzmiuw.gov.pl */
45125,  /* zp.gov.pl */
 1397,  /* own.pm */
  113,  /* co.pn */
 2622,  /* edu.pn */
 3665,  /* gov.pn */
 5710,  /* net.pn */
 6026,  /* org.pn */
   62,  /* ac.pr */
  986,  /* biz.pr */
 1910,  /* com.pr */
 2622,  /* edu.pr */
  902,  /* est.pr */
 3665,  /* gov.pr */
 3149,  /* info.pr */
45133,  /* isla.pr */
 5672,  /* name.pr */
 5710,  /* net.pr */
 6026,  /* org.pr */
 6376,  /* pro.pr */
 6397,  /* prof.pr */
45151,  /* bci.dnstrace.pro */
 1910,  /* com.ps */
 2622,  /* edu.ps */
 3665,  /* gov.ps */
 5710,  /* net.ps */
 6026,  /* org.ps */
18804,  /* plo.ps */
 1961,  /* sec.ps */
10791,  /* blogspot.pt */
 1910,  /* com.pt */
 2622,  /* edu.pt */
 3665,  /* gov.pt */
 3611,  /* int.pt */
 5710,  /* net.pt */
31092,  /* nome.pt */
12575,  /* nym.pt */
 6026,  /* org.pt */
17939,  /* publ.pt */
45155,  /* belau.pw */
11510,  /* cloudns.pw */
  113,  /* co.pw */
 1856,  /* ed.pw */
  257,  /* go.pw */
 1198,  /* ne.pw */
 5943,  /* nom.pw */
  137,  /* or.pw */
45161,  /* x443.pw */
 1910,  /* com.py */
 2044,  /* coop.py */
 2622,  /* edu.py */
 3665,  /* gov.py */
 4157,  /* mil.py */
 5710,  /* net.py */
 6026,  /* org.py */
10791,  /* blogspot.qa */
 1910,  /* com.qa */
 2622,  /* edu.qa */
 3665,  /* gov.qa */
 4157,  /* mil.qa */
 5672,  /* name.qa */
 5710,  /* net.qa */
 5943,  /* nom.qa */
 6026,  /* org.qa */
 1140,  /* sch.qa */
11821,  /* asso.re */
10791,  /* blogspot.re */
 1910,  /* com.re */
 5943,  /* nom.re */
45166,  /* clan.rip */
 6118,  /* arts.ro */
10791,  /* blogspot.ro */
 1910,  /* com.ro */
12882,  /* firm.ro */
 3149,  /* info.ro */
 5943,  /* nom.ro */
   97,  /* nt.ro */
12575,  /* nym.ro */
 6026,  /* org.ro */
12406,  /* rec.ro */
 7204,  /* shop.ro */
 7493,  /* store.ro */
 7890,  /* tm.ro */
12712,  /* www.ro */
11571,  /* lima-city.rocks */
32032,  /* myddns.rocks */
 7366,  /* webspace.rocks */
   62,  /* ac.rs */
10791,  /* blogspot.rs */
  113,  /* co.rs */
 2622,  /* edu.rs */
 3665,  /* gov.rs */
  898,  /* in.rs */
 5943,  /* nom.rs */
 6026,  /* org.rs */
 1173,  /* ox.rs */
12806,  /* hb.cldmail.ru */
45329,  /* development.run */
14892,  /* ravendb.run */
   62,  /* ac.rw */
  113,  /* co.rw */
 1910,  /* com.rw */
 2622,  /* edu.rw */
11834,  /* gouv.rw */
 3665,  /* gov.rw */
 3611,  /* int.rw */
 4157,  /* mil.rw */
 5710,  /* net.rw */
 1910,  /* com.sa */
 2622,  /* edu.sa */
 3665,  /* gov.sa */
 1855,  /* med.sa */
 5710,  /* net.sa */
 6026,  /* org.sa */
 6462,  /* pub.sa */
 1140,  /* sch.sa */
 1910,  /* com.sd */
 2622,  /* edu.sd */
 3665,  /* gov.sd */
 3149,  /* info.sd */
 1855,  /* med.sd */
 5710,  /* net.sd */
 6026,  /* org.sd */
 2545,  /* tv.sd */
    2,  /* a.se */
   62,  /* ac.se */
   18,  /* b.se */
  855,  /* bd.se */
10791,  /* blogspot.se */
32220,  /* brand.se */
   36,  /* c.se */
 1910,  /* com.se */
  142,  /* d.se */
   32,  /* e.se */
  192,  /* f.se */
 4541,  /* fh.se */
45341,  /* fhsk.se */
45346,  /* fhv.se */
  162,  /* g.se */
   14,  /* h.se */
   58,  /* i.se */
  734,  /* k.se */
45350,  /* komforb.se */
45358,  /* kommunalforbund.se */
45374,  /* komvux.se */
  211,  /* l.se */
45381,  /* lanbib.se */
  354,  /* m.se */
  235,  /* n.se */
45388,  /* naturbruksgymn.se */
   49,  /* o.se */
 6026,  /* org.se */
    7,  /* p.se */
45403,  /* parti.se */
  469,  /* pp.se */
  371,  /* press.se */
  138,  /* r.se */
  110,  /* s.se */
   25,  /* t.se */
 7890,  /* tm.se */
  585,  /* u.se */
  650,  /* w.se */
  398,  /* x.se */
   71,  /* y.se */
  326,  /* z.se */
10791,  /* blogspot.sg */
 1910,  /* com.sg */
 2622,  /* edu.sg */
 3665,  /* gov.sg */
 5710,  /* net.sg */
 6026,  /* org.sg */
 4488,  /* per.sg */
10791,  /* blogspot.si */
 5943,  /* nom.si */
  527,  /* art.sn */
10791,  /* blogspot.sn */
 1910,  /* com.sn */
 2622,  /* edu.sn */
11834,  /* gouv.sn */
 6026,  /* org.sn */
17012,  /* perso.sn */
45443,  /* univ.sn */
 1910,  /* com.so */
 5710,  /* net.so */
 6026,  /* org.so */
 7910,  /* linkitools.space */
45448,  /* stackspace.space */
45459,  /* uber.space */
45464,  /* xs4all.space */
  113,  /* co.st */
 1910,  /* com.st */
45471,  /* consulado.st */
 2622,  /* edu.st */
45481,  /* embaixada.st */
 3665,  /* gov.st */
 4157,  /* mil.st */
 5710,  /* net.st */
45491,  /* noho.st */
 5943,  /* nom.st */
 6026,  /* org.st */
45496,  /* principe.st */
27655,  /* saotome.st */
 7493,  /* store.st */
45505,  /* abkhazia.su */
45171,  /* adygeya.su */
45514,  /* aktyubinsk.su */
45525,  /* arkhangelsk.su */
45537,  /* armenia.su */
45545,  /* ashgabad.su */
45554,  /* azerbaijan.su */
45565,  /* balashov.su */
45179,  /* bashkiria.su */
45574,  /* bryansk.su */
45582,  /* bukhara.su */
45590,  /* chimkent.su */
45197,  /* dagestan.su */
45599,  /* east-kazakhstan.su */
 5708,  /* exnet.su */
33809,  /* georgia.su */
45206,  /* grozny.su */
45615,  /* ivanovo.su */
45623,  /* jambyl.su */
45213,  /* kalmykia.su */
45630,  /* kaluga.su */
45637,  /* karacol.su */
45645,  /* karaganda.su */
45655,  /* karelia.su */
45663,  /* khakassia.su */
45673,  /* krasnodar.su */
45683,  /* kurgan.su */
45222,  /* kustanai.su */
45690,  /* lenug.su */
45696,  /* mangyshlak.su */
45238,  /* mordovia.su */
 7270,  /* msk.su */
45707,  /* murmansk.su */
45260,  /* nalchik.su */
45716,  /* navoi.su */
45722,  /* north-kazakhstan.su */
45268,  /* nov.su */
12575,  /* nym.su */
45739,  /* obninsk.su */
45747,  /* penza.su */
45753,  /* pokrovsk.su */
45762,  /* sochi.su */
11450,  /* spb.su */
45768,  /* tashkent.su */
45777,  /* termez.su */
45784,  /* togliatti.su */
45794,  /* troitsk.su */
45802,  /* tselinograd.su */
45814,  /* tula.su */
45819,  /* tuva.su */
45287,  /* vladikavkaz.su */
45299,  /* vladimir.su */
44091,  /* vologda.su */
 1910,  /* com.sv */
 2622,  /* edu.sv */
11461,  /* gob.sv */
 6026,  /* org.sv */
 4652,  /* red.sv */
 3665,  /* gov.sx */
12575,  /* nym.sx */
45824,  /* knightpoint.systems */
   62,  /* ac.sz */
  113,  /* co.sz */
 6026,  /* org.sz */
   62,  /* ac.th */
  113,  /* co.th */
  257,  /* go.th */
  898,  /* in.th */
 5364,  /* mi.th */
 5710,  /* net.th */
  137,  /* or.th */
   62,  /* ac.tj */
  986,  /* biz.tj */
  113,  /* co.tj */
 1910,  /* com.tj */
 2622,  /* edu.tj */
  257,  /* go.tj */
 3665,  /* gov.tj */
 3611,  /* int.tj */
 4157,  /* mil.tj */
 5672,  /* name.tj */
 5710,  /* net.tj */
 1812,  /* nic.tj */
 5943,  /* nom.tj */
 6026,  /* org.tj */
45128,  /* test.tj */
12075,  /* web.tj */
  113,  /* co.tm */
 1910,  /* com.tm */
 2622,  /* edu.tm */
 3665,  /* gov.tm */
 4157,  /* mil.tm */
 5710,  /* net.tm */
 5943,  /* nom.tm */
 6026,  /* org.tm */
45836,  /* agrinet.tn */
 1910,  /* com.tn */
45844,  /* defense.tn */
45852,  /* edunet.tn */
 6135,  /* ens.tn */
 4193,  /* fin.tn */
 3665,  /* gov.tn */
12273,  /* ind.tn */
 3149,  /* info.tn */
 7884,  /* intl.tn */
 1907,  /* mincom.tn */
  561,  /* nat.tn */
 5710,  /* net.tn */
 6026,  /* org.tn */
17012,  /* perso.tn */
45859,  /* rnrt.tn */
12587,  /* rns.tn */
 5874,  /* rnu.tn */
44839,  /* tourism.tn */
 6625,  /* turen.tn */
 1910,  /* com.to */
 2622,  /* edu.to */
 3665,  /* gov.to */
 4157,  /* mil.to */
 5710,  /* net.to */
 6026,  /* org.to */
45864,  /* vpnplus.to */
36558,  /* now-dns.top */
45872,  /* ntdll.top */
  164,  /* aero.tt */
  986,  /* biz.tt */
  113,  /* co.tt */
 1910,  /* com.tt */
 2044,  /* coop.tt */
 2622,  /* edu.tt */
 3665,  /* gov.tt */
 3149,  /* info.tt */
 3611,  /* int.tt */
 4440,  /* jobs.tt */
 5415,  /* mobi.tt */
 5596,  /* museum.tt */
 5672,  /* name.tt */
 5710,  /* net.tt */
 6026,  /* org.tt */
 6376,  /* pro.tt */
 7998,  /* travel.tt */
45886,  /* better-than.tv */
11733,  /* dyndns.tv */
45898,  /* on-the-web.tv */
45909,  /* worse-than.tv */
45945,  /* mymailer.com.tw */
   62,  /* ac.tz */
  113,  /* co.tz */
  257,  /* go.tz */
 7728,  /* hotel.tz */
 3149,  /* info.tz */
 1690,  /* me.tz */
 4157,  /* mil.tz */
 5415,  /* mobi.tz */
 1198,  /* ne.tz */
  137,  /* or.tz */
 2155,  /* sc.tz */
 2545,  /* tv.tz */
  986,  /* biz.ua */
 1573,  /* cc.ua */
45954,  /* cherkassy.ua */
45964,  /* cherkasy.ua */
 3659,  /* chernigov.ua */
 3905,  /* chernihiv.ua */
45973,  /* chernivtsi.ua */
45984,  /* chernovtsy.ua */
  996,  /* ck.ua */
  842,  /* cn.ua */
  113,  /* co.ua */
 1910,  /* com.ua */
 2088,  /* cr.ua */
45995,  /* crimea.ua */
 2173,  /* cv.ua */
  285,  /* dn.ua */
46002,  /* dnepropetrovsk.ua */
46017,  /* dnipropetrovsk.ua */
46032,  /* dominic.ua */
46040,  /* donetsk.ua */
46048,  /* dp.ua */
 2622,  /* edu.ua */
 3665,  /* gov.ua */
 5136,  /* if.ua */
  898,  /* in.ua */
 5769,  /* inf.ua */
46051,  /* ivano-frankivsk.ua */
 4547,  /* kh.ua */
46067,  /* kharkiv.ua */
46075,  /* kharkov.ua */
46083,  /* kherson.ua */
46091,  /* khmelnitskiy.ua */
46104,  /* khmelnytskyi.ua */
46117,  /* kiev.ua */
46122,  /* kirovograd.ua */
 4593,  /* km.ua */
 3107,  /* kr.ua */
46133,  /* krym.ua */
 6791,  /* ks.ua */
46138,  /* kv.ua */
46141,  /* kyiv.ua */
12508,  /* lg.ua */
  151,  /* lt.ua */
 5070,  /* ltd.ua */
46146,  /* lugansk.ua */
46154,  /* lutsk.ua */
 5114,  /* lv.ua */
46160,  /* lviv.ua */
 5400,  /* mk.ua */
46165,  /* mykolaiv.ua */
 5710,  /* net.ua */
46174,  /* nikolaev.ua */
 3160,  /* od.ua */
17101,  /* odesa.ua */
46183,  /* odessa.ua */
 6026,  /* org.ua */
 5056,  /* pl.ua */
46190,  /* poltava.ua */
  469,  /* pp.ua */
46198,  /* rivne.ua */
46204,  /* rovno.ua */
 8041,  /* rv.ua */
 6950,  /* sb.ua */
46210,  /* sebastopol.ua */
46221,  /* sevastopol.ua */
 7290,  /* sm.ua */
 5625,  /* sumy.ua */
  334,  /* te.ua */
46232,  /* ternopil.ua */
 5847,  /* uz.ua */
46241,  /* uzhgorod.ua */
46250,  /* vinnica.ua */
46258,  /* vinnytsia.ua */
 8348,  /* vn.ua */
46268,  /* volyn.ua */
36863,  /* yalta.ua */
46274,  /* zaporizhzhe.ua */
46286,  /* zaporizhzhia.ua */
46299,  /* zhitomir.ua */
46308,  /* zhytomyr.ua */
45125,  /* zp.ua */
 4401,  /* zt.ua */
   62,  /* ac.ug */
10791,  /* blogspot.ug */
  113,  /* co.ug */
 1910,  /* com.ug */
  257,  /* go.ug */
 1198,  /* ne.ug */
 5943,  /* nom.ug */
  137,  /* or.ug */
 6026,  /* org.ug */
 2155,  /* sc.ug */
11692,  /* barsy.co.uk */
 5974,  /* barsyonline.co.uk */
10791,  /* blogspot.co.uk */
46328,  /* gwiddle.co.uk */
46336,  /* nh-serv.co.uk */
11795,  /* no-ip.co.uk */
16610,  /* wellbeingzone.co.uk */
 5900,  /* homeoffice.gov.uk */
46344,  /* service.gov.uk */
46352,  /* glug.org.uk */
46353,  /* lug.org.uk */
43907,  /* lugs.org.uk */
 1573,  /* cc.ak.us */
16571,  /* k12.ak.us */
16579,  /* lib.ak.us */
 1573,  /* cc.hi.us */
16579,  /* lib.hi.us */
46395,  /* chtr.k12.ma.us */
46400,  /* paroch.k12.ma.us */
16840,  /* pvt.k12.ma.us */
46407,  /* ann-arbor.mi.us */
 1573,  /* cc.mi.us */
11446,  /* cog.mi.us */
46417,  /* dst.mi.us */
46421,  /* eaton.mi.us */
 8364,  /* gen.mi.us */
16571,  /* k12.mi.us */
16579,  /* lib.mi.us */
12350,  /* mus.mi.us */
 7619,  /* tec.mi.us */
46427,  /* washtenaw.mi.us */
 1573,  /* cc.wv.us */
  113,  /* co.uz */
 1910,  /* com.uz */
 5710,  /* net.uz */
 6026,  /* org.uz */
 1910,  /* com.vc */
 2622,  /* edu.vc */
 3665,  /* gov.vc */
 4157,  /* mil.vc */
 5710,  /* net.vc */
 5943,  /* nom.vc */
 6026,  /* org.vc */
 6118,  /* arts.ve */
  113,  /* co.ve */
 1910,  /* com.ve */
46441,  /* e12.ve */
 2622,  /* edu.ve */
12882,  /* firm.ve */
11461,  /* gob.ve */
 3665,  /* gov.ve */
 3149,  /* info.ve */
 3611,  /* int.ve */
 4157,  /* mil.ve */
 5710,  /* net.ve */
 6026,  /* org.ve */
12406,  /* rec.ve */
 7493,  /* store.ve */
 7619,  /* tec.ve */
12075,  /* web.ve */
  113,  /* co.vi */
 1910,  /* com.vi */
16571,  /* k12.vi */
 5710,  /* net.vi */
 6026,  /* org.vi */
   62,  /* ac.vn */
  986,  /* biz.vn */
10791,  /* blogspot.vn */
 1910,  /* com.vn */
 2622,  /* edu.vn */
 3665,  /* gov.vn */
 3838,  /* health.vn */
 3149,  /* info.vn */
 3611,  /* int.vn */
 5672,  /* name.vn */
 5710,  /* net.vn */
 6026,  /* org.vn */
 6376,  /* pro.vn */
46460,  /* xn--80au.xn--90a3ac */
46469,  /* xn--90azh.xn--90a3ac */
 9100,  /* xn--c1avg.xn--90a3ac */
46479,  /* xn--d1at.xn--90a3ac */
46488,  /* xn--o1ac.xn--90a3ac */
46497,  /* xn--o1ach.xn--90a3ac */
 8877,  /* xn--55qx5d.xn--j6w193g */
16878,  /* xn--gmqw5a.xn--j6w193g */
10100,  /* xn--mxtq1m.xn--j6w193g */
12836,  /* xn--od0alg.xn--j6w193g */
16934,  /* xn--uc0atv.xn--j6w193g */
16957,  /* xn--wcvs22d.xn--j6w193g */
46507,  /* xn--12c1fe0br.xn--o3cw4h */
46521,  /* xn--12cfi8ixb8l.xn--o3cw4h */
46537,  /* xn--12co0c3b4eva.xn--o3cw4h */
46554,  /* xn--h3cuzk1di.xn--o3cw4h */
46568,  /* xn--m3ch0j3a.xn--o3cw4h */
46581,  /* xn--o3cyx2a.xn--o3cw4h */
43351,  /* blogsite.xyz */
46593,  /* crafting.xyz */
  466,  /* fhapp.xyz */
43932,  /* zapto.xyz */
   62,  /* ac.zm */
  986,  /* biz.zm */
  113,  /* co.zm */
 1910,  /* com.zm */
 2622,  /* edu.zm */
 3665,  /* gov.zm */
 3149,  /* info.zm */
 4157,  /* mil.zm */
 5710,  /* net.zm */
 6026,  /* org.zm */
 1140,  /* sch.zm */
   62,  /* ac.zw */
  113,  /* co.zw */
 3665,  /* gov.zw */
 4157,  /* mil.zw */
 6026,  /* org.zw */
};

static const size_t kLeafChildOffset = 3904;
static const size_t kNumRootChildren = 1555;
