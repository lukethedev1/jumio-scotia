//
//  JumioDefaultUI.h
//
//  Copyright © 2025 Jumio Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DefaultUI.
FOUNDATION_EXPORT double JumioDefaultUIVersionNumber;

//! Project version string for DefaultUI.
FOUNDATION_EXPORT const unsigned char JumioDefaultUIVersionString[];
